import streamlit as st
from datetime import datetime
import time
from typing import Dict
import uuid
from components import Card, ErrorBoundary, display_rating
from error_handler import error_logger

class MovieCard:
    def __init__(self, movie_data, review_system, streaming_service):
        self.movie_data = movie_data
        self.review_system = review_system
        self.streaming_service = streaming_service

    def get_genres(self, movie):
        """Safely get genres from movie data"""
        genres = []
        try:
            if 'genre_ids' in movie:
                genres = self.movie_data.get_genres_by_ids(movie['genre_ids'])
            elif 'genres' in movie:
                genres = [genre['name'] for genre in movie['genres']]
        except:
            # Fallback genres if there's an error
            if 'genre_ids' in movie:
                genre_map = {
                    28: "Action", 12: "Adventure", 16: "Animation",
                    35: "Comedy", 80: "Crime", 99: "Documentary",
                    18: "Drama", 10751: "Family", 14: "Fantasy",
                    36: "History", 27: "Horror", 10402: "Music",
                    9648: "Mystery", 10749: "Romance", 878: "Science Fiction",
                    10770: "TV Movie", 53: "Thriller", 10752: "War",
                    37: "Western"
                }
                genres = [genre_map.get(id, "") for id in movie.get('genre_ids', [])]
                genres = [g for g in genres if g]  # Remove empty strings
        return genres

    def display(self, movie: Dict, prefix: str = ""):
        """Display movie card using reusable components"""
        with ErrorBoundary():
            # Create movie content
            content = self._create_movie_content(movie)
            
            # Create movie footer with actions
            footer = self._create_movie_footer(movie)
            
            # Use reusable Card component
            Card(
                title=movie['title'],
                content=content,
                footer=footer
            ).render()

    def _create_movie_content(self, movie: Dict):
        """Create the main content of the movie card"""
        movie_id = movie['id']
        container = st.container()
        with container:
            col1, col2 = st.columns([1, 3])
            
            with col1:
                if movie.get('poster_path'):
                    poster_url = f"https://image.tmdb.org/t/p/w200{movie['poster_path']}"
                else:
                    poster_url = "https://via.placeholder.com/200x300?text=No+Poster"
                st.image(poster_url, use_container_width=True)
            
            with col2:
                st.markdown(f"### {movie['title']}")
                display_rating(movie.get('vote_average', 0) / 2)  # Convert 10-scale to 5-scale
                st.write(f"{movie.get('vote_count', 0)} votes")
                
                if movie.get('release_date'):
                    st.write(f"Release Date: {movie['release_date']}")
                
                # Get movie state from session
                movie_key = f"movie_{movie_id}"
                movie_state = st.session_state.movie_states.get(movie_key, {})
                
                # Like button and count
                if 'user' in st.session_state and st.session_state.user.get('is_logged_in'):
                    likes_count = self.review_system.get_movie_likes_count(movie_id)
                    is_liked = self.review_system.get_movie_like_status(movie_id, st.session_state.user.get('id'))
                    like_emoji = "❤️" if is_liked else "🤍"
                    
                    if st.button(f"{like_emoji} {likes_count}", key=f"like_btn_{movie_id}"):
                        try:
                            like_result = self.review_system.toggle_movie_like(movie_id, st.session_state.user.get('id'))
                            movie_state['liked'] = like_result
                            st.session_state.movie_states[movie_key] = movie_state
                            
                            # Store message in session state
                            if like_result:
                                st.success("Added to your likes!")
                            else:
                                st.info("Removed from your likes")
                            
                            # Update query params to trigger refresh
                            st.query_params["refresh"] = str(time.time())
                            
                        except Exception as e:
                            error_logger.log_error(e, "Like operation failed")
                            st.error("Unable to update like status. Please try again.")
                    
                    # Display stored message if exists
                    if f"like_message_{movie_id}" in st.session_state:
                        st.success(st.session_state[f"like_message_{movie_id}"])
                        # Clear message after displaying
                        del st.session_state[f"like_message_{movie_id}"]
                else:
                    likes_count = self.review_system.get_movie_likes_count(movie_id)
                    st.markdown(f"**🤍 {likes_count} likes**")
                
                # Review section
                if 'user' in st.session_state and st.session_state.user.get('is_logged_in'):
                    if st.button("Add Review", key=f"review_btn_{movie_id}"):
                        movie_state['show_review'] = True
                        st.session_state.movie_states[movie_key] = movie_state
                        st.experimental_rerun()
                    
                    if movie_state.get('show_review'):
                        with st.form(key=f"review_form_{movie_id}"):
                            rating = st.slider("Rating", 1, 5, 3, key=f"rating_{movie_id}")
                            review_text = st.text_area("Review", key=f"review_{movie_id}")
                            submit = st.form_submit_button("Submit Review")
                            
                            if submit:
                                try:
                                    self.review_system.add_review(
                                        movie_id,
                                        st.session_state.user.get('id'),
                                        rating,
                                        review_text
                                    )
                                    movie_state['show_review'] = False
                                    st.session_state.movie_states[movie_key] = movie_state
                                    st.success("Review added successfully!")
                                    time.sleep(0.1)
                                    st.experimental_rerun()
                                except Exception as e:
                                    st.error("Error adding review. Please try again.")
        
        return container

    def _create_movie_footer(self, movie: Dict):
        """Create the footer with action buttons"""
        movie_id = movie['id']
        container = st.container()
        with container:
            col1, col2 = st.columns(2)
            movie_key = f"movie_{movie_id}"
            
            with col1:
                if st.button("Overview", key=f"overview_btn_{movie_id}"):
                    movie_state = st.session_state.movie_states.get(movie_key, {})
                    movie_state['show_details'] = not movie_state.get('show_details', False)
                    st.session_state.movie_states[movie_key] = movie_state
                    st.query_params["refresh"] = str(time.time())
            
            with col2:
                if st.button("Watch", key=f"watch_btn_{movie_id}"):
                    movie_state = st.session_state.movie_states.get(movie_key, {})
                    movie_state['show_watch'] = not movie_state.get('show_watch', False)
                    st.session_state.movie_states[movie_key] = movie_state
                    st.query_params["refresh"] = str(time.time())

            # Show content based on state
            movie_state = st.session_state.movie_states.get(movie_key, {})
            if movie_state.get('show_details'):
                with st.expander("Overview", expanded=True):
                    st.write(movie.get('overview', 'No overview available'))
                
            if movie_state.get('show_watch'):
                self._show_streaming_options(movie)

        return container

    def _show_streaming_options(self, movie: Dict):
        """Show streaming options with error handling"""
        try:
            options = self.streaming_service.get_streaming_options(movie['id'])
            if options:
                st.write("Available on:")
                for option in options:
                    st.markdown(f"- [{option['provider']}]({option['url']})")
            else:
                st.info("No streaming options found")
        except Exception as e:
            error_logger.display_error_message(
                e,
                "fetching streaming options",
                "Unable to load streaming options at the moment."
            )

    def display_movie_details(self, movie):
        """Display detailed movie information"""
        col1, col2 = st.columns([1, 2])
        
        with col1:
            if movie.get('poster_path'):
                st.image(
                    f"https://image.tmdb.org/t/p/w500{movie['poster_path']}", 
                    use_container_width=True
                )
        
        with col2:
            st.markdown(f"## {movie['title']}")
            if movie.get('tagline'):
                st.markdown(f"*{movie['tagline']}*")
            
            st.markdown("### Overview")
            st.write(movie.get('overview', 'No overview available'))
            
            # Movie details
            release_date = movie.get('release_date', 'N/A')
            runtime = movie.get('runtime', 'N/A')
            rating = movie.get('vote_average', 'N/A')
            
            st.markdown(f"""
            **Release Date:** {release_date}  
            **Runtime:** {runtime} minutes  
            **Rating:** {rating}/10  
            """)