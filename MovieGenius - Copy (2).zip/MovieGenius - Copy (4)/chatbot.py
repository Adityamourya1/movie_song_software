import streamlit as st
import openai
from typing import List, Dict
from datetime import datetime
import re
import random

class MovieChatbot:
    def __init__(self, movie_data, user_profile):
        self.movie_data = movie_data
        self.user_profile = user_profile
        self.openai = openai
        self.openai.api_key = st.secrets["OPENAI_API_KEY"]
        
        # Initialize system prompt
        self.system_prompt = """
        You are an expert movie recommendation chatbot. You have extensive knowledge 
        about movies, directors, actors, and genres. You can provide personalized 
        recommendations based on users' preferences and viewing history.
        """
        
        # Initialize chat state
        if 'chat_messages' not in st.session_state:
            st.session_state.chat_messages = []
        if 'show_chat' not in st.session_state:
            st.session_state.show_chat = False

    def display_chat_interface(self):
        st.markdown("""
            <div class="chat-container">
                <div class="chat-header">
                    <h3>Movie Assistant</h3>
                    <button class="close-btn">×</button>
                </div>
                <div class="chat-messages" id="chat-messages">
        """, unsafe_allow_html=True)
        
        # Display chat messages with animation
        for msg in st.session_state.chat_messages:
            msg_class = "user-message" if msg["role"] == "user" else "bot-message"
            st.markdown(f"""
                <div class="chat-message {msg_class}">
                    <div class="message-content">{msg["content"]}</div>
                    <div class="message-time">{datetime.now().strftime('%H:%M')}</div>
                </div>
            """, unsafe_allow_html=True)
        
        st.markdown("</div>", unsafe_allow_html=True)
        
        # Chat input
        with st.container():
            st.text_input(
                "Message",
                key="chat_input",
                placeholder="Ask me about movies...",
                on_change=self.handle_input
            )

    def get_response(self, prompt: str) -> str:
        """Get response with fallback for API limits"""
        try:
            messages = [{"role": "system", "content": self.system_prompt}]
            messages.extend([{"role": "user", "content": prompt}])
            
            response = self.openai.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=messages,
                max_tokens=150,
                temperature=0.7
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            # Check if it's a quota error
            if "insufficient_quota" in str(e):
                return self._get_fallback_response(prompt)
            return f"I'm having trouble right now. Please try again later."

    def _get_fallback_response(self, prompt: str) -> str:
        """Provide basic fallback responses when API is unavailable"""
        # Basic keyword matching for common movie-related questions
        prompt_lower = prompt.lower()
        
        if "recommend" in prompt_lower or "suggest" in prompt_lower:
            return ("I'm sorry, but I can't provide personalized recommendations right now. "
                    "Try exploring our trending movies or use the search feature!")
        
        elif "genre" in prompt_lower:
            return ("You can explore different genres using the filters on our main page. "
                    "We have action, comedy, drama, and many more!")
        
        elif "rating" in prompt_lower or "review" in prompt_lower:
            return ("You can find movie ratings and reviews on each movie's detail page. "
                    "Click on any movie to learn more!")
        
        elif "hello" in prompt_lower or "hi" in prompt_lower:
            return "Hello! While I'm operating in limited mode, I can still help you navigate the website!"
        
        else:
            return ("I'm currently operating in limited mode due to high demand. "
                    "Please try using our search and filter features to find what you're looking for!")

    def clear_chat_history(self):
        """Clear chat history"""
        st.session_state.chat_messages = []

    def _get_user_context(self) -> str:
        if 'user' not in st.session_state:
            return ""
        user_id = st.session_state.user['id']
        profile = self.user_profile.get_user_profile(user_id)
        if not profile:
            return ""
        return f"""
        User Context:
        - Preferred Genres: {', '.join(profile['preferences']['preferred_genres'])}
        - Mood Preferences: {', '.join(profile['preferences']['mood_preferences'])}
        - Language Preferences: {', '.join(profile['preferences']['language_preferences'])}
        """

    def initialize_chat_history(self):
        """Initialize chat history in session state"""
        if 'chat_history' not in st.session_state:
            st.session_state.chat_history = []

    def display_chat_interface(self):
        """Display chat interface in Streamlit"""
        st.markdown("""
        <style>
        .chat-message {
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
            display: flex;
            flex-direction: column;
        }
        .user-message {
            background-color: #262730;
            margin-left: 2rem;
        }
        .bot-message {
            background-color: #1E1E1E;
            margin-right: 2rem;
        }
        </style>
        """, unsafe_allow_html=True)

        # Display chat history
        for message in st.session_state.chat_messages:
            with st.container():
                if message["role"] == "user":
                    st.markdown(f"""
                    <div class="chat-message user-message">
                        <p>{message["content"]}</p>
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown(f"""
                    <div class="chat-message bot-message">
                        <p>{message["content"]}</p>
                    </div>
                    """, unsafe_allow_html=True)

        # Chat input
        user_input = st.text_input("Ask me about movies!", key="chat_input")
        if user_input:
            self.process_user_input(user_input)

    def process_user_input(self, user_input: str):
        """Process user input and generate response"""
        # Add user message to chat history
        st.session_state.chat_messages.append({
            "role": "user",
            "content": user_input
        })

        # Get user context if available
        user_context = self._get_user_context() if 'user' in st.session_state else ""

        # Prepare messages for API
        messages = [
            {"role": "system", "content": self.system_prompt + user_context},
            *[{
                "role": m["role"],
                "content": m["content"]
            } for m in st.session_state.chat_messages[-5:]]  # Include last 5 messages
        ]

        try:
            # Get response from OpenAI
            response = self.openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=messages,
                temperature=0.7,
                max_tokens=300
            )

            # Process the response
            bot_response = response.choices[0].message.content
            
            # Check if response contains movie recommendations
            movie_titles = self._extract_movie_titles(bot_response)
            if movie_titles:
                # Fetch movie details and add them to the response
                movie_details = self._get_movie_details(movie_titles)
                bot_response = self._enhance_response_with_movies(
                    bot_response, movie_details)

            # Add bot response to chat history
            st.session_state.chat_messages.append({
                "role": "assistant",
                "content": bot_response
            })

        except Exception as e:
            st.error(f"Error generating response: {str(e)}")

    def _extract_movie_titles(self, text: str) -> List[str]:
        """Extract movie titles from text using NLP"""
        # This is a simplified version - you might want to use
        # more sophisticated NLP techniques
        # Look for titles in quotes or titles followed by (year)
        titles = re.findall(r'"([^"]*)"|\b([^,\s]+(?:\s+[^,\s]+)*?)(?:\s*\(\d{4}\))', text)
        return [t[0] or t[1] for t in titles if t[0] or t[1]]

    def _get_movie_details(self, titles: List[str]) -> List[Dict]:
        """Get movie details from movie_data service"""
        movies = []
        for title in titles:
            movie = self.movie_data.search_movies(title)
            if movie:
                movies.append(movie[0])  # Add first matching movie
        return movies

    def _enhance_response_with_movies(self, response: str, 
                                    movies: List[Dict]) -> str:
        """Enhance chatbot response with movie details"""
        if not movies:
            return response
            
        enhanced_response = response + "\n\n**Movie Details:**\n"
        for movie in movies:
            enhanced_response += f"""
            🎬 **{movie['title']}** ({movie['release_date'][:4]})
            - Rating: ⭐ {movie['vote_average']}/10
            - Overview: {movie['overview'][:100]}...
            
            """
        return enhanced_response

    def suggest_movies(self, context: str) -> List[Dict]:
        """Get movie suggestions based on conversation context"""
        prompt = f"""
        Based on the following conversation context, suggest 5 movies:
        {context}
        
        Format: Title (Year)
        """
        
        response = self.openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7
        )
        
        movie_titles = self._extract_movie_titles(
            response.choices[0].message.content)
        return self._get_movie_details(movie_titles)

    def display_chat_button(self):
        """Display floating chat button with improved visibility and error handling"""
        st.sidebar.markdown("### Chat with Movie Assistant")
        if st.sidebar.button("💬 Open Chat", use_container_width=True):
            st.session_state.show_chat = True
        
        if st.session_state.show_chat:
            with st.sidebar:
                if st.button("❌ Close Chat", use_container_width=True):
                    st.session_state.show_chat = False
                    st.rerun()
                
                # Chat container
                st.markdown("#### Movie Assistant")
                if not self.openai.api_key:
                    st.warning("Chat is operating in limited mode due to API restrictions.")
                st.markdown("---")
                
                # Display chat messages
                for message in st.session_state.chat_messages:
                    with st.chat_message(message["role"]):
                        st.markdown(message["content"])
                
                # Chat input
                prompt = st.chat_input("Ask about movies...")
                if prompt:
                    # Add user message
                    st.session_state.chat_messages.append({"role": "user", "content": prompt})
                    
                    # Get and display bot response
                    response = self.get_response(prompt)
                    st.session_state.chat_messages.append({"role": "assistant", "content": response})
                    st.rerun()

    def display_chat_dialog(self):
        """Display chat dialog"""
        # Chat container
        chat_container = st.container()
        
        with chat_container:
            # Display chat messages
            for message in st.session_state.chat_messages:
                with st.chat_message(message["role"]):
                    st.markdown(message["content"])
            
            # Chat input
            prompt = st.chat_input("Ask about movies...")
            if prompt:
                # Add user message
                st.session_state.chat_messages.append({"role": "user", "content": prompt})
                
                # Get and display bot response
                response = self.get_response(prompt)
                st.session_state.chat_messages.append({"role": "assistant", "content": response})
                st.rerun()

    def clear_chat(self):
        """Clear chat history"""
        st.session_state.chat_messages = [] 