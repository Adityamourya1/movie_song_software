import streamlit as st
from song_data import SongData

def test_spotify_connection():
    """Test Spotify API connection"""
    st.title("Spotify API Connection Test")
    
    song_data = SongData()
    
    if song_data.initialize_spotify():
        st.write("Testing search functionality...")
        results = song_data.search_songs("Test")
        
        if results:
            st.success("Search test successful!")
            st.write("Sample results:")
            for track in results[:3]:
                st.write(f"- {track['name']} by {', '.join(a['name'] for a in track['artists'])}")
        else:
            st.warning("Search returned no results")
    else:
        st.error("Failed to initialize Spotify connection")

if __name__ == "__main__":
    test_spotify_connection() 