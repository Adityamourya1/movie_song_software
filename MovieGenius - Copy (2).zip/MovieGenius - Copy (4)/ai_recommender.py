from openai import OpenAI
import streamlit as st
from datetime import datetime, timedelta
from typing import List, Dict
from sqlalchemy.orm import sessionmaker
from models import AffiliateLink
import random
import re
import requests

class AIRecommender:
    def __init__(self, movie_data):
        self.movie_data = movie_data
        try:
            self.client = OpenAI(api_key=st.secrets["OPENAI_API_KEY"])
            self.use_ai = True
        except:
            self.use_ai = False
            st.warning("OpenAI API not available. Using fallback recommendation system.")

    def natural_language_search(self, query: str) -> List[Dict]:
        """Process natural language queries for movie search"""
        if not self.use_ai:
            return self._fallback_search(query)
            
        try:
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "Extract search parameters from the query. Focus on genre, year range, rating, and other relevant criteria."},
                    {"role": "user", "content": query}
                ]
            )
            
            search_params = self._parse_search_params(response.choices[0].message.content)
            return self.movie_data.advanced_search(**search_params)
        except Exception as e:
            st.warning("Using fallback search method due to API limitations.")
            return self._fallback_search(query)

    def _fallback_search(self, query: str) -> List[Dict]:
        """Improved fallback search method when AI is unavailable"""
        query = query.lower()
        
        # Initialize search parameters
        params = {
            'genres': [],
            'year_from': None,
            'year_to': None,
            'min_rating': 0,
            'keywords': []
        }

        # Extract years and handle "last X years"
        year_pattern = r'\b(19|20)\d{2}\b'
        years = re.findall(year_pattern, query)
        
        # Handle "last X years" pattern
        last_years_pattern = r'last (\d+) years?'
        last_years_match = re.search(last_years_pattern, query)
        if last_years_match:
            num_years = int(last_years_match.group(1))
            current_year = datetime.now().year
            params['year_from'] = current_year - num_years
            params['year_to'] = current_year
        elif years:
            if 'recent' in query:
                params['year_from'] = int(years[-1]) - 5
                params['year_to'] = int(years[-1])
            else:
                params['year_from'] = int(years[0])
                params['year_to'] = int(years[-1]) if len(years) > 1 else None

        # Genre mapping with common variations
        genre_mapping = {
            'action': [28, ['action', 'fighting', 'explosive']],
            'adventure': [12, ['adventure', 'adventurous']],
            'animation': [16, ['animation', 'animated', 'anime', 'cartoon']],
            'comedy': [35, ['comedy', 'funny', 'humorous', 'hilarious']],
            'crime': [80, ['crime', 'criminal', 'detective', 'police']],
            'documentary': [99, ['documentary', 'doc']],
            'drama': [18, ['drama', 'dramatic']],
            'family': [10751, ['family', 'kid', 'children']],
            'fantasy': [14, ['fantasy', 'magical', 'magic']],
            'history': [36, ['history', 'historical', 'period']],
            'horror': [27, ['horror', 'scary', 'frightening', 'terror']],
            'music': [10402, ['music', 'musical']],
            'mystery': [9648, ['mystery', 'mysterious']],
            'romance': [10749, ['romance', 'romantic', 'love story']],
            'sci-fi': [878, ['sci-fi', 'science fiction', 'scifi', 'scientific']],
            'thriller': [53, ['thriller', 'thrilling', 'suspense', 'suspenseful']],
            'war': [10752, ['war', 'military', 'battle']],
            'western': [37, ['western', 'cowboy']]
        }

        # Extract genres
        for genre, (genre_id, keywords) in genre_mapping.items():
            if any(keyword in query for keyword in keywords):
                params['genres'].append(genre_id)

        # Quality indicators
        quality_indicators = ['best', 'top', 'great', 'excellent', 'highest rated', 'acclaimed']
        if any(indicator in query for indicator in quality_indicators):
            params['min_rating'] = 7.0

        # Extract meaningful keywords
        common_words = {'movie', 'movies', 'film', 'films', 'show', 'shows', 'the', 'a', 'an', 'and', 
                       'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'from', 
                       'up', 'about', 'into', 'over', 'after', 'want', 'looking', 'search', 'find', 
                       'show', 'me', 'get', 'like', 'last', 'year', 'years'}
        
        words = query.split()
        params['keywords'] = [word for word in words 
                             if word not in common_words 
                             and len(word) > 2 
                             and not any(word in kw for _, (_, kw) in genre_mapping.items())]

        # Get results using advanced search
        results = self.movie_data.advanced_search(**params)
        
        # If no results, try with more relaxed parameters
        if not results:
            params['min_rating'] = max(0, params['min_rating'] - 1)
            params['year_from'] = None
            params['year_to'] = None
            results = self.movie_data.advanced_search(**params)

        return results

    def mood_based_recommendations(self, mood: str) -> List[Dict]:
        """Get movie recommendations based on user's mood"""
        if not self.use_ai:
            return self._fallback_mood_recommendations(mood)
            
        mood_prompts = {
            'happy': "uplifting, comedy, feel-good movies with positive endings",
            'sad': "emotional dramas, touching stories that help process feelings",
            'thrilling': "suspenseful, action-packed movies with high stakes",
            'romantic': "love stories, romantic comedies, heartwarming relationships",
            'relaxed': "calm, easy-going films with beautiful scenery",
            'energetic': "fast-paced action movies, sports films, or music-filled adventures"
        }
        
        try:
            prompt = f"Suggest movie characteristics for {mood_prompts.get(mood.lower(), mood)}"
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a movie expert. Suggest movie characteristics that match the given mood."},
                    {"role": "user", "content": prompt}
                ]
            )
            
            characteristics = self._parse_mood_characteristics(response.choices[0].message.content)
            return self.movie_data.get_movies_by_characteristics(characteristics)
        except Exception as e:
            st.warning("Using fallback mood recommendations due to API limitations.")
            return self._fallback_mood_recommendations(mood)

    def _fallback_mood_recommendations(self, mood: str) -> List[Dict]:
        """Improved fallback mood-based recommendations"""
        mood_mappings = {
            'happy': {
                'genres': [35, 16, 10751],  # Comedy, Animation, Family
                'min_rating': 7.0,
                'keywords': ['fun', 'happy', 'comedy', 'uplifting', 'cheerful']
            },
            'sad': {
                'genres': [18, 10749],  # Drama, Romance
                'min_rating': 7.0,
                'keywords': ['emotional', 'drama', 'touching', 'moving']
            },
            'thrilling': {
                'genres': [28, 53, 9648],  # Action, Thriller, Mystery
                'min_rating': 7.0,
                'keywords': ['exciting', 'suspense', 'action', 'thrill']
            },
            'romantic': {
                'genres': [10749, 35],  # Romance, Comedy
                'min_rating': 7.0,
                'keywords': ['love', 'romance', 'romantic', 'relationship']
            },
            'relaxed': {
                'genres': [12, 16, 14],  # Adventure, Animation, Fantasy
                'min_rating': 7.0,
                'keywords': ['peaceful', 'beautiful', 'calm', 'gentle']
            },
            'energetic': {
                'genres': [28, 12, 878],  # Action, Adventure, Science Fiction
                'min_rating': 7.0,
                'keywords': ['action', 'exciting', 'fast', 'adventure']
            }
        }
        
        params = mood_mappings.get(mood.lower(), {
            'genres': [],
            'min_rating': 7.0,
            'keywords': [mood.lower()]
        })
        
        results = self.movie_data.advanced_search(**params)
        
        # If no results, try with relaxed parameters
        if not results:
            params['min_rating'] = 6.0
            results = self.movie_data.advanced_search(**params)
        
        return results

    def _parse_search_params(self, ai_response: str) -> Dict:
        """Parse AI response into search parameters"""
        try:
            # Create a more structured prompt to get parameters
            format_response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "Convert the following movie search criteria into a JSON format with keys: genres, year_from, year_to, min_rating, keywords"},
                    {"role": "user", "content": ai_response}
                ]
            )
            
            import json
            params = json.loads(format_response.choices[0].message.content)
            
            # Clean and validate parameters
            return {
                'genres': params.get('genres', []),
                'year_from': params.get('year_from', None),
                'year_to': params.get('year_to', None),
                'min_rating': params.get('min_rating', 0),
                'keywords': params.get('keywords', [])
            }
        except Exception as e:
            st.error(f"Error parsing search parameters: {str(e)}")
            return {'genres': [], 'keywords': []}

    def _parse_mood_characteristics(self, ai_response: str) -> Dict:
        """Parse AI response into movie characteristics"""
        try:
            # Create a more structured prompt to get characteristics
            format_response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "Convert the following movie characteristics into a JSON format with keys: genres, themes, tone, keywords"},
                    {"role": "user", "content": ai_response}
                ]
            )
            
            import json
            characteristics = json.loads(format_response.choices[0].message.content)
            
            return {
                'genres': characteristics.get('genres', []),
                'themes': characteristics.get('themes', []),
                'tone': characteristics.get('tone', ''),
                'keywords': characteristics.get('keywords', [])
            }
        except Exception as e:
            st.error(f"Error parsing mood characteristics: {str(e)}")
            return {'genres': [], 'keywords': []}

    def _parse_ai_response(self, response):
        # Implementation of AI response parsing
        pass

    def get_movies_by_mood(self, mood):
        return self.mood_based_recommendations(mood)