import streamlit as st
from typing import List, Dict, Optional
from datetime import datetime
from error_handler import error_logger
from exceptions import DatabaseError, ValidationError
from database import session_scope
from components import Card, ErrorBoundary, display_rating, display_timestamp
from models import Review, SongReview, User, SongLike, MovieLike

class ReviewSystem:
    def __init__(self, db_engine):
        self.db_engine = db_engine
        self._initialize_cache()

    def _initialize_cache(self):
        """Initialize review cache"""
        if 'review_cache' not in st.session_state:
            st.session_state.review_cache = {}

    def add_review(self, movie_id: int, user_id: int, rating: int, 
                  review_text: str) -> bool:
        """Add or update movie review with validation"""
        try:
            self._validate_review_input(rating, review_text)
            
            with session_scope() as session:
                # Check for existing review
                existing = session.query(Review).filter_by(
                    content_id=movie_id,
                    content_type='movie',
                    user_id=user_id
                ).first()
                
                if existing:
                    # Update existing review
                    existing.rating = rating
                    existing.review_text = review_text
                    existing.updated_at = datetime.utcnow()
                else:
                    # Create new review
                    review = Review(
                        content_id=movie_id,
                        content_type='movie',
                        user_id=user_id,
                        rating=rating,
                        review_text=review_text,
                        created_at=datetime.utcnow()
                    )
                    session.add(review)
                
                try:
                    session.commit()
                    # Clear cache for this movie
                    self._clear_movie_cache(movie_id)
                    return True
                except Exception as e:
                    session.rollback()
                    raise DatabaseError(f"Failed to save review: {str(e)}")

        except ValidationError as e:
            st.error(str(e))
            return False
        except Exception as e:
            error_logger.log_error(e, "adding review")
            st.error("Unable to save your review. Please try again.")
            return False

    def add_song_review(self, song_id: str, user_id: int, rating: int, 
                       review_text: str) -> bool:
        """Add or update song review with validation"""
        try:
            self._validate_review_input(rating, review_text)
            
            with session_scope() as session:
                # Check for existing review
                existing = session.query(SongReview).filter_by(
                    song_id=song_id,
                    user_id=user_id
                ).first()
                
                if existing:
                    # Update existing review
                    existing.rating = rating
                    existing.review_text = review_text
                    existing.updated_at = datetime.utcnow()
                else:
                    # Create new review
                    review = SongReview(
                        song_id=song_id,
                        user_id=user_id,
                        rating=rating,
                        review_text=review_text,
                        created_at=datetime.utcnow()
                    )
                    session.add(review)
                
                session.commit()
                
                # Clear cache for this song
                self._clear_song_cache(song_id)
                return True

        except ValidationError as e:
            st.error(str(e))
            return False
        except Exception as e:
            error_logger.display_error_message(
                e,
                "adding song review",
                "Unable to save your review. Please try again."
            )
            return False

    def get_movie_reviews(self, movie_id: int, include_private: bool = False) -> Dict:
        """Get all reviews for a movie with caching"""
        cache_key = f"movie_reviews_{movie_id}_{include_private}"
        
        # Check cache
        if cache_key in st.session_state.review_cache:
            return st.session_state.review_cache[cache_key]

        try:
            with session_scope() as session:
                query = session.query(Review, User).join(User).filter(
                    Review.content_id == movie_id,
                    Review.content_type == 'movie'
                )
                
                if not include_private:
                    query = query.filter(User.show_reviews == True)
                
                reviews = query.all()
                
                result = {
                    'average_rating': 0.0,
                    'total_reviews': len(reviews),
                    'rating_distribution': {1: 0, 2: 0, 3: 0, 4: 0, 5: 0},
                    'reviews': []
                }
                
                if reviews:
                    total_rating = sum(review.Review.rating for review in reviews)
                    result['average_rating'] = round(total_rating / len(reviews), 1)
                    
                    for review, user in reviews:
                        result['rating_distribution'][int(review.rating)] += 1
                        result['reviews'].append({
                            'id': review.id,
                            'username': user.username,
                            'rating': review.rating,
                            'review_text': review.review_text,
                            'created_at': review.created_at.strftime('%Y-%m-%d'),
                            'movie_id': review.content_id,
                            'is_critic': review.is_critic
                        })
                
                # Cache results
                st.session_state.review_cache[cache_key] = result
                return result

        except Exception as e:
            error_logger.log_error(e, "getting movie reviews")
            return {
                'average_rating': 0.0,
                'total_reviews': 0,
                'rating_distribution': {1: 0, 2: 0, 3: 0, 4: 0, 5: 0},
                'reviews': []
            }

    def get_song_reviews(self, song_id: str, include_private: bool = False) -> Dict:
        """Get all reviews for a song with caching"""
        cache_key = f"song_reviews_{song_id}_{include_private}"
        
        # Check cache
        if cache_key in st.session_state.review_cache:
            return st.session_state.review_cache[cache_key]

        try:
            with session_scope() as session:
                query = session.query(SongReview, User).join(User).filter(
                    SongReview.song_id == song_id
                )
                
                if not include_private:
                    query = query.filter(User.show_reviews == True)
                
                reviews = query.all()
                
                result = {
                    'average_rating': 0.0,
                    'total_reviews': len(reviews),
                    'rating_distribution': {1: 0, 2: 0, 3: 0, 4: 0, 5: 0},
                    'reviews': []
                }
                
                if reviews:
                    total_rating = sum(review.SongReview.rating for review in reviews)
                    result['average_rating'] = round(total_rating / len(reviews), 1)
                    
                    for review, user in reviews:
                        result['rating_distribution'][review.rating] += 1
                        result['reviews'].append({
                            'id': review.id,
                            'user': user.username,
                            'rating': review.rating,
                            'review_text': review.review_text,
                            'created_at': review.created_at,
                            'updated_at': review.updated_at
                        })
                
                # Cache results
                st.session_state.review_cache[cache_key] = result
                return result

        except Exception as e:
            error_logger.log_error(e, "getting song reviews")
            return {
                'average_rating': 0.0,
                'total_reviews': 0,
                'rating_distribution': {1: 0, 2: 0, 3: 0, 4: 0, 5: 0},
                'reviews': []
            }

    def get_user_reviews(self, user_id: int) -> List[Dict]:
        """Get all reviews by a user"""
        try:
            with session_scope() as session:
                reviews = session.query(Review).filter_by(
                    user_id=user_id,
                    content_type='movie'
                ).all()
                return [
                    {
                        'movie_id': review.content_id,
                        'rating': review.rating,
                        'review_text': review.review_text,
                        'created_at': review.created_at
                    }
                    for review in reviews
                ]
        except Exception as e:
            error_logger.log_error(e, "fetching user reviews")
            return []

    def display_reviews(self, item_id: str, is_song: bool = False):
        """Display reviews using reusable components"""
        with ErrorBoundary():
            reviews = (self.get_song_reviews(item_id) if is_song 
                      else self.get_movie_reviews(item_id))
            
            # Display average rating
            st.subheader("Reviews & Ratings")
            col1, col2 = st.columns([1, 2])
            
            with col1:
                display_rating(reviews['average_rating'])
                st.write(f"{reviews['total_reviews']} total reviews")
            
            with col2:
                # Display rating distribution
                for rating in range(5, 0, -1):
                    count = reviews['rating_distribution'][rating]
                    percentage = (count / reviews['total_reviews'] * 100) if reviews['total_reviews'] > 0 else 0
                    st.write(f"{rating}★ {count:3d} ({percentage:2.0f}%)")
            
            # Display individual reviews
            st.subheader("User Reviews")
            if reviews['reviews']:
                for review in reviews['reviews']:
                    Card(
                        title=f"Review by {review['user']}",
                        content=review['review_text'],
                        footer=self._format_review_footer(review)
                    ).render()
            else:
                st.info("No reviews yet. Be the first to review!")

    def toggle_movie_like(self, movie_id: int, user_id: int) -> bool:
        """Toggle like status for a movie"""
        try:
            with session_scope() as session:
                existing_like = session.query(MovieLike).filter_by(
                    user_id=user_id,
                    movie_id=movie_id
                ).first()
                
                if existing_like:
                    # Unlike: remove existing like
                    session.delete(existing_like)
                    session.commit()
                    return False
                else:
                    # Like: add new like
                    new_like = MovieLike(user_id=user_id, movie_id=movie_id)
                    session.add(new_like)
                    session.commit()
                    return True
                
        except Exception as e:
            error_logger.log_error(e, "toggling movie like")
            return False

    def get_movie_like_status(self, movie_id: int, user_id: int) -> bool:
        """Check if a user has liked a movie"""
        try:
            with session_scope() as session:
                like_exists = session.query(MovieLike).filter_by(
                    user_id=user_id,
                    movie_id=movie_id
                ).first() is not None
                return like_exists
        except Exception as e:
            error_logger.log_error(e, "checking movie like status")
            return False

    def get_movie_likes_count(self, movie_id: int) -> int:
        """Get the total number of likes for a movie"""
        try:
            with session_scope() as session:
                count = session.query(MovieLike).filter_by(movie_id=movie_id).count()
                return count
        except Exception as e:
            error_logger.log_error(e, "getting movie likes count")
            return 0

    def toggle_song_like(self, song_id: str, user_id: int) -> bool:
        """Toggle like status for a song"""
        try:
            with session_scope() as session:
                existing_like = session.query(SongLike).filter_by(
                    song_id=song_id,
                    user_id=user_id
                ).first()
                
                if existing_like:
                    session.delete(existing_like)
                    session.commit()
                    return False  # Unlike
                else:
                    new_like = SongLike(
                        song_id=song_id,
                        user_id=user_id
                    )
                    session.add(new_like)
                    session.commit()
                    return True  # Like
                    
        except Exception as e:
            error_logger.log_error(e, "toggling song like")
            return None

    def get_song_like_status(self, song_id: str, user_id: int) -> bool:
        """Check if a user has liked a song"""
        try:
            with session_scope() as session:
                existing_like = session.query(SongLike).filter_by(
                    song_id=song_id,
                    user_id=user_id
                ).first()
                return bool(existing_like)
        except Exception as e:
            error_logger.log_error(e, "checking song like status")
            return False

    def get_song_likes_count(self, song_id: str) -> int:
        """Get the number of likes for a song"""
        try:
            with session_scope() as session:
                return session.query(SongLike).filter_by(song_id=song_id).count()
        except Exception as e:
            error_logger.log_error(e, "getting song likes count")
            return 0

    def _validate_review_input(self, rating: int, review_text: str):
        """Validate review input"""
        if not isinstance(rating, (int, float)) or rating < 1 or rating > 5:
            raise ValidationError("Rating must be between 1 and 5")
        if not review_text or len(review_text.strip()) < 1:
            raise ValidationError("Review text cannot be empty")
        if len(review_text) > 2000:
            raise ValidationError("Review text cannot exceed 2000 characters")

    def _clear_movie_cache(self, movie_id: int):
        """Clear cached reviews for a movie"""
        keys_to_remove = []
        for key in st.session_state.review_cache:
            if key.startswith(f"movie_reviews_{movie_id}"):
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            del st.session_state.review_cache[key]

    def _clear_song_cache(self, song_id: str):
        """Clear cached reviews for a song"""
        keys_to_clear = [
            k for k in st.session_state.review_cache.keys()
            if k.startswith(f"song_reviews_{song_id}")
        ]
        for key in keys_to_clear:
            del st.session_state.review_cache[key]

    def _format_review_footer(self, review: Dict) -> str:
        """Format review footer with timestamps"""
        footer = [f"Rating: {'⭐' * review['rating']}"]
        if review.get('updated_at'):
            footer.append(f"Updated: {review['updated_at'].strftime('%Y-%m-%d %H:%M')}")
        else:
            footer.append(f"Posted: {review['created_at'].strftime('%Y-%m-%d %H:%M')}")
        return " | ".join(footer)