import streamlit as st
from sqlalchemy import create_engine, text
from models import Base
import os
from database import DATABASE_URL

def init_database():
    """Initialize the database with proper schema"""
    try:
        # Make sure data directory exists
        os.makedirs('data', exist_ok=True)
        
        # Use the centralized database URL
        engine = create_engine(
            DATABASE_URL,
            pool_pre_ping=True,
            pool_recycle=300,
            pool_size=5,
            max_overflow=10,
            connect_args={'check_same_thread': False}
        )
        
        # Create tables only if they don't exist
        Base.metadata.create_all(engine)
        
        # Verify connection by executing a simple query using text()
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
            conn.commit()
        
        print("Database initialized successfully!")
        st.success("Database initialized successfully!")
        return engine
        
    except Exception as e:
        error_msg = f"Error initializing database: {str(e)}"
        print(error_msg)
        st.error(error_msg)
        return None

if __name__ == "__main__":
    init_database()