import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
from functools import lru_cache
import requests

class MovieRecommender:
    def __init__(self, movie_data):
        self.movie_data = movie_data
        self.movies_df = None
        self.tfidf_matrix = None
        self._initialize_cache()
        self._refresh_data()

    def _initialize_cache(self):
        """Initialize cache with TTL"""
        if 'movie_recommendations' not in st.session_state:
            st.session_state.movie_recommendations = {}
        if 'cache_timestamp' not in st.session_state:
            st.session_state.cache_timestamp = datetime.now()
        if 'cache_ttl' not in st.session_state:
            st.session_state.cache_ttl = timedelta(hours=1)

    @lru_cache(maxsize=100)
    def get_recommendations(self, user_id: int, n_recommendations: int = 10) -> List[Dict]:
        """Get movie recommendations with improved caching and error handling"""
        try:
            cache_key = f"user_{user_id}_{datetime.now().strftime('%Y%m%d')}"
            
            # Check cache validity
            if self._is_cache_valid(cache_key):
                return st.session_state.movie_recommendations[cache_key]['data']

            # Get user's watched and liked movies
            watched_movies = self._get_user_watched_movies(user_id)
            if not watched_movies:
                return self._get_default_recommendations(n_recommendations)

            recommendations = self._generate_recommendations(watched_movies, n_recommendations)
            self._cache_recommendations(cache_key, recommendations)
            
            return recommendations

        except Exception as e:
            st.error(f"Error in recommendation generation: {str(e)}")
            return self._get_default_recommendations(n_recommendations)

    def _is_cache_valid(self, cache_key: str) -> bool:
        """Check if cached recommendations are still valid"""
        if cache_key in st.session_state.movie_recommendations:
            cache_age = datetime.now() - st.session_state.movie_recommendations[cache_key]['timestamp']
            return cache_age < st.session_state.cache_ttl
        return False

    def _generate_recommendations(self, watched_movies: List[Dict], n_recommendations: int) -> List[Dict]:
        """Generate personalized recommendations"""
        try:
            all_recommendations = []
            seen_ids = set(movie['id'] for movie in watched_movies)

            for movie in watched_movies:
                similar_movies = self._get_similar_movies(movie['id'])
                for rec in similar_movies:
                    if rec['id'] not in seen_ids:
                        rec['similarity_score'] = self._calculate_similarity_score(movie, rec)
                        all_recommendations.append(rec)
                        seen_ids.add(rec['id'])

            # Sort and diversify recommendations
            return self._diversify_recommendations(all_recommendations, n_recommendations)

        except Exception as e:
            st.error(f"Error generating recommendations: {str(e)}")
            return []

    def _calculate_similarity_score(self, source_movie: Dict, target_movie: Dict) -> float:
        """Calculate enhanced similarity score between movies"""
        try:
            base_score = 0.0
            weights = {
                'genre': 0.4,
                'rating': 0.2,
                'popularity': 0.2,
                'recency': 0.2
            }

            if source_movie.get('genre_ids') and target_movie.get('genre_ids'):
                genre_similarity = len(
                    set(source_movie['genre_ids']) & 
                    set(target_movie['genre_ids'])
                ) / len(
                    set(source_movie['genre_ids']) | 
                    set(target_movie['genre_ids'])
                )
                base_score += weights['genre'] * genre_similarity

            # Rating similarity
            if 'vote_average' in source_movie and 'vote_average' in target_movie:
                rating_diff = abs(source_movie['vote_average'] - target_movie['vote_average'])
                rating_sim = max(0, 1 - (rating_diff / 10))
                base_score += weights['rating'] * rating_sim

            # Popularity similarity
            if 'popularity' in source_movie and 'popularity' in target_movie:
                pop_ratio = min(source_movie['popularity'], target_movie['popularity']) / \
                           max(source_movie['popularity'], target_movie['popularity'])
                base_score += weights['popularity'] * pop_ratio

            # Recency factor
            if 'release_date' in source_movie and 'release_date' in target_movie:
                year_diff = abs(
                    int(source_movie['release_date'][:4]) - 
                    int(target_movie['release_date'][:4])
                )
                recency_score = 1 / (1 + year_diff/5)
                base_score += weights['recency'] * recency_score

            return base_score

        except Exception:
            return 0.0

    def _diversify_recommendations(self, recommendations: List[Dict], n: int) -> List[Dict]:
        """Ensure diverse recommendations"""
        if not recommendations:
            return []

        diverse_recs = []
        genre_counts = {}
        
        for movie in sorted(recommendations, key=lambda x: x.get('similarity_score', 0), reverse=True):
            movie_genres = set(movie.get('genre_ids', []))
            
            # Check if we're not over-representing any genre
            genre_ok = True
            for genre in movie_genres:
                if genre_counts.get(genre, 0) >= n/3:  # No more than 1/3 of recs from same genre
                    genre_ok = False
                    break
                    
            if genre_ok:
                diverse_recs.append(movie)
                for genre in movie_genres:
                    genre_counts[genre] = genre_counts.get(genre, 0) + 1
                    
            if len(diverse_recs) >= n:
                break
                
        return diverse_recs

    def _get_default_recommendations(self, n: int) -> List[Dict]:
        """Get default recommendations for new users"""
        try:
            trending = self.movie_data.get_trending_movies()
            top_rated = self.movie_data.get_top_rated_movies()
            
            # Combine and deduplicate
            seen_ids = set()
            defaults = []
            
            for movie in trending + top_rated:
                if movie['id'] not in seen_ids and len(defaults) < n:
                    seen_ids.add(movie['id'])
                    defaults.append(movie)
                    
            return defaults[:n]
            
        except Exception as e:
            st.error(f"Error getting default recommendations: {str(e)}")
            return []

    def _cache_recommendations(self, cache_key: str, recommendations: List[Dict]):
        """Cache recommendations with timestamp"""
        st.session_state.movie_recommendations[cache_key] = {
            'data': recommendations,
            'timestamp': datetime.now()
        }

    def _get_user_watched_movies(self, user_id: int) -> List[Dict]:
        """Get list of movies watched by user"""
        try:
            # For now, return some trending movies as sample watched movies
            return self.movie_data.get_trending_movies()[:5]
        except Exception as e:
            st.error(f"Error getting watched movies: {str(e)}")
            return []

    def _get_similar_movies(self, movie_id: int) -> List[Dict]:
        """Get similar movies based on content similarity"""
        try:
            return self.movie_data.get_similar_movies(movie_id)
        except Exception as e:
            st.error(f"Error getting similar movies: {str(e)}")
            return []

    def _refresh_data(self):
        """Refresh the movie database"""
        # Check if refresh is needed
        if (st.session_state.last_refresh and 
            datetime.now() - st.session_state.last_refresh < st.session_state.cache_duration):
            return

        movies = []
        total_pages = 5  # Get first 5 pages of popular movies

        for page in range(1, total_pages + 1):
            url = f"{self.movie_data.base_url}/movie/popular"
            params = {
                "api_key": self.movie_data.api_key,
                "page": page,
                "language": "en-US",
                "region": "IN"
            }

            try:
                response = requests.get(url, params=params)
                response.raise_for_status()
                movies.extend(response.json()['results'])
            except requests.exceptions.RequestException as e:
                st.error(f"Error fetching movies: {str(e)}")
                return

        if movies:
            self.movies_df = pd.DataFrame(movies)
            st.session_state.movies_df = self.movies_df
            st.session_state.last_refresh = datetime.now()
            self._prepare_features()

    def _prepare_features(self):
        """Prepare movie features for similarity calculation"""
        if self.movies_df is None:
            return

        # Combine relevant features
        self.movies_df['features'] = self.movies_df.apply(
            lambda x: ' '.join([
                str(x['overview'] or ''),
                str(x['title'] or ''),
                ' '.join(str(x['genre_ids'])),
                str(x['original_language'] or '')
            ]), axis=1
        )

        # Create TF-IDF matrix
        tfidf = TfidfVectorizer(stop_words='english')
        self.tfidf_matrix = tfidf.fit_transform(self.movies_df['features'])
        st.session_state.tfidf_matrix = self.tfidf_matrix