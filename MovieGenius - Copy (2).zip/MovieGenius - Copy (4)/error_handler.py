import logging
import traceback
from datetime import datetime
import streamlit as st
from typing import Optional, Dict, Any
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Ensure logs directory exists
Path("logs").mkdir(exist_ok=True)

class ErrorLogger:
    def __init__(self):
        self.file_handler = logging.FileHandler(
            f"logs/moviegenius_{datetime.now().strftime('%Y%m%d')}.log"
        )
        self.file_handler.setFormatter(
            logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        )
        logger.addHandler(self.file_handler)

    def log_error(self, error: Exception, context: str, user_id: Optional[int] = None) -> str:
        """Log an error with context and return error ID"""
        error_id = datetime.now().strftime('%Y%m%d_%H%M%S')
        error_details = {
            'error_id': error_id,
            'timestamp': datetime.now().isoformat(),
            'error_type': type(error).__name__,
            'error_message': str(error),
            'context': context,
            'user_id': user_id,
            'traceback': traceback.format_exc()
        }
        
        logger.error(f"Error ID: {error_id}")
        logger.error(f"Context: {context}")
        logger.error(f"Error: {str(error)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        
        self._store_error(error_details)
        return error_id

    def _store_error(self, error_details: Dict[str, Any]):
        """Store error details in session state for tracking"""
        if 'error_log' not in st.session_state:
            st.session_state.error_log = []
        st.session_state.error_log.append(error_details)
        
        # Keep only last 100 errors
        if len(st.session_state.error_log) > 100:
            st.session_state.error_log = st.session_state.error_log[-100:]

    def get_error_details(self, error_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve error details by error ID"""
        if 'error_log' in st.session_state:
            for error in st.session_state.error_log:
                if error['error_id'] == error_id:
                    return error
        return None

    def display_error_message(self, error: Exception, context: str, 
                            user_friendly_message: Optional[str] = None):
        """Display user-friendly error message and log error"""
        error_id = self.log_error(error, context)
        
        if user_friendly_message:
            st.error(f"""
                {user_friendly_message}
                
                Error ID: {error_id}
                If this problem persists, please contact support with this Error ID.
            """)
        else:
            st.error(f"""
                An error occurred while {context}.
                
                Error ID: {error_id}
                If this problem persists, please contact support with this Error ID.
            """)

error_logger = ErrorLogger()