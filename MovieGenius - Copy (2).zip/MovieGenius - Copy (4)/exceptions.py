class MovieGeniusError(Exception):
    """Base exception class for MovieGenius application"""
    def __init__(self, message: str, error_code: str = None):
        self.message = message
        self.error_code = error_code
        super().__init__(self.message)

class DatabaseError(MovieGeniusError):
    """Raised when database operations fail"""
    pass

class AuthenticationError(MovieGeniusError):
    """Raised when authentication operations fail"""
    pass

class APIError(MovieGeniusError):
    """Raised when external API calls fail"""
    def __init__(self, message: str, service_name: str, status_code: int = None):
        self.service_name = service_name
        self.status_code = status_code
        error_code = f"API_{service_name}_{status_code}" if status_code else f"API_{service_name}"
        super().__init__(message, error_code)

class RecommendationError(MovieGeniusError):
    """Raised when recommendation generation fails"""
    pass

class ValidationError(MovieGeniusError):
    """Raised when input validation fails"""
    pass

class CacheError(MovieGeniusError):
    """Raised when cache operations fail"""
    pass

class ResourceNotFoundError(MovieGeniusError):
    """Raised when a requested resource is not found"""
    pass

class RateLimitError(MovieGeniusError):
    """Raised when rate limits are exceeded"""
    def __init__(self, message: str, retry_after: int = None):
        self.retry_after = retry_after
        super().__init__(message, "RATE_LIMIT_EXCEEDED")