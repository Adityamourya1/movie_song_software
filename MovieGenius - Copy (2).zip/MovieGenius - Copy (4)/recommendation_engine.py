import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import requests
import streamlit as st
from datetime import datetime

class MovieRecommender:
    def __init__(self, movie_data):
        self.movie_data = movie_data
        self.movies_df = None
        self.tfidf_matrix = None
        self._initialize_cache()
        self.refresh_data()

    def _initialize_cache(self):
        """Initialize cache for recommendations"""
        if 'recommender_cache' not in st.session_state:
            st.session_state.recommender_cache = {}

    @st.cache_data(ttl=3600)  # Cache for 1 hour
    def refresh_data(_self):
        """Refresh the movie database with caching"""
        movies = []
        total_pages = 5  # Get first 5 pages of popular movies

        for page in range(1, total_pages + 1):
            url = f"{_self.movie_data.base_url}/movie/popular"
            params = {
                "api_key": _self.movie_data.api_key,
                "page": page,
                "language": "en-US",
                "region": "IN"  # Include Indian region specifically
            }

            try:
                response = requests.get(url, params=params)
                response.raise_for_status()
                movies.extend(response.json()['results'])
            except requests.exceptions.RequestException as e:
                st.error(f"Error fetching movies: {str(e)}")
                return

        if movies:
            _self.movies_df = pd.DataFrame(movies)
            _self._prepare_features()

    def _prepare_features(self):
        """Prepare movie features for recommendation"""
        if self.movies_df is None or self.movies_df.empty:
            return

        # Create combined features for better recommendations
        self.movies_df['features'] = self.movies_df.apply(self._create_feature_soup, axis=1)

        # Calculate popularity score
        vote_counts = self.movies_df['vote_count']
        vote_averages = self.movies_df['vote_average']

        # Calculate weighted rating
        m = vote_counts.quantile(0.60)
        C = vote_averages.mean()
        self.movies_df['weighted_rating'] = (vote_counts / (vote_counts + m) * vote_averages + 
                                           m / (m + vote_counts) * C)

        # Enhanced TF-IDF matrix with more sophisticated parameters
        tfidf = TfidfVectorizer(
            stop_words='english',
            max_features=10000,  # Increased feature set
            ngram_range=(1, 4),  # Include up to 4-grams for better phrase matching
            min_df=3,  # Slightly higher minimum document frequency
            max_df=0.90,  # More stringent maximum document frequency
            analyzer='word',
            token_pattern=r'(?u)\b[\w\'-]+\b',  # Better word tokenization including hyphens
            use_idf=True,
            smooth_idf=True,
            sublinear_tf=True  # Apply sublinear scaling to term frequencies
        )

        try:
            self.tfidf_matrix = tfidf.fit_transform(self.movies_df['features'].fillna(''))
        except Exception as e:
            st.error(f"Error creating TF-IDF matrix: {str(e)}")
            self.tfidf_matrix = None

    def _create_feature_soup(self, x):
        """Create a rich feature set for each movie with advanced factors"""
        features = []

        # Title features with higher weight for exact matching
        if x.get('title'):
            features.extend([x['title']] * 4)
            # Add title words separately for partial matching
            title_words = x['title'].lower().split()
            features.extend(title_words * 2)

        # Enhanced overview processing with key themes extraction
        if x.get('overview'):
            overview = x['overview'].lower()
            features.extend([overview] * 2)

            # Identify key themes and story elements
            story_indicators = ['revenge', 'love', 'war', 'family', 'survival', 
                              'friendship', 'betrayal', 'adventure', 'mystery',
                              'coming-of-age', 'redemption', 'sacrifice']
            for theme in story_indicators:
                if theme in overview:
                    features.extend([f"theme_{theme}"] * 3)

        # Genre processing with sophisticated combinations
        genre_ids = x.get('genre_ids', [])
        if genre_ids:
            genre_names = []
            for genre_id in genre_ids:
                for genre_name, g_id in self.movie_data.genres.items():
                    if g_id == genre_id:
                        genre_names.append(genre_name)
                        # Add weighted genre importance
                        if genre_name.lower() in ['drama', 'action', 'thriller']:
                            features.extend([genre_name] * 4)
                        else:
                            features.extend([genre_name] * 3)

            # Add genre combinations for multi-genre matching
            for i, genre1 in enumerate(genre_names):
                for genre2 in genre_names[i+1:]:
                    features.append(f"{genre1}_{genre2}_combo")

        # Add release year with context
        if x.get('release_date'):
            try:
                year = str(datetime.strptime(x['release_date'], '%Y-%m-%d').year)
                features.append(f"year_{year}")  # Add year context
                # Add decade for broader matching
                decade = f"{year[:3]}0s"
                features.append(f"decade_{decade}")
            except (ValueError, TypeError):
                pass

        # Add popularity indicators
        if x.get('popularity'):
            if x['popularity'] > 20:
                features.append("popular_movie")
            if x['popularity'] > 50:
                features.append("highly_popular")

        # Add rating indicators
        if x.get('vote_average'):
            if x['vote_average'] >= 7:
                features.append("high_rated")
            if x['vote_average'] >= 8:
                features.append("top_rated")

        return ' '.join(features)

    @st.cache_data(ttl=1800)  # Cache for 30 minutes
    def get_recommendations(_self, movie_id, n_recommendations=5):
        """Get highly personalized movie recommendations"""
        try:
            if _self.movies_df is None or _self.tfidf_matrix is None:
                return []

            # Find the movie in our dataframe
            movie_idx = _self.movies_df[_self.movies_df['id'] == movie_id].index[0]
            source_movie = _self.movies_df.iloc[movie_idx]

            # Calculate content-based similarity scores
            cosine_sim = cosine_similarity(
                _self.tfidf_matrix[movie_idx:movie_idx+1],
                _self.tfidf_matrix
            ).flatten()

            # Get source movie's key attributes
            movie_genres = set(source_movie['genre_ids'])
            movie_year = int(source_movie['release_date'][:4]) if source_movie['release_date'] else 0
            movie_language = source_movie.get('original_language', '')
            movie_popularity = source_movie.get('popularity', 0)
            movie_vote_avg = source_movie.get('vote_average', 0)

            # Advanced similarity calculation with comprehensive feature analysis
            similar_scores = []
            for idx, content_sim in enumerate(cosine_sim):
                if idx != movie_idx:
                    movie = _self.movies_df.iloc[idx]

                    # Deep content analysis (35%)
                    content_weight = 0.35
                    plot_similarity = content_sim
                    keyword_match = self._calculate_keyword_similarity(source_movie, movie)
                    final_sim = content_weight * (0.7 * plot_similarity + 0.3 * keyword_match)

                    # Genre and subgenre analysis (25%)
                    genre_weight = 0.25
                    curr_genres = set(movie['genre_ids'])
                    genre_overlap = len(movie_genres.intersection(curr_genres)) / max(len(movie_genres), 1)
                    subgenre_score = self._calculate_subgenre_score(movie_genres, curr_genres)
                    final_sim += genre_weight * (0.6 * genre_overlap + 0.4 * subgenre_score)

                    # Production and crew similarity (15%)
                    production_weight = 0.15
                    director_match = self._check_director_overlap(source_movie, movie)
                    production_match = self._check_production_overlap(source_movie, movie)
                    final_sim += production_weight * (0.7 * director_match + 0.3 * production_match)

                    # Audience reception patterns (15%)
                    audience_weight = 0.15
                    rating_similarity = 1 - abs(movie['vote_average'] - movie_vote_avg) / 10
                    popularity_ratio = min(movie['popularity'], movie_popularity) / max(movie['popularity'], movie_popularity)
                    vote_count_ratio = min(movie['vote_count'], source_movie['vote_count']) / max(movie['vote_count'], source_movie['vote_count'])
                    final_sim += audience_weight * (0.4 * rating_similarity + 0.3 * popularity_ratio + 0.3 * vote_count_ratio)

                    # Time relevance and trends (10%)
                    time_weight = 0.10
                    year_diff = abs(int(movie['release_date'][:4]) - movie_year) if movie['release_date'] else 20
                    recency_score = 1 / (1 + year_diff/5)  # Sharper decay for older movies
                    trend_score = self._calculate_trend_score(movie)
                    final_sim += time_weight * (0.6 * recency_score + 0.4 * trend_score)

                    similar_scores.append((idx, final_sim))

            # Sort by final similarity score
            similar_scores = sorted(similar_scores, key=lambda x: x[1], reverse=True)

            # Get top N recommendations with enhanced diversity
            recommendations = []
            used_genres = set()
            idx = 0

            while len(recommendations) < n_recommendations and idx < len(similar_scores):
                movie_idx = similar_scores[idx][0]
                movie = _self.movies_df.iloc[movie_idx].to_dict()

                # Ensure genre diversity in recommendations
                movie_genres = set(movie['genre_ids'])
                if not movie_genres.issubset(used_genres):
                    recommendations.append(movie)
                    used_genres.update(movie_genres)

                idx += 1

            # Add similarity scores and match reasons
            for rec, (_, score) in zip(recommendations, similar_scores[:n_recommendations]):
                rec['similarity_score'] = round(score * 100, 1)
                rec['match_reason'] = _self._get_match_reason(
                    _self.movies_df.iloc[movie_idx],
                    rec
                )

            return recommendations

        except Exception as e:
            st.error(f"Error generating recommendations: {str(e)}")
            return []

    def _get_match_reason(self, source_movie, recommended_movie):
        """Generate a human-readable match reason"""
        reasons = []

        # Check genre overlap
        source_genres = set(source_movie['genre_ids'])
        rec_genres = set(recommended_movie['genre_ids'])
        common_genres = source_genres.intersection(rec_genres)

        if common_genres:
            genre_names = []
            for genre_id in common_genres:
                for name, gid in self.movie_data.genres.items():
                    if gid == genre_id:
                        genre_names.append(name.title())
            if genre_names:
                reasons.append(f"Similar genres: {', '.join(genre_names[:2])}")

        # Check release year proximity
        year_diff = abs(
            int(source_movie['release_date'][:4]) - 
            int(recommended_movie['release_date'][:4])
        ) if source_movie['release_date'] and recommended_movie['release_date'] else 10
        if year_diff <= 5:
            reasons.append("Released in similar time period")

        # Check rating similarity
        if abs(source_movie['vote_average'] - recommended_movie['vote_average']) <= 1:
            reasons.append("Similar audience rating")

        # Add popularity reason if both are highly rated
        if source_movie['vote_average'] >= 7 and recommended_movie['vote_average'] >= 7:
            reasons.append("Both highly rated")

        return " • ".join(reasons[:3])

    def _calculate_keyword_similarity(self, movie1, movie2):
        """Calculate keyword similarity between movies"""
        keywords1 = set(movie1.get('overview', '').lower().split())
        keywords2 = set(movie2.get('overview', '').lower().split())
        intersection = len(keywords1.intersection(keywords2))
        union = len(keywords1.union(keywords2))
        return intersection / union if union > 0 else 0

    def _calculate_subgenre_score(self, genres1, genres2):
        """Calculate detailed genre similarity"""
        if not genres1 or not genres2:
            return 0
        
        # Weight common genres by their specificity
        genre_weights = {
            28: 0.8,  # Action
            12: 0.7,  # Adventure
            16: 0.9,  # Animation
            35: 0.6,  # Comedy
            80: 0.9,  # Crime
            99: 0.9,  # Documentary
            18: 0.7,  # Drama
            10751: 0.8,  # Family
            14: 0.9,  # Fantasy
            36: 0.9,  # History
            27: 0.9,  # Horror
            10402: 0.9,  # Music
            9648: 0.8,  # Mystery
            10749: 0.7,  # Romance
            878: 0.9,  # Science Fiction
            10770: 0.6,  # TV Movie
            53: 0.8,  # Thriller
            10752: 0.9,  # War
            37: 0.9   # Western
        }
        
        score = 0
        for genre in genres1.intersection(genres2):
            score += genre_weights.get(genre, 0.5)
            
        return min(score / max(len(genres1), len(genres2)), 1.0)

    def _check_director_overlap(self, movie1, movie2):
        """Check director similarity"""
        directors1 = set(c['name'] for c in movie1.get('crew', []) if c.get('job') == 'Director')
        directors2 = set(c['name'] for c in movie2.get('crew', []) if c.get('job') == 'Director')
        return 1.0 if directors1.intersection(directors2) else 0.2

    def _check_production_overlap(self, movie1, movie2):
        """Check production company overlap"""
        companies1 = set(c['name'] for c in movie1.get('production_companies', []))
        companies2 = set(c['name'] for c in movie2.get('production_companies', []))
        return len(companies1.intersection(companies2)) / max(len(companies1), len(companies2)) if companies1 and companies2 else 0.3

    def _calculate_trend_score(self, movie):
        """Calculate movie trend score based on release date and popularity"""
        if not movie.get('release_date'):
            return 0.5
            
        release_date = datetime.strptime(movie['release_date'], '%Y-%m-%d')
        days_since_release = (datetime.now() - release_date).days
        
        # Recent movies get higher scores
        recency_score = 1.0 / (1 + days_since_release/365)
        
        # Popular movies get higher scores
        popularity_score = min(movie.get('popularity', 0) / 100, 1.0)
        
        return 0.7 * recency_score + 0.3 * popularity_score