from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, Boolean, DateTime, Text
from sqlalchemy.exc import OperationalError
from models import Base, WatchlistItem, User
import streamlit as st
import os
from datetime import datetime
from database import DATABASE_URL

def add_is_critic_column():
    """Add is_critic column to movie_reviews table"""
    try:
        engine = create_engine(DATABASE_URL)
        metadata = MetaData()
        
        # Add is_critic column if it doesn't exist
        with engine.connect() as conn:
            if not engine.dialect.has_column('movie_reviews', 'is_critic'):
                conn.execute('ALTER TABLE movie_reviews ADD COLUMN is_critic BOOLEAN DEFAULT false')
                st.success("Added is_critic column to movie_reviews table")
    except Exception as e:
        st.error(f"Error adding is_critic column: {str(e)}")

def migrate_database():
    """Run database migrations to add new columns"""
    try:
        # Create database engine using the centralized URL
        engine = create_engine(DATABASE_URL)
        metadata = MetaData()

        # Create a temporary table with all columns
        temp_users = Table(
            'users_new', metadata,
            Column('id', Integer, primary_key=True),
            Column('username', String(50), unique=True, nullable=False),
            Column('email', String(120), unique=True, nullable=False),
            Column('password_hash', String(200), nullable=False),
            Column('bio', Text),
            Column('profile_picture', String(200)),
            Column('is_active', Boolean, default=True, nullable=False),
            Column('created_at', DateTime, default=datetime.utcnow),
            Column('last_login', DateTime),
            Column('session_id', String(36), unique=True),
            Column('is_admin', Boolean, default=False),
            Column('email_notifications', Boolean, default=True),
            Column('is_public', Boolean, default=False),
            Column('show_reviews', Boolean, default=True),
            Column('show_playlists', Boolean, default=True),
            Column('show_mature_content', Boolean, default=False)
        )

        with engine.connect() as conn:
            # Create new table
            metadata.create_all(engine)
            
            # Copy data from old table to new table if it exists
            if engine.dialect.has_table(engine, 'users'):
                conn.execute("""
                    INSERT INTO users_new (
                        id, username, email, password_hash, is_active, 
                        created_at, last_login, session_id, is_admin
                    )
                    SELECT 
                        id, username, email, password_hash, is_active, 
                        created_at, last_login, session_id, is_admin
                    FROM users
                """)
                
                # Drop old table
                conn.execute("DROP TABLE users")
            
            # Rename new table to users
            conn.execute("ALTER TABLE users_new RENAME TO users")
            
        st.success("Database migration completed successfully!")
        return True
        
    except Exception as e:
        st.error(f"Error during migration: {str(e)}")
        return False

def init_database():
    """Initialize the database and run migrations"""
    try:
        # Create database engine
        engine = create_engine(DATABASE_URL)
        
        # Create all tables
        Base.metadata.create_all(engine)
        
        # Run migrations
        migrate_database()
        
        return engine
        
    except Exception as e:
        st.error(f"Error initializing database: {str(e)}")
        return None

def run_migrations():
    """Run any necessary database migrations"""
    try:
        engine = create_engine(DATABASE_URL)
        
        # Add new migrations here as needed
        add_song_likes_table()
        
        st.success("Migrations completed successfully!")
        
    except Exception as e:
        st.error(f"Error running migrations: {str(e)}")

def reset_database():
    """Reset the database (for development only)"""
    try:
        engine = create_engine(DATABASE_URL)
        Base.metadata.drop_all(engine)
        Base.metadata.create_all(engine)
        st.success("Database reset successfully!")
        
    except Exception as e:
        st.error(f"Error resetting database: {str(e)}")

def add_song_likes_table():
    """Add song_likes table if it doesn't exist"""
    try:
        engine = create_engine(DATABASE_URL)
        Base.metadata.create_all(engine)
        st.success("Song likes table created successfully!")
    except Exception as e:
        st.error(f"Error creating song likes table: {str(e)}")