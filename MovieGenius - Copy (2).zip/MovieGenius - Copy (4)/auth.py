import streamlit as st
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import os
import pickle
from datetime import datetime, timedelta
import jwt
from werkzeug.security import generate_password_hash, check_password_hash
from models import User, Base
from sqlalchemy.orm import sessionmaker, declarative_base, Session
from sqlalchemy import create_engine, Column, Integer, String, Boolean, DateTime
import bcrypt
import uuid
import secrets
from typing import Optional, Dict
from database import get_db_session

Base = declarative_base()

class Auth:
    def __init__(self, db_engine):
        self.engine = db_engine
        self._initialize_state()
        self.session_duration = timedelta(days=7)
        self.jwt_secret = st.secrets.get("JWT_SECRET", secrets.token_hex(32))

    def _initialize_state(self):
        """Initialize session state variables"""
        if 'user' not in st.session_state:
            st.session_state.user = {
                'id': None,
                'username': 'Guest',
                'is_logged_in': False,
                'session_token': None
            }
        if 'auth_errors' not in st.session_state:
            st.session_state.auth_errors = []

    def register_user(self, username: str, email: str, password: str) -> bool:
        """Register a new user with enhanced validation"""
        try:
            with get_db_session() as session:
                # Input validation
                if not self._validate_registration_input(username, email, password):
                    return False

                # Check existing user
                if self._user_exists(session, username, email):
                    return False

                # Create new user with secure password
                hashed_password = self._hash_password(password)
                new_user = User(
                    username=username,
                    email=email,
                    password_hash=hashed_password,
                    created_at=datetime.utcnow(),
                    is_active=True
                )
                
                session.add(new_user)
                session.commit()
                return True

        except Exception as e:
            st.error(f"Registration error: {str(e)}")
            return False

    def login_user(self, username: str, password: str) -> bool:
        """Login user with enhanced security"""
        try:
            with get_db_session() as session:
                user = session.query(User).filter(User.username == username).first()
                
                if not user or not self._verify_password(password, user.password_hash):
                    st.error("Invalid username or password")
                    return False

                if not user.is_active:
                    st.error("Account is inactive")
                    return False

                # Generate session token
                session_token = self._generate_session_token(user)
                
                # Update user session
                user.last_login = datetime.utcnow()
                user.session_id = session_token
                session.commit()

                # Update session state
                self._set_user_session(user, session_token)
                return True

        except Exception as e:
            st.error(f"Login error: {str(e)}")
            return False

    def verify_session(self) -> bool:
        """Verify current user session with token validation"""
        try:
            if not st.session_state.user['session_token']:
                return False

            with get_db_session() as session:
                # Verify token
                payload = self._verify_session_token(st.session_state.user['session_token'])
                if not payload:
                    self.logout_user()
                    return False

                # Check user exists and session is valid
                user = session.query(User).filter(User.id == payload['user_id']).first()
                if not user or user.session_id != st.session_state.user['session_token']:
                    self.logout_user()
                    return False

                return True

        except Exception:
            self.logout_user()
            return False

    def logout_user(self):
        """Logout user and clear session"""
        try:
            with get_db_session() as session:
                if st.session_state.user['id']:
                    user = session.query(User).filter(User.id == st.session_state.user['id']).first()
                    if user:
                        user.session_id = None
                        session.commit()

            st.session_state.user = {
                'id': None,
                'username': 'Guest',
                'is_logged_in': False,
                'session_token': None
            }
            st.session_state.auth_errors = []

        except Exception as e:
            st.error(f"Logout error: {str(e)}")

    def _hash_password(self, password: str) -> str:
        """Hash password with bcrypt"""
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

    def _verify_password(self, password: str, hashed: str) -> bool:
        """Verify password against hash"""
        try:
            return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))
        except Exception:
            return False

    def _generate_session_token(self, user: User) -> str:
        """Generate JWT session token"""
        return jwt.encode(
            {
                'user_id': user.id,
                'username': user.username,
                'exp': datetime.utcnow() + self.session_duration
            },
            self.jwt_secret,
            algorithm='HS256'
        )

    def _verify_session_token(self, token: str) -> Optional[Dict]:
        """Verify JWT session token"""
        try:
            return jwt.decode(token, self.jwt_secret, algorithms=['HS256'])
        except Exception:
            return None

    def _set_user_session(self, user: User, session_token: str):
        """Set user session state"""
        st.session_state.user = {
            'id': user.id,
            'username': user.username,
            'is_logged_in': True,
            'session_token': session_token
        }

    def _validate_registration_input(self, username: str, email: str, password: str) -> bool:
        """Validate registration input"""
        st.session_state.auth_errors = []
        
        if len(username) < 3:
            st.session_state.auth_errors.append("Username must be at least 3 characters long")
        
        if len(password) < 8:
            st.session_state.auth_errors.append("Password must be at least 8 characters long")
            
        import re
        if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
            st.session_state.auth_errors.append("Invalid email format")
            
        return len(st.session_state.auth_errors) == 0

    def _user_exists(self, session: Session, username: str, email: str) -> bool:
        """Check if user already exists"""
        existing_user = session.query(User).filter(
            (User.username == username) | (User.email == email)
        ).first()
        
        if existing_user:
            if existing_user.username == username:
                st.session_state.auth_errors.append("Username already taken")
            if existing_user.email == email:
                st.session_state.auth_errors.append("Email already registered")
            return True
            
        return False

    def login_form(self):
        """Display login form"""
        st.write("## Login")
        with st.form("login_form"):
            username = st.text_input("Username")
            password = st.text_input("Password", type="password")
            submit = st.form_submit_button("Login")
            
            if submit:
                if self.login_user(username, password):
                    st.success("Login successful!")
                    return True
        return False

    def register_form(self):
        """Display registration form"""
        st.write("## Register")
        with st.form("register_form"):
            username = st.text_input("Username")
            email = st.text_input("Email")
            password = st.text_input("Password", type="password")
            confirm_password = st.text_input("Confirm Password", type="password")
            
            submit = st.form_submit_button("Register")
            
            if submit:
                if password != confirm_password:
                    st.error("Passwords do not match!")
                    return False

                if self.register_user(username, email, password):
                    st.success("Registration successful! Please login.")
                    return True
        return False

    def logout(self):
        """Logout the current user"""
        if 'user' in st.session_state:
            del st.session_state['user']
            st.success("Logged out successfully!")

    def google_login(self):
        # Implementation of Google OAuth2 login
        pass