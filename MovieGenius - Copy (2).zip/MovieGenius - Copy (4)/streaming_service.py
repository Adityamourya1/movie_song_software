import streamlit as st
from sqlalchemy.orm import sessionmaker
from models import StreamingLink, WatchlistItem
import requests
from typing import Dict, List
from datetime import datetime
from typing import List, Dict, Optional
from datetime import datetime, timedelta
from error_handler import error_logger
from exceptions import APIError, RateLimitError, ResourceNotFoundError

class StreamingService:
    def __init__(self, db_engine):
        self.db_engine = db_engine
        self.Session = sessionmaker(bind=db_engine)
        self.justwatch_api_url = "https://api.justwatch.com/content/titles/movie"
        self._initialize_cache()

    def _initialize_cache(self):
        """Initialize streaming service cache"""
        if 'streaming_cache' not in st.session_state:
            st.session_state.streaming_cache = {}
        if 'streaming_cache_ttl' not in st.session_state:
            st.session_state.streaming_cache_ttl = timedelta(hours=12)

    def get_streaming_options(self, movie_id: int) -> List[Dict]:
        """Get streaming options with caching and error handling"""
        cache_key = f"streaming_{movie_id}"
        
        # Check cache
        if cache_key in st.session_state.streaming_cache:
            cache_data = st.session_state.streaming_cache[cache_key]
            if datetime.now() - cache_data['timestamp'] < st.session_state.streaming_cache_ttl:
                return cache_data['data']

        try:
            # First try JustWatch API
            options = self._get_justwatch_options(movie_id)
            if not options:
                # Fallback to our database
                options = self._get_database_options(movie_id)

            # Cache results
            st.session_state.streaming_cache[cache_key] = {
                'data': options,
                'timestamp': datetime.now()
            }
            
            return options

        except Exception as e:
            error_logger.log_error(e, "fetching streaming options")
            return self._get_database_options(movie_id)  # Fallback to database

    def _get_justwatch_options(self, movie_id: int) -> List[Dict]:
        """Get streaming options from JustWatch API"""
        try:
            response = requests.get(
                self.justwatch_api_url,
                params={'tmdb_id': movie_id}
            )
            
            if response.status_code == 429:  # Rate limited
                raise RateLimitError(
                    "JustWatch API rate limit exceeded",
                    retry_after=int(response.headers.get('Retry-After', 30))
                )
            
            response.raise_for_status()
            data = response.json()
            
            options = []
            for offer in data.get('offers', []):
                if offer.get('monetization_type') == 'flatrate':  # Streaming services only
                    options.append({
                        'provider': offer['provider_name'],
                        'url': offer['urls']['standard_web'],
                        'price': None,
                        'quality': offer.get('presentation_type', 'SD'),
                        'last_updated': datetime.now()
                    })
            
            return options

        except Exception as e:
            error_logger.log_error(e, "JustWatch API request")
            raise APIError("Failed to fetch JustWatch data", "JustWatch",
                         getattr(e.response, 'status_code', None))

    def _get_database_options(self, movie_id: int) -> List[Dict]:
        """Get streaming options from our database"""
        try:
            with self.db_engine.connect() as conn:
                result = conn.execute("""
                    SELECT provider_name, url, price, quality, last_updated
                    FROM streaming_options
                    WHERE movie_id = ? AND last_updated > datetime('now', '-7 days')
                    ORDER BY price NULLS FIRST
                """, (movie_id,))
                
                return [{
                    'provider': row[0],
                    'url': row[1],
                    'price': row[2],
                    'quality': row[3],
                    'last_updated': row[4]
                } for row in result]

        except Exception as e:
            error_logger.log_error(e, "database streaming options")
            return []

    def update_streaming_option(self, movie_id: int, provider: str, 
                              url: str, price: Optional[float] = None,
                              quality: str = 'SD') -> bool:
        """Update or add streaming option in database"""
        try:
            with self.db_engine.connect() as conn:
                conn.execute("""
                    INSERT INTO streaming_options 
                    (movie_id, provider_name, url, price, quality, last_updated)
                    VALUES (?, ?, ?, ?, ?, datetime('now'))
                    ON CONFLICT(movie_id, provider_name) DO UPDATE SET
                        url = excluded.url,
                        price = excluded.price,
                        quality = excluded.quality,
                        last_updated = datetime('now')
                """, (movie_id, provider, url, price, quality))
                
                # Clear cache for this movie
                cache_key = f"streaming_{movie_id}"
                if cache_key in st.session_state.streaming_cache:
                    del st.session_state.streaming_cache[cache_key]
                
                return True

        except Exception as e:
            error_logger.log_error(e, "updating streaming option")
            return False

    def remove_streaming_option(self, movie_id: int, provider: str) -> bool:
        """Remove a streaming option from database"""
        try:
            with self.db_engine.connect() as conn:
                conn.execute("""
                    DELETE FROM streaming_options
                    WHERE movie_id = ? AND provider_name = ?
                """, (movie_id, provider))
                
                # Clear cache for this movie
                cache_key = f"streaming_{movie_id}"
                if cache_key in st.session_state.streaming_cache:
                    del st.session_state.streaming_cache[cache_key]
                
                return True

        except Exception as e:
            error_logger.log_error(e, "removing streaming option")
            return False

    def get_streaming_availability(self, movie_id: int) -> Dict[str, str]:
        """Get streaming availability for a movie"""
        # First check our database
        session = self.Session()
        db_links = session.query(StreamingLink).filter_by(movie_id=movie_id).all()
        
        if db_links:
            return {link.platform: link.affiliate_link for link in db_links}
            
        # If not in database, check streaming APIs
        availability = self._check_streaming_apis(movie_id)
        
        # Save results to database
        if availability:
            self._save_streaming_links(movie_id, availability)
            
        session.close()
        return availability

    def _check_streaming_apis(self, movie_id: int) -> Dict[str, str]:
        """Check various streaming APIs for movie availability"""
        availability = {}
        
        for platform, api_info in self.streaming_apis.items():
            try:
                response = requests.get(
                    f"{api_info['base_url']}/{movie_id}",
                    headers=api_info['headers']
                )
                if response.status_code == 200:
                    data = response.json()
                    if self._is_available(data, platform):
                        availability[platform] = self._get_watch_link(data, platform)
            except Exception as e:
                st.error(f"Error checking {platform}: {str(e)}")
                
        return availability

    def _save_streaming_links(self, movie_id: int, availability: Dict[str, str]):
        """Save streaming links to database"""
        session = self.Session()
        for platform, link in availability.items():
            streaming_link = StreamingLink(
                movie_id=movie_id,
                platform=platform,
                affiliate_link=link
            )
            session.add(streaming_link)
        session.commit()
        session.close()

    @st.cache_data(ttl=3600)  # Cache for 1 hour
    def get_trending_by_platform(self, platform: str) -> List[Dict]:
        """Get trending movies by streaming platform"""
        api_info = self.streaming_apis.get(platform)
        if not api_info:
            return []
            
        try:
            response = requests.get(
                f"{api_info['base_url']}/trending",
                headers=api_info['headers']
            )
            if response.status_code == 200:
                return response.json().get('results', [])
        except Exception as e:
            st.error(f"Error getting trending movies for {platform}: {str(e)}")
        return []

    def get_user_watchlist(self, user_id: int) -> List[int]:
        """Get list of movie IDs in user's watchlist"""
        session = self.Session()
        try:
            watchlist_items = session.query(WatchlistItem)\
                .filter_by(user_id=user_id)\
                .all()
            return [item.movie_id for item in watchlist_items]
        finally:
            session.close()

    def add_to_watchlist(self, user_id: int, movie_id: int) -> bool:
        """Add a movie to user's watchlist"""
        session = self.Session()
        try:
            # Check if already in watchlist
            existing = session.query(WatchlistItem)\
                .filter_by(user_id=user_id, movie_id=movie_id)\
                .first()
            
            if not existing:
                new_item = WatchlistItem(
                    user_id=user_id,
                    movie_id=movie_id,
                    added_at=datetime.utcnow()
                )
                session.add(new_item)
                session.commit()
                return True
            return False
            
        except Exception as e:
            st.error(f"Error adding to watchlist: {str(e)}")
            session.rollback()
            return False
            
        finally:
            session.close()

    def remove_from_watchlist(self, user_id: int, movie_id: int) -> bool:
        """Remove a movie from user's watchlist"""
        session = self.Session()
        try:
            item = session.query(WatchlistItem)\
                .filter_by(user_id=user_id, movie_id=movie_id)\
                .first()
            
            if item:
                session.delete(item)
                session.commit()
                return True
            return False
            
        except Exception as e:
            st.error(f"Error removing from watchlist: {str(e)}")
            session.rollback()
            return False
            
        finally:
            session.close()

    def is_in_watchlist(self, user_id: int, movie_id: int) -> bool:
        """Check if a movie is in user's watchlist"""
        session = self.Session()
        try:
            return session.query(WatchlistItem)\
                .filter_by(user_id=user_id, movie_id=movie_id)\
                .first() is not None
        finally:
            session.close()

    def get_streaming_links(self, movie_id: int) -> Dict[str, str]:
        """Get streaming links for a movie"""
        session = self.Session()
        try:
            links = session.query(StreamingLink)\
                .filter_by(movie_id=movie_id)\
                .all()
            return {link.platform: link.affiliate_link for link in links}
        finally:
            session.close()

    def add_streaming_link(self, movie_id: int, platform: str, 
                         link: str, added_by: int) -> bool:
        """Add a streaming link for a movie"""
        session = self.Session()
        try:
            # Check if link already exists
            existing = session.query(StreamingLink)\
                .filter_by(movie_id=movie_id, platform=platform)\
                .first()
            
            if existing:
                existing.affiliate_link = link
                existing.added_by = added_by
            else:
                new_link = StreamingLink(
                    movie_id=movie_id,
                    platform=platform,
                    affiliate_link=link,
                    added_by=added_by,
                    created_at=datetime.utcnow()
                )
                session.add(new_link)
                
            session.commit()
            return True
            
        except Exception as e:
            st.error(f"Error adding streaming link: {str(e)}")
            session.rollback()
            return False
            
        finally:
            session.close()

    def remove_streaming_link(self, movie_id: int, platform: str) -> bool:
        """Remove a streaming link for a movie"""
        session = self.Session()
        try:
            link = session.query(StreamingLink)\
                .filter_by(movie_id=movie_id, platform=platform)\
                .first()
            
            if link:
                session.delete(link)
                session.commit()
                return True
            return False
            
        except Exception as e:
            st.error(f"Error removing streaming link: {str(e)}")
            session.rollback()
            return False
            
        finally:
            session.close()

    def get_available_platforms(self) -> List[str]:
        """Get list of available streaming platforms"""
        return [
            "Netflix",
            "Amazon Prime",
            "Disney+",
            "Hulu",
            "HBO Max",
            "Apple TV+",
            "Peacock",
            "Paramount+"
        ]

class AffiliateManager:
    def __init__(self, db_engine):
        self.Session = sessionmaker(bind=db_engine)

    def add_affiliate_link(self, movie_id: int, platform: str, 
                         affiliate_link: str, admin_id: int):
        """Add or update affiliate link for a movie"""
        session = self.Session()
        existing_link = session.query(StreamingLink).filter_by(
            movie_id=movie_id, platform=platform).first()
            
        if existing_link:
            existing_link.affiliate_link = affiliate_link
            existing_link.added_by = admin_id
        else:
            new_link = StreamingLink(
                movie_id=movie_id,
                platform=platform,
                affiliate_link=affiliate_link,
                added_by=admin_id
            )
            session.add(new_link)
            
        session.commit()
        session.close()

    def get_admin_analytics(self, admin_id: int) -> Dict:
        """Get analytics for admin's affiliate links"""
        session = self.Session()
        links = session.query(StreamingLink).filter_by(added_by=admin_id).all()
        
        analytics = {
            'total_links': len(links),
            'by_platform': {},
            'recent_additions': []
        }
        
        for link in links:
            # Count by platform
            analytics['by_platform'][link.platform] = \
                analytics['by_platform'].get(link.platform, 0) + 1
            
            # Add recent links
            if len(analytics['recent_additions']) < 5:
                analytics['recent_additions'].append({
                    'movie_id': link.movie_id,
                    'platform': link.platform,
                    'added_at': link.created_at
                })
                
        session.close()
        return analytics