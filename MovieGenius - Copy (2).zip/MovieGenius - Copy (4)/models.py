from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Table, Boolean, Float, Text, UniqueConstraint
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

# User-Movie likes association table
user_movie_likes = Table(
    'user_movie_likes', Base.metadata,
    Column('user_id', Integer, ForeignKey('users.id')),
    Column('movie_id', Integer)
)

# User-Movie watchlist association table
user_movie_watchlist = Table(
    'user_movie_watchlist', Base.metadata,
    Column('user_id', Integer, ForeignKey('users.id')),
    Column('movie_id', Integer)
)

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(200), nullable=False)
    bio = Column(Text, nullable=True)
    profile_picture = Column(String(200), nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime, nullable=True)
    session_id = Column(String(36), unique=True, nullable=True)
    is_admin = Column(Boolean, default=False)
    email_notifications = Column(Boolean, default=True)
    is_public = Column(Boolean, default=False)
    show_reviews = Column(Boolean, default=True)
    show_playlists = Column(Boolean, default=True)
    show_mature_content = Column(Boolean, default=False)
    
    # Relationships
    movie_reviews = relationship("MovieReview", back_populates="user")
    song_reviews = relationship("SongReview", back_populates="user")
    content_reviews = relationship("Review", back_populates="user")
    likes = relationship("MovieLike", back_populates="user")
    watchlist_items = relationship("WatchlistItem", back_populates="user")
    preferences = relationship("UserPreference", back_populates="user", uselist=False)
    streaming_links = relationship("StreamingLink", backref="added_by_user")
    song_likes = relationship("SongLike", back_populates="user")

class MovieReview(Base):
    __tablename__ = 'movie_reviews'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    movie_id = Column(Integer)
    rating = Column(Integer, nullable=False)
    review_text = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = relationship("User", back_populates="movie_reviews")

class SongReview(Base):
    __tablename__ = 'song_reviews'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    song_id = Column(String(50))
    rating = Column(Float)
    review_text = Column(String(1000))
    created_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User", back_populates="song_reviews")

class MovieLike(Base):
    __tablename__ = 'movie_likes'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    movie_id = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User", back_populates="likes")
    
    __table_args__ = (
        UniqueConstraint('user_id', 'movie_id', name='unique_user_movie_like'),
    )
    
    def __repr__(self):
        return f"<MovieLike(user_id={self.user_id}, movie_id={self.movie_id})>"

class WatchlistItem(Base):
    __tablename__ = 'watchlist'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    movie_id = Column(Integer)
    added_at = Column(DateTime, default=datetime.utcnow)
    
    user = relationship("User", back_populates="watchlist_items")
    
    def __repr__(self):
        return f"<WatchlistItem(user_id={self.user_id}, movie_id={self.movie_id})>"

class StreamingLink(Base):
    __tablename__ = 'streaming_links'
    
    id = Column(Integer, primary_key=True)
    movie_id = Column(Integer)
    platform = Column(String(50))  # Netflix, Amazon Prime, etc.
    affiliate_link = Column(String(500))
    added_by = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=datetime.utcnow)

class UserPreference(Base):
    __tablename__ = 'user_preferences'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), unique=True)
    preferred_genres = Column(String(200))
    mood_preferences = Column(String(200))
    language_preferences = Column(String(100))
    
    user = relationship("User", back_populates="preferences")

class AffiliateLink(Base):
    __tablename__ = 'affiliate_links'
    
    id = Column(Integer, primary_key=True)
    movie_id = Column(Integer, nullable=False)
    platform = Column(String(50), nullable=False)
    link = Column(String(500), nullable=False)
    admin_id = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=datetime.utcnow)

class Review(Base):
    __tablename__ = 'reviews'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    content_id = Column(Integer, nullable=False)
    content_type = Column(String(10))  # 'movie' or 'song'
    rating = Column(Float)
    review_text = Column(Text)
    is_critic = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Update relationship
    user = relationship("User", back_populates="content_reviews")  # Changed from 'reviews'

class Playlist(Base):
    __tablename__ = 'playlists'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    name = Column(String(100))
    created_at = Column(DateTime, default=datetime.utcnow)
    
    items = relationship("PlaylistItem", back_populates="playlist")

class PlaylistItem(Base):
    __tablename__ = 'playlist_items'
    
    id = Column(Integer, primary_key=True)
    playlist_id = Column(Integer, ForeignKey('playlists.id'))
    content_id = Column(Integer, nullable=False)
    content_type = Column(String(10))  # 'movie' or 'song'
    added_at = Column(DateTime, default=datetime.utcnow)
    
    playlist = relationship("Playlist", back_populates="items")

class SongLike(Base):
    __tablename__ = 'song_likes'

    id = Column(Integer, primary_key=True)
    song_id = Column(String(255), nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationship
    user = relationship("User", back_populates="song_likes")