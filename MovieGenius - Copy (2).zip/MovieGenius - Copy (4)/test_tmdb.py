import requests
import streamlit as st

def test_tmdb_key(api_key):
    """Test TMDB API key with a simple configuration request"""
    base_url = "https://api.themoviedb.org/3"
    test_url = f"{base_url}/configuration"
    
    # Test with query parameter
    params = {"api_key": api_key}
    print(f"Testing API key (first 4 chars: {api_key[:4]}...)")
    
    try:
        response = requests.get(test_url, params=params, timeout=10)
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.text[:200]}")  # Print first 200 chars of response
        
        return response.status_code == 200
    except Exception as e:
        print(f"Error testing API key: {str(e)}")
        return False

if __name__ == "__main__":
    api_key = "eff57f501e2b97588cbda46b8d182845"  # New API key
    success = test_tmdb_key(api_key)
    print(f"\nAPI Key Test Result: {'Success' if success else 'Failed'}")
