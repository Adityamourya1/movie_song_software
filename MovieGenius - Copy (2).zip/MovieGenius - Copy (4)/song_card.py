import streamlit as st
from typing import Dict
import uuid
from components import Card, ErrorBoundary, display_rating, loading_placeholder
from error_handler import error_logger

class SongCard:
    def __init__(self, song_data, review_system):
        self.song_data = song_data
        self.review_system = review_system

    def display(self, song: Dict, prefix: str = ""):
        """Display song card using reusable components"""
        with ErrorBoundary():
            unique_id = f"{prefix}_{song['id']}_{uuid.uuid4().hex[:8]}"
            
            # Create song content
            content = self._create_song_content(song, unique_id)
            
            # Create song footer with actions
            footer = self._create_song_footer(song, unique_id)
            
            # Use reusable Card component
            Card(
                title=song['name'],
                content=content,
                footer=footer
            ).render()

    def _create_song_content(self, song: Dict, unique_id: str) -> st.container:
        """Create the main content of the song card"""
        container = st.container()
        with container:
            col1, col2 = st.columns([1, 3])
            
            with col1:
                if song.get('album', {}).get('images'):
                    st.image(
                        song['album']['images'][0]['url'],
                        use_container_width=True
                    )
            
            with col2:
                # Artist information
                st.write("by " + ", ".join(artist['name'] for artist in song['artists']))
                
                # Album information
                if song.get('album'):
                    st.write(f"Album: {song['album']['name']}")
                
                # Song preview
                if song.get('preview_url'):
                    st.audio(song['preview_url'])
                
                # Song details
                details = []
                if song.get('duration_ms'):
                    duration_sec = song['duration_ms'] / 1000
                    minutes = int(duration_sec // 60)
                    seconds = int(duration_sec % 60)
                    details.append(f"Duration: {minutes}:{seconds:02d}")
                
                if song.get('popularity'):
                    display_rating(song['popularity'] / 20)  # Convert 100-scale to 5-scale
                
                st.write(" | ".join(details))

    def _create_song_footer(self, song: Dict, unique_id: str) -> st.container:
        """Create the footer with action buttons"""
        container = st.container()
        with container:
            col1, col2 = st.columns(2)
            
            with col1:
                if st.button("Rate & Review", key=f"{unique_id}_review"):
                    st.session_state[f"show_song_review_{song['id']}"] = True
            
            with col2:
                if st.button("Similar Songs", key=f"{unique_id}_similar"):
                    st.session_state[f"show_similar_songs_{song['id']}"] = True
                    
            # Show review form if requested
            if st.session_state.get(f"show_song_review_{song['id']}", False):
                self._show_review_form(song)
                
            # Show similar songs if requested
            if st.session_state.get(f"show_similar_songs_{song['id']}", False):
                self._show_similar_songs(song)

        return container

    def _show_review_form(self, song: Dict):
        """Display song review form"""
        try:
            with st.form(key=f"review_form_{song['id']}"):
                st.write(f"Review for {song['name']}")
                rating = st.slider("Rating", 1, 5, 3)
                review_text = st.text_area("Your Review")
                
                if st.form_submit_button("Submit Review"):
                    self.review_system.add_song_review(
                        song['id'],
                        st.session_state.user['id'],
                        rating,
                        review_text
                    )
                    st.success("Review submitted successfully!")
                    st.session_state[f"show_song_review_{song['id']}"] = False
                    st.rerun()
                    
        except Exception as e:
            error_logger.display_error_message(
                e,
                "submitting song review",
                "Unable to submit review at the moment."
            )

    def _show_similar_songs(self, song: Dict):
        """Display similar songs"""
        try:
            with st.spinner("Loading similar songs..."):
                similar_songs = self.song_data.get_recommendations(
                    [song['id']], 
                    limit=5
                )
                
                if similar_songs:
                    st.write("Similar Songs:")
                    for similar in similar_songs:
                        self.display(similar, prefix=f"similar_{song['id']}")
                else:
                    st.info("No similar songs found")
                    
        except Exception as e:
            error_logger.display_error_message(
                e,
                "fetching similar songs",
                "Unable to load similar songs at the moment."
            )