from crewai import Agent, Task, Crew
import os

# Set your OpenAI API key
os.environ["OPENAI_API_KEY"] = "your_openai_api_key"

# Define an AI agent to improve your UI
ui_designer = Agent(
    role="Streamlit UI Expert",
    goal="Improve the UI of an existing Streamlit-based movie recommendation system",
    backstory="An expert in Streamlit UI/UX, creating visually appealing and user-friendly interfaces.",
    verbose=True,
    model="gpt-4"
)

# Define a task for UI enhancement
ui_task = Task(
    description="Refactor and enhance the existing Streamlit UI with better layout, styling, and interactivity. Improve navigation, responsiveness, and add animations where needed.",
    agent=ui_designer
)

# Create a Crew (AI team)
crew = Crew(
    agents=[ui_designer],
    tasks=[ui_task]
)

# Run CrewAI to improve your UI
results = crew.kickoff()
print("Enhanced Streamlit UI Code:\n", results)
