from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship, sessionmaker
from models import SongReview, User, Base
from datetime import datetime
from typing import List, Dict
import streamlit as st

class SongReviewSystem:
    def __init__(self, db_engine, song_data):
        self.Session = sessionmaker(bind=db_engine)
        self.song_data = song_data

    def add_review(self, user_id: int, song_id: str, 
                  rating: float, review_text: str) -> bool:
        """Add or update a song review"""
        session = self.Session()
        
        try:
            existing_review = session.query(SongReview).filter_by(
                user_id=user_id, song_id=song_id).first()
                
            if existing_review:
                existing_review.rating = rating
                existing_review.review_text = review_text
            else:
                new_review = SongReview(
                    user_id=user_id,
                    song_id=song_id,
                    rating=rating,
                    review_text=review_text
                )
                session.add(new_review)
                
            session.commit()
            return True
            
        except Exception as e:
            st.error(f"Error saving review: {str(e)}")
            session.rollback()
            return False
            
        finally:
            session.close()

    def get_song_reviews(self, song_id: str) -> Dict:
        """Get all reviews for a song"""
        session = self.Session()
        reviews = session.query(SongReview).filter_by(song_id=song_id).all()
        
        result = {
            'average_rating': 0.0,
            'total_reviews': len(reviews),
            'rating_distribution': {1: 0, 2: 0, 3: 0, 4: 0, 5: 0},
            'reviews': []
        }
        
        if reviews:
            total_rating = sum(review.rating for review in reviews)
            result['average_rating'] = round(total_rating / len(reviews), 1)
            
            for review in reviews:
                rating_key = int(review.rating)
                result['rating_distribution'][rating_key] = \
                    result['rating_distribution'].get(rating_key, 0) + 1
                
                result['reviews'].append({
                    'user': review.user.username,
                    'rating': review.rating,
                    'review': review.review_text,
                    'date': review.created_at
                })
                
        session.close()
        return result

    def display_song_review_form(self, song_id: str, song_info: Dict):
        """Display song review form in Streamlit"""
        st.markdown(f"""
        ### Review "{song_info['name']}" by {', '.join(a['name'] for a in song_info['artists'])}
        """)
        
        with st.form(key=f'song_review_form_{song_id}'):
            rating = st.slider("Rating", 1, 5, 3)
            review_text = st.text_area("Your Review")
            submit = st.form_submit_button("Submit Review")
            
            if submit and 'user' in st.session_state:
                success = self.add_review(
                    st.session_state.user['id'],
                    song_id,
                    float(rating),
                    review_text
                )
                if success:
                    st.success("Review submitted successfully!")
                    return True
        return False

    def display_song_reviews(self, song_id: str, song_info: Dict):
        """Display song reviews in Streamlit"""
        reviews_data = self.get_song_reviews(song_id)
        
        st.markdown(f"""
        ### Reviews for "{song_info['name']}"
        **Average Rating:** ⭐ {reviews_data['average_rating']}/5
        **Total Reviews:** {reviews_data['total_reviews']}
        """)
        
        # Rating distribution visualization
        st.markdown("### Rating Distribution")
        for rating, count in reviews_data['rating_distribution'].items():
            percentage = (count / reviews_data['total_reviews'] * 100) \
                if reviews_data['total_reviews'] > 0 else 0
            st.progress(percentage / 100)
            st.write(f"{rating}⭐: {count} reviews ({percentage:.1f}%)")
        
        # Individual reviews
        st.markdown("### User Reviews")
        for review in reviews_data['reviews']:
            with st.container():
                st.markdown(f"""
                ---
                **{review['user']}** - ⭐ {review['rating']}/5
                
                {review['review']}
                
                *{review['date'].strftime('%Y-%m-%d %H:%M')}*
                """) 