import streamlit as st
from sqlalchemy.orm import sessionmaker
from models import User, WatchlistItem, MovieLike, UserPreference, MovieReview, Playlist, PlaylistItem
from typing import List, Dict, Optional
from datetime import datetime
import bcrypt

class UserProfile:
    def __init__(self, db_engine):
        self.Session = sessionmaker(bind=db_engine)

    def display_profile(self):
        if not st.session_state.auth.verify_session():
            st.warning("Please log in to view your profile")
            return
        
        user_id = st.session_state.user['id']
        session = self.Session()
        
        try:
            user = session.query(User).get(user_id)
            if not user:
                st.error("User not found")
                return
            
            # Profile Header
            col1, col2 = st.columns([1, 2])
            with col1:
                st.image("https://via.placeholder.com/150", use_container_width=True)
            with col2:
                st.title(user.username)
                st.markdown(f"Member since: {user.created_at.strftime('%B %Y')}")
                last_login = "Never" if user.last_login is None else user.last_login.strftime('%Y-%m-%d %H:%M')
                st.markdown(f"Last login: {last_login}")
            
            # Profile Tabs
            tab1, tab2, tab3 = st.tabs(["Activity", "Settings", "Privacy"])
            
            with tab1:
                self.display_user_activity(user)
            
            with tab2:
                self.display_profile_settings(user)
            
            with tab3:
                self.display_privacy_settings(user)
            
        except Exception as e:
            st.error(f"Error loading profile: {str(e)}")
        finally:
            session.close()

    def display_profile_settings(self, user):
        """Display and manage all user profile settings"""
        st.subheader("Profile Settings")
        
        # Create tabs for different settings
        profile_tab, preferences_tab, account_tab = st.tabs([
            "Profile Info", "Preferences", "Account Settings"
        ])
        
        with profile_tab:
            # Basic profile information
            st.write("**Personal Information**")
            new_username = st.text_input("Username", value=user.username)
            new_email = st.text_input("Email", value=user.email)
            
            # Profile picture (placeholder for now)
            st.write("**Profile Picture**")
            uploaded_file = st.file_uploader("Choose a profile picture", type=['jpg', 'png', 'jpeg'])
            
            # Bio section
            st.write("**Bio**")
            bio = getattr(user, 'bio', '') or ''  # Handle None value
            new_bio = st.text_area("Tell us about yourself", value=bio)
            
            if st.button("Update Profile"):
                if self.update_profile_info(user.id, new_username, new_email, new_bio, uploaded_file):
                    st.success("Profile updated successfully!")
                    st.rerun()
        
        with preferences_tab:
            # Get current preferences
            current_prefs = self.get_user_preferences(user.id)
            
            # Genre preferences
            st.write("**Favorite Genres**")
            available_genres = [
                "Action", "Adventure", "Animation", "Comedy", "Crime",
                "Documentary", "Drama", "Family", "Fantasy", "History",
                "Horror", "Music", "Mystery", "Romance", "Science Fiction",
                "Thriller", "War", "Western"
            ]
            selected_genres = st.multiselect(
                "Select your favorite genres",
                options=available_genres,
                default=current_prefs.get('preferred_genres', [])
            )
            
            # Mood preferences
            st.write("**Mood Preferences**")
            available_moods = [
                "Happy", "Relaxed", "Excited", "Thoughtful",
                "Emotional", "Intense", "Light-hearted"
            ]
            selected_moods = st.multiselect(
                "What moods do you prefer?",
                options=available_moods,
                default=current_prefs.get('mood_preferences', [])
            )
            
            # Language preferences
            st.write("**Language Preferences**")
            available_languages = [
                "English", "Spanish", "French", "German",
                "Japanese", "Korean", "Chinese", "Hindi"
            ]
            selected_languages = st.multiselect(
                "Preferred languages",
                options=available_languages,
                default=current_prefs.get('language_preferences', [])
            )
            
            # Content preferences
            st.write("**Content Preferences**")
            mature_content = st.toggle(
                "Show mature content",
                value=current_prefs.get('show_mature_content', False)
            )
            
            if st.button("Save Preferences"):
                if self.update_preferences(
                    user.id,
                    selected_genres,
                    selected_moods,
                    selected_languages,
                    mature_content
                ):
                    st.success("Preferences updated successfully!")
                    st.rerun()
        
        with account_tab:
            # Password change
            st.write("**Change Password**")
            current_password = st.text_input("Current Password", type="password")
            new_password = st.text_input("New Password", type="password")
            confirm_password = st.text_input("Confirm New Password", type="password")
            
            # Notification settings
            st.write("**Notification Settings**")
            email_notifications = st.toggle(
                "Email notifications",
                value=getattr(user, 'email_notifications', True)
            )
            
            # Privacy settings
            st.write("**Privacy Settings**")
            profile_public = st.toggle(
                "Make profile public",
                value=getattr(user, 'is_public', False)
            )
            show_reviews = st.toggle(
                "Show my reviews publicly",
                value=getattr(user, 'show_reviews', True)
            )
            show_playlists = st.toggle(
                "Show my playlists publicly",
                value=getattr(user, 'show_playlists', True)
            )
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("Update Password"):
                    if new_password != confirm_password:
                        st.error("New passwords don't match!")
                    else:
                        if self.update_password(user.id, current_password, new_password):
                            st.success("Password updated successfully!")
            
            with col2:
                if st.button("Save Account Settings"):
                    if self.update_account_settings(
                        user.id,
                        email_notifications,
                        profile_public,
                        show_reviews,
                        show_playlists
                    ):
                        st.success("Account settings updated successfully!")
                        st.rerun()

    def update_profile_info(self, user_id: int, username: str, email: str, bio: str, profile_pic=None) -> bool:
        """Update user profile information"""
        session = self.Session()
        try:
            user = session.query(User).get(user_id)
            if not user:
                return False
            
            user.username = username
            user.email = email
            user.bio = bio
            
            if profile_pic:
                # Handle profile picture upload (implement storage logic)
                pass
            
            session.commit()
            return True
        except Exception as e:
            st.error(f"Error updating profile: {str(e)}")
            session.rollback()
            return False
        finally:
            session.close()

    def update_password(self, user_id: int, current_password: str, new_password: str) -> bool:
        """Update user password"""
        session = self.Session()
        try:
            user = session.query(User).get(user_id)
            if not user:
                return False
            
            # Verify current password
            if not bcrypt.checkpw(current_password.encode('utf-8'), 
                                user.password_hash.encode('utf-8')):
                st.error("Current password is incorrect")
                return False
            
            # Update to new password
            user.password_hash = bcrypt.hashpw(
                new_password.encode('utf-8'), 
                bcrypt.gensalt()
            ).decode('utf-8')
            
            session.commit()
            return True
        except Exception as e:
            st.error(f"Error updating password: {str(e)}")
            session.rollback()
            return False
        finally:
            session.close()

    def update_account_settings(self, user_id: int, email_notifications: bool,
                              profile_public: bool, show_reviews: bool,
                              show_playlists: bool) -> bool:
        """Update user account settings"""
        session = self.Session()
        try:
            user = session.query(User).get(user_id)
            if not user:
                return False
            
            user.email_notifications = email_notifications
            user.is_public = profile_public
            user.show_reviews = show_reviews
            user.show_playlists = show_playlists
            
            session.commit()
            return True
        except Exception as e:
            st.error(f"Error updating account settings: {str(e)}")
            session.rollback()
            return False
        finally:
            session.close()

    def get_user_data(self, user_id: int) -> Dict:
        """Get user information from database"""
        session = self.Session()
        try:
            user = session.query(User).filter_by(id=user_id).first()
            if user:
                return {
                    'username': user.username,
                    'email': user.email,
                    'created_at': user.created_at,
                    'is_admin': user.is_admin
                }
        finally:
            session.close()
        return {}

    def get_user_preferences(self, user_id: int) -> Dict:
        """Get user preferences with safe fallbacks for missing columns"""
        if not user_id:
            return self._get_default_preferences()
        
        session = self.Session()
        try:
            user = session.query(User).get(user_id)
            if not user:
                return self._get_default_preferences()
            
            # Safely get preferences with fallbacks
            prefs = session.query(UserPreference).filter_by(user_id=user_id).first()
            if not prefs:
                prefs = UserPreference(user_id=user_id)
                session.add(prefs)
                session.commit()
            
            return {
                'preferred_genres': (prefs.preferred_genres or '').split(',') if prefs.preferred_genres else [],
                'mood_preferences': (prefs.mood_preferences or '').split(',') if prefs.mood_preferences else [],
                'language_preferences': (prefs.language_preferences or '').split(',') if prefs.language_preferences else [],
                'show_mature_content': getattr(user, 'show_mature_content', False),
                'email_notifications': getattr(user, 'email_notifications', True),
                'is_public': getattr(user, 'is_public', False),
                'show_reviews': getattr(user, 'show_reviews', True),
                'show_playlists': getattr(user, 'show_playlists', True)
            }
        
        except Exception as e:
            st.error(f"Error getting user preferences: {str(e)}")
            return self._get_default_preferences()
        finally:
            session.close()

    def _get_default_preferences(self) -> Dict:
        """Return default preferences"""
        return {
            'preferred_genres': [],
            'mood_preferences': [],
            'language_preferences': [],
            'show_mature_content': False,
            'email_notifications': True,
            'is_public': False,
            'show_reviews': True,
            'show_playlists': True
        }

    def update_preferences(self, user_id: int, genres: list, 
                         moods: list, languages: list, mature_content: bool) -> bool:
        """Update user preferences in database"""
        session = self.Session()
        try:
            prefs = session.query(UserPreference).filter_by(user_id=user_id).first()
            
            if prefs:
                prefs.preferred_genres = ','.join(genres)
                prefs.mood_preferences = ','.join(moods)
                prefs.language_preferences = ','.join(languages)
                prefs.show_mature_content = mature_content
            else:
                new_prefs = UserPreference(
                    user_id=user_id,
                    preferred_genres=','.join(genres),
                    mood_preferences=','.join(moods),
                    language_preferences=','.join(languages),
                    show_mature_content=mature_content
                )
                session.add(new_prefs)
                
            session.commit()
            return True
            
        except Exception as e:
            st.error(f"Error updating preferences: {str(e)}")
            session.rollback()
            return False
            
        finally:
            session.close()

    def display_user_activity(self, user):
        """Display user's recent activity"""
        st.subheader("Recent Activity")
        
        session = self.Session()
        try:
            # Get user's recent reviews
            recent_reviews = session.query(MovieReview)\
                .filter(MovieReview.user_id == user.id)\
                .order_by(MovieReview.created_at.desc())\
                .limit(5)\
                .all()
                
            if recent_reviews:
                st.write("Recent Reviews:")
                for review in recent_reviews:
                    with st.expander(f"Movie Review - {review.created_at.strftime('%Y-%m-%d')}"):
                        st.write(f"Rating: {'⭐' * int(review.rating)}")
                        st.write(f"Review: {review.content}")
            else:
                st.info("No recent reviews")
                
            # Get user's playlists
            playlists = session.query(Playlist)\
                .filter(Playlist.user_id == user.id)\
                .order_by(Playlist.created_at.desc())\
                .all()
                
            if playlists:
                st.write("Playlists:")
                for playlist in playlists:
                    with st.expander(f"Playlist: {playlist.name}"):
                        items = session.query(PlaylistItem)\
                            .filter(PlaylistItem.playlist_id == playlist.id)\
                            .all()
                        if items:
                            for item in items:
                                st.write(f"- {item.content_type}: {item.content_id}")
                        else:
                            st.info("No items in playlist")
            else:
                st.info("No playlists created")
                
        except Exception as e:
            st.error(f"Error displaying activity: {str(e)}")
        finally:
            session.close()

    def get_user_profile(self, user_id: int) -> Dict:
        """Get user profile information"""
        session = self.Session()
        user = session.query(User).filter_by(id=user_id).first()
        
        if not user:
            session.close()
            return None
            
        profile = {
            'username': user.username,
            'email': user.email,
            'joined_date': user.created_at,
            'watchlist_count': len(user.watchlist),
            'likes_count': len(user.liked_movies),
            'preferences': self._get_user_preferences(user)
        }
        
        session.close()
        return profile

    def get_watchlist(self, user_id: int) -> List[int]:
        """Get user's watchlist"""
        session = self.Session()
        watchlist = session.query(WatchlistItem).filter_by(user_id=user_id).all()
        movie_ids = [item.movie_id for item in watchlist]
        session.close()
        return movie_ids

    def add_to_watchlist(self, user_id: int, movie_id: int):
        """Add movie to user's watchlist"""
        session = self.Session()
        if not session.query(WatchlistItem).filter_by(
            user_id=user_id, movie_id=movie_id).first():
            watchlist_item = WatchlistItem(user_id=user_id, movie_id=movie_id)
            session.add(watchlist_item)
            session.commit()
        session.close()

    def remove_from_watchlist(self, user_id: int, movie_id: int):
        """Remove movie from user's watchlist"""
        session = self.Session()
        session.query(WatchlistItem).filter_by(
            user_id=user_id, movie_id=movie_id).delete()
        session.commit()
        session.close()

    def toggle_like(self, user_id: int, movie_id: int) -> bool:
        """Toggle like status for a movie"""
        session = self.Session()
        like = session.query(MovieLike).filter_by(
            user_id=user_id, movie_id=movie_id).first()
            
        if like:
            session.delete(like)
            session.commit()
            session.close()
            return False
        else:
            new_like = MovieLike(user_id=user_id, movie_id=movie_id)
            session.add(new_like)
            session.commit()
            session.close()
            return True

    def _get_user_preferences(self, user: User) -> Dict:
        """Get formatted user preferences"""
        if not user.preferences:
            return {
                'preferred_genres': [],
                'mood_preferences': [],
                'language_preferences': [],
                'show_mature_content': False
            }
            
        return {
            'preferred_genres': user.preferences.preferred_genres.split(','),
            'mood_preferences': user.preferences.mood_preferences.split(','),
            'language_preferences': user.preferences.language_preferences.split(','),
            'show_mature_content': user.preferences.show_mature_content
        }

    def get_recommended_movies(self, user_id: int) -> List[int]:
        """Get personalized movie recommendations based on user preferences"""
        session = self.Session()
        user = session.query(User).filter_by(id=user_id).first()
        
        if not user or not user.preferences:
            session.close()
            return []
            
        # Get user's liked movies
        liked_movies = [like.movie_id for like in user.liked_movies]
        
        # Get user's preferences
        preferences = self._get_user_preferences(user)
        
        session.close()
        
        # Use these preferences to get recommendations
        # This would typically call your recommendation engine
        return self._get_personalized_recommendations(
            liked_movies, preferences)

    def _get_personalized_recommendations(self, 
                                       liked_movies: List[int], 
                                       preferences: Dict) -> List[int]:
        """
        Get personalized recommendations based on user's likes and preferences
        This would be implemented in your recommendation engine
        """
        # Placeholder - implement your recommendation logic here
        pass

    def display_privacy_settings(self, user):
        """Display and manage user privacy settings"""
        st.subheader("Privacy Settings")
        
        session = self.Session()
        try:
            # Profile visibility settings
            st.write("Profile Visibility")
            profile_public = st.toggle(
                "Make profile public",
                value=getattr(user, 'is_public', False),
                key='profile_visibility'
            )
            
            # Review visibility settings
            st.write("Review Settings")
            show_reviews = st.toggle(
                "Show my reviews publicly",
                value=getattr(user, 'show_reviews', True),
                key='review_visibility'
            )
            
            # Playlist visibility settings
            st.write("Playlist Settings")
            show_playlists = st.toggle(
                "Show my playlists publicly",
                value=getattr(user, 'show_playlists', True),
                key='playlist_visibility'
            )
            
            # Save changes button
            if st.button("Save Privacy Settings"):
                try:
                    user.is_public = profile_public
                    user.show_reviews = show_reviews
                    user.show_playlists = show_playlists
                    session.commit()
                    st.success("Privacy settings updated successfully!")
                except Exception as e:
                    st.error(f"Error saving privacy settings: {str(e)}")
                    session.rollback()
                
        except Exception as e:
            st.error(f"Error loading privacy settings: {str(e)}")
        finally:
            session.close() 