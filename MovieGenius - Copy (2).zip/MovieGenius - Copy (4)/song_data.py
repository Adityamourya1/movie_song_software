import streamlit as st
import requests
from typing import List, Dict, Optional
from datetime import datetime, timedelta
import logging
import random
from error_handler import error_logger
from exceptions import APIError, RateLimitError, ResourceNotFoundError

class SongData:
    def __init__(self):
        """Initialize Spotify API configuration"""
        try:
            # Try to access Spotify credentials
            if "spotify" not in st.secrets:
                raise KeyError("'spotify' section not found in secrets")
                
            spotify_secrets = st.secrets["spotify"]
            if "client_id" not in spotify_secrets:
                raise KeyError("'client_id' not found in spotify secrets")
            if "client_secret" not in spotify_secrets:
                raise KeyError("'client_secret' not found in spotify secrets")
            
            self.client_id = spotify_secrets["client_id"]
            self.client_secret = spotify_secrets["client_secret"]
            
            # Verify credentials are not empty
            if not self.client_id or not self.client_secret:
                raise ValueError("Spotify credentials are empty")
                
            self.use_spotify = True
            
        except Exception as e:
            st.error(f"Error loading Spotify credentials: {str(e)}")
            st.info("Please ensure your .streamlit/secrets.toml file contains:")
            st.code("""
[spotify]
client_id = "your_spotify_client_id"
client_secret = "your_spotify_client_secret"
            """)
            self.use_spotify = False
            
        self.base_url = "https://api.spotify.com/v1"
        self.default_image = "https://via.placeholder.com/300?text=No+Image"
        self._initialize_cache()
        self._get_access_token()
        self._initialize_default_songs()
        self._initialize_rate_limiting()

    def _initialize_cache(self):
        """Initialize cache structures in session state"""
        if 'song_cache' not in st.session_state:
            st.session_state.song_cache = {}
        if 'spotify_token' not in st.session_state:
            st.session_state.spotify_token = None
        if 'token_expiry' not in st.session_state:
            st.session_state.token_expiry = None
        if 'cache_duration' not in st.session_state:
            st.session_state.cache_duration = timedelta(hours=1)
        if 'default_songs' not in st.session_state:
            st.session_state.default_songs = []

    def _initialize_default_songs(self):
        """Initialize a list of popular song IDs"""
        # Popular song IDs from various genres
        default_song_ids = [
            "11dFghVXANMlKmJXsNCbNl",  # "Cut To The Feeling" by Carly Rae Jepsen
            "7qiZfU4dY1lWllzX7mPBI3",  # "Shape of You" by Ed Sheeran
            "1zi7xx7UVEFkmKfv06H8x0",  # "One Dance" by Drake
            "3T4UodGkfZObJ43RtA5KDF",  # "Counting Stars" by OneRepublic
            "4iJyoBOLtHqaGxP12qzhQI",  # "Titanium" by David Guetta
            "0VjIjW4GlUZAMYd2vXMi3b",  # "Blinding Lights" by The Weeknd
            "4u7EnebtmKWzUH433cf5Qv",  # "Bohemian Rhapsody" by Queen
            "1BxfuPKGuaTgP7aM0Bbdwr",  # "Cruel Summer" by Taylor Swift
            "2LBqCSwhJGcFQeTHMVGwy3",  # "The Less I Know The Better" by Tame Impala
            "4fzsfWzRhPawzqhX8Qt9F3"   # "Uptown Funk" by Mark Ronson
        ]
        st.session_state.default_songs = default_song_ids

    def _get_access_token(self):
        """Get Spotify access token with error handling"""
        try:
            # Check if we have a valid token
            if (hasattr(st.session_state, 'spotify_token') and 
                hasattr(st.session_state, 'token_expiry') and 
                st.session_state.token_expiry and  # Add this check
                isinstance(st.session_state.token_expiry, datetime) and  # Add type check
                st.session_state.token_expiry > datetime.now()):
                return st.session_state.spotify_token
            
            auth_response = requests.post(
                'https://accounts.spotify.com/api/token',
                data={
                    'grant_type': 'client_credentials',
                    'client_id': self.client_id,
                    'client_secret': self.client_secret,
                }
            )
            
            if auth_response.status_code != 200:
                st.error(f"Spotify API error: {auth_response.text}")
                return None
                
            auth_data = auth_response.json()
            
            st.session_state.spotify_token = auth_data['access_token']
            st.session_state.token_expiry = datetime.now() + timedelta(seconds=auth_data['expires_in'])
            
            return st.session_state.spotify_token
            
        except Exception as e:
            st.error(f"Error getting Spotify access token: {str(e)}")
            return None

    def get_song_details(self, song_id: str) -> Dict:
        """Get song details with fallback for missing credentials"""
        if not self.use_spotify:
            return self._get_fallback_song_details(song_id)
            
        try:
            access_token = self._get_access_token()
            if not access_token:
                return {}

            headers = {
                'Authorization': f'Bearer {access_token}'
            }
            
            # Get track details
            response = requests.get(
                f"{self.base_url}/tracks/{song_id}",
                headers=headers
            )
            response.raise_for_status()
            track_data = response.json()
            
            # Extract the largest available image
            images = track_data.get('album', {}).get('images', [])
            image_url = self.default_image
            if images:
                # Sort images by size and get the largest one
                images.sort(key=lambda x: x.get('width', 0), reverse=True)
                image_url = images[0].get('url', self.default_image)
            
            # Format the response
            return {
                'id': track_data.get('id'),
                'name': track_data.get('name'),
                'artist': track_data.get('artists', [{}])[0].get('name', 'Unknown Artist'),
                'album': track_data.get('album', {}).get('name', 'Unknown Album'),
                'image_url': image_url,
                'preview_url': track_data.get('preview_url'),
                'external_url': track_data.get('external_urls', {}).get('spotify'),
                'duration_ms': track_data.get('duration_ms'),
                'release_date': track_data.get('album', {}).get('release_date')
            }
            
        except Exception as e:
            st.error(f"Error fetching song details: {str(e)}")
            return {}

    def search_songs(self, query: str, limit: int = 10) -> List[Dict]:
        """Search for songs with proper error handling"""
        try:
            if not self.use_spotify:
                return self._get_fallback_search_results(query, limit)

            access_token = self._get_access_token()
            if not access_token:
                return self._get_fallback_search_results(query, limit)

            headers = {
                'Authorization': f'Bearer {access_token}'
            }
            
            response = requests.get(
                f"{self.base_url}/search",
                headers=headers,
                params={
                    'q': query,
                    'type': 'track',
                    'limit': limit
                }
            )
            response.raise_for_status()
            data = response.json()
            
            # Extract tracks and format them
            tracks = data.get('tracks', {}).get('items', [])
            formatted_tracks = []
            
            for track in tracks:
                # Get artist names safely
                artists = track.get('artists', [])
                artist_names = [artist.get('name', 'Unknown Artist') for artist in artists]
                
                # Get album details safely
                album = track.get('album', {})
                images = album.get('images', [])
                image_url = self.default_image
                if images:
                    image_url = images[0].get('url', self.default_image)
                
                formatted_track = {
                    'id': track.get('id', ''),
                    'name': track.get('name', 'Unknown Track'),
                    'artists': artist_names,
                    'artist': ', '.join(artist_names),  # Add combined artist string
                    'album': album.get('name', 'Unknown Album'),
                    'image_url': image_url,
                    'preview_url': track.get('preview_url'),
                    'external_url': track.get('external_urls', {}).get('spotify'),
                    'duration_ms': track.get('duration_ms', 0),
                    'release_date': album.get('release_date', 'Unknown Date')
                }
                formatted_tracks.append(formatted_track)
            
            return formatted_tracks
            
        except Exception as e:
            st.error(f"Error searching songs: {str(e)}")
            return self._get_fallback_search_results(query, limit)

    def display_song(self, song: Dict):
        """Display song with proper error handling"""
        with st.container():
            col1, col2 = st.columns([1, 3])
            
            with col1:
                image_url = song.get('image_url', self.default_image)
                st.image(
                    image_url,
                    use_container_width=True,
                    caption=song.get('album', 'Album')
                )
            
            with col2:
                st.subheader(song.get('name', 'Unknown Track'))
                st.write(f"**Artist:** {song.get('artist', 'Unknown Artist')}")
                st.write(f"**Album:** {song.get('album', 'Unknown Album')}")
                
                # Add like button and count
                if 'user' in st.session_state and st.session_state.user['is_logged_in']:
                    like_col, count_col = st.columns([1, 3])
                    with like_col:
                        user_id = st.session_state.user['id']
                        has_liked = st.session_state.review_system.has_user_liked_song(
                            song['id'], user_id
                        )
                        like_button_key = f"song_like_{song['id']}_{datetime.now().timestamp()}"
                        if st.button(
                            "❤️" if has_liked else "🤍",
                            key=like_button_key
                        ):
                            st.session_state.review_system.toggle_song_like(
                                song['id'], user_id
                            )
                            st.rerun()
                    
                    with count_col:
                        likes_count = st.session_state.review_system.get_song_likes_count(song['id'])
                        st.write(f"**{likes_count} likes**")
                
                if song.get('preview_url'):
                    st.audio(song['preview_url'])
                
                if song.get('external_url'):
                    st.markdown(f"[Open in Spotify]({song['external_url']})")

    def get_song_by_id(self, song_id: str) -> Optional[Dict]:
        """Get song details by Spotify ID"""
        # Convert to string if needed
        song_id = str(song_id)
        
        # If invalid song_id, return a random default song
        if not song_id or song_id == "1" or len(song_id) < 5:
            return self.get_random_default_song()

        # Check cache first
        cache_key = f"song_{song_id}"
        if cache_key in st.session_state.song_cache:
            cached_data = st.session_state.song_cache[cache_key]
            if datetime.now() - cached_data['timestamp'] < st.session_state.cache_duration:
                return cached_data['data']

        try:
            headers = {
                'Authorization': f'Bearer {self._get_access_token()}'
            }
            response = requests.get(
                f'https://api.spotify.com/v1/tracks/{song_id}',
                headers=headers
            )
            response.raise_for_status()
            
            song_data = response.json()
            
            # Cache the results
            st.session_state.song_cache[cache_key] = {
                'data': song_data,
                'timestamp': datetime.now()
            }
            
            return song_data
            
        except Exception as e:
            st.error(f"Error fetching song details: {str(e)}")
            return self.get_random_default_song()

    def get_random_default_song(self) -> Optional[Dict]:
        """Get a random song from default songs list"""
        try:
            random_id = random.choice(st.session_state.default_songs)
            headers = {
                'Authorization': f'Bearer {self._get_access_token()}'
            }
            response = requests.get(
                f'https://api.spotify.com/v1/tracks/{random_id}',
                headers=headers
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logging.error(f"Error fetching random default song: {str(e)}")
            return None

    def get_song_recommendations(self, seed_tracks: List[str], limit: int = 10) -> List[Dict]:
        """Get song recommendations based on seed tracks"""
        cache_key = f"recommendations_{','.join(seed_tracks)}_{limit}"
        if cache_key in st.session_state.song_cache:
            cached_data = st.session_state.song_cache[cache_key]
            if datetime.now() - cached_data['timestamp'] < st.session_state.cache_duration:
                return cached_data['data']

        try:
            headers = {
                'Authorization': f'Bearer {self._get_access_token()}'
            }
            response = requests.get(
                'https://api.spotify.com/v1/recommendations',
                headers=headers,
                params={
                    'seed_tracks': ','.join(seed_tracks),
                    'limit': limit
                }
            )
            response.raise_for_status()
            
            recommendations = response.json()['tracks']
            
            # Cache the results
            st.session_state.song_cache[cache_key] = {
                'data': recommendations,
                'timestamp': datetime.now()
            }
            
            return recommendations
            
        except Exception as e:
            st.error(f"Error getting song recommendations: {str(e)}")
            return []

    def get_artist_top_tracks(self, artist_id: str) -> List[Dict]:
        """Get artist's top tracks"""
        response = self._make_api_request(
            f'artists/{artist_id}/top-tracks',
            {'market': 'US'}
        )
        if response and 'tracks' in response:
            return response['tracks']
        return []

    def get_trending_songs(self, limit: int = 10) -> List[Dict]:
        """Get trending songs from Spotify"""
        cache_key = f"trending_{datetime.now().strftime('%Y%m%d')}_{limit}"
        if cache_key in st.session_state.song_cache:
            cached_data = st.session_state.song_cache[cache_key]
            if datetime.now() - cached_data['timestamp'] < st.session_state.cache_duration:
                return cached_data['data']

        try:
            headers = {
                'Authorization': f'Bearer {self._get_access_token()}'
            }
            # Get tracks from Global Top 50 playlist
            response = requests.get(
                'https://api.spotify.com/v1/playlists/37i9dQZEVXbMDoHDwVN2tF/tracks',
                headers=headers,
                params={'limit': limit}
            )
            response.raise_for_status()
            
            tracks = [item['track'] for item in response.json()['items']]
            
            # Cache the results
            st.session_state.song_cache[cache_key] = {
                'data': tracks,
                'timestamp': datetime.now()
            }
            
            return tracks
            
        except Exception as e:
            logging.error(f"Error fetching trending songs: {str(e)}")
            # Return some default songs if API fails
            return [self.get_song_by_id(song_id) for song_id in 
                   st.session_state.default_songs[:limit]]

    def verify_spotify_credentials(self):
        """Verify Spotify credentials are working"""
        if not self._get_access_token():
            return False
            
        try:
            test_response = requests.get(
                f"https://api.spotify.com/v1/browse/new-releases",
                headers={'Authorization': f'Bearer {self._get_access_token()}'}
            )
            return test_response.status_code == 200
        except Exception:
            return False

    def initialize_spotify(self):
        """Initialize Spotify connection and verify credentials"""
        if not self.client_id or not self.client_secret:
            st.error("Spotify credentials not found in secrets.toml")
            return False
            
        if not self.verify_spotify_credentials():
            st.error("Failed to verify Spotify credentials")
            return False
            
        st.success("Spotify connection established successfully!")
        return True

    def _make_api_request(self, endpoint: str, params: Dict = None) -> Dict:
        """Make request to Spotify API"""
        if not self._get_access_token():
            return None
            
        headers = {
            'Authorization': f'Bearer {self._get_access_token()}'
        }
        
        try:
            response = requests.get(
                f"https://api.spotify.com/v1/{endpoint}",
                headers=headers,
                params=params
            )
            
            if response.status_code == 401:
                # Token expired, get new token
                self._get_access_token()
                if self._get_access_token():
                    headers['Authorization'] = f'Bearer {self._get_access_token()}'
                    response = requests.get(
                        f"https://api.spotify.com/v1/{endpoint}",
                        headers=headers,
                        params=params
                    )
                    
            return response.json() if response.status_code == 200 else None
            
        except Exception as e:
            st.error(f"Error making API request: {str(e)}")
            return None

    def _get_fallback_song_details(self, song_id: str) -> Dict:
        """Provide fallback song details when Spotify API is unavailable"""
        return {
            'id': song_id,
            'name': 'Sample Song',
            'artist': 'Sample Artist',
            'album': 'Sample Album',
            'image_url': self.default_image,
            'preview_url': None,
            'external_url': None,
            'duration_ms': 180000,
            'release_date': '2024-01-01'
        }

    def _get_fallback_search_results(self, query: str, limit: int) -> List[Dict]:
        """Provide fallback search results"""
        return [{
            'id': f'sample_{i}',
            'name': f'Sample Result for "{query}" ({i})',
            'artists': ['Sample Artist'],
            'artist': 'Sample Artist',
            'album': 'Sample Album',
            'image_url': self.default_image,
            'preview_url': None,
            'external_url': None,
            'duration_ms': 180000,
            'release_date': '2024'
        } for i in range(1, limit + 1)]

    def _initialize_rate_limiting(self):
        """Initialize rate limiting tracking"""
        if 'spotify_api_calls' not in st.session_state:
            st.session_state.spotify_api_calls = []
        if 'spotify_window_start' not in st.session_state:
            st.session_state.spotify_window_start = datetime.now()

    def _check_rate_limit(self):
        """Check and manage API rate limiting"""
        now = datetime.now()
        
        # Clear old calls outside the window (30 seconds)
        st.session_state.spotify_api_calls = [
            timestamp for timestamp in st.session_state.spotify_api_calls
            if (now - timestamp) < timedelta(seconds=30)
        ]
        
        # Check if we're over the limit (100 requests per 30 seconds)
        if len(st.session_state.spotify_api_calls) >= 100:
            oldest_call = min(st.session_state.spotify_api_calls)
            wait_time = 30 - (now - oldest_call).total_seconds()
            if wait_time > 0:
                raise RateLimitError(
                    f"Spotify API rate limit exceeded. Try again in {int(wait_time)} seconds.",
                    retry_after=int(wait_time)
                )

        # Add current call
        st.session_state.spotify_api_calls.append(now)

    def _get_access_token(self) -> str:
        """Get or refresh Spotify access token"""
        try:
            now = datetime.now()
            
            # Check if token is still valid
            if (st.session_state.spotify_token and st.session_state.token_expiry 
                and st.session_state.token_expiry > now):
                return st.session_state.spotify_token

            # Get new token
            auth_response = requests.post(
                'https://accounts.spotify.com/api/token',
                data={
                    'grant_type': 'client_credentials',
                    'client_id': self.client_id,
                    'client_secret': self.client_secret,
                },
            )
            
            auth_response.raise_for_status()
            auth_data = auth_response.json()
            
            # Store token and expiry
            st.session_state.spotify_token = auth_data['access_token']
            st.session_state.token_expiry = now + timedelta(seconds=auth_data['expires_in'])
            
            return st.session_state.spotify_token

        except requests.exceptions.RequestException as e:
            error_logger.log_error(e, "Spotify authentication")
            raise APIError("Failed to authenticate with Spotify", "Spotify", 
                         getattr(e.response, 'status_code', None))

    def _make_api_request(self, endpoint: str, params: Dict = None) -> Dict:
        """Make Spotify API request with error handling and rate limiting"""
        try:
            self._check_rate_limit()
            
            headers = {
                'Authorization': f'Bearer {self._get_access_token()}'
            }
            
            response = requests.get(
                f'https://api.spotify.com/v1/{endpoint}',
                headers=headers,
                params=params
            )
            
            if response.status_code == 429:  # Too Many Requests
                retry_after = int(response.headers.get('Retry-After', 30))
                raise RateLimitError(
                    f"Spotify API rate limit exceeded. Try again in {retry_after} seconds.",
                    retry_after=retry_after
                )
            
            response.raise_for_status()
            return response.json()

        except requests.exceptions.RequestException as e:
            if isinstance(e, requests.exceptions.HTTPError):
                if e.response.status_code == 404:
                    raise ResourceNotFoundError(f"Resource not found: {endpoint}")
                elif e.response.status_code == 401:
                    # Token might be expired, clear it and retry once
                    st.session_state.spotify_token = None
                    return self._make_api_request(endpoint, params)
                
            error_logger.log_error(e, f"Spotify API request to {endpoint}")
            raise APIError(f"Spotify API request failed: {str(e)}", "Spotify",
                         getattr(e.response, 'status_code', None))

    def search_songs(self, query: str, limit: int = 10) -> List[Dict]:
        """Search for songs with error handling and caching"""
        cache_key = f"search_{query}_{limit}"
        
        # Check cache
        if cache_key in st.session_state.song_cache:
            cache_data = st.session_state.song_cache[cache_key]
            if datetime.now() - cache_data['timestamp'] < timedelta(minutes=30):
                return cache_data['data']

        try:
            response = self._make_api_request('search', {
                'q': query,
                'type': 'track',
                'limit': limit
            })
            
            results = response.get('tracks', {}).get('items', [])
            
            # Cache results
            st.session_state.song_cache[cache_key] = {
                'data': results,
                'timestamp': datetime.now()
            }
            
            return results

        except RateLimitError:
            # Return cached results if available
            if cache_key in st.session_state.song_cache:
                return st.session_state.song_cache[cache_key]['data']
            raise
        except Exception as e:
            error_logger.log_error(e, "song search")
            return []

    def get_song_by_id(self, song_id: str) -> Optional[Dict]:
        """Get song details with error handling and caching"""
        cache_key = f"song_{song_id}"
        
        # Check cache
        if cache_key in st.session_state.song_cache:
            cache_data = st.session_state.song_cache[cache_key]
            if datetime.now() - cache_data['timestamp'] < timedelta(hours=24):
                return cache_data['data']

        try:
            response = self._make_api_request(f'tracks/{song_id}')
            
            # Cache results
            st.session_state.song_cache[cache_key] = {
                'data': response,
                'timestamp': datetime.now()
            }
            
            return response

        except ResourceNotFoundError:
            error_logger.log_error(Exception(f"Song {song_id} not found"), 
                                 "get song details")
            return None
        except Exception as e:
            error_logger.log_error(e, "get song details")
            return None

    def get_recommendations(self, seed_tracks: List[str], seed_genres: List[str] = None,
                          limit: int = 10) -> List[Dict]:
        """Get song recommendations with error handling and caching"""
        cache_key = f"recommendations_{','.join(seed_tracks)}_{','.join(seed_genres or [])}_{limit}"
        
        # Check cache
        if cache_key in st.session_state.song_cache:
            cache_data = st.session_state.song_cache[cache_key]
            if datetime.now() - cache_data['timestamp'] < timedelta(hours=1):
                return cache_data['data']

        try:
            params = {
                'seed_tracks': ','.join(seed_tracks),
                'limit': limit
            }
            if seed_genres:
                params['seed_genres'] = ','.join(seed_genres)

            response = self._make_api_request('recommendations', params)
            tracks = response.get('tracks', [])
            
            # Cache results
            st.session_state.song_cache[cache_key] = {
                'data': tracks,
                'timestamp': datetime.now()
            }
            
            return tracks

        except Exception as e:
            error_logger.log_error(e, "get song recommendations")
            return []

    def get_trending_songs(self, limit: int = 10) -> List[Dict]:
        """Get trending songs with error handling and caching"""
        cache_key = f"trending_songs_{limit}"
        
        # Check cache
        if cache_key in st.session_state.song_cache:
            cache_data = st.session_state.song_cache[cache_key]
            if datetime.now() - cache_data['timestamp'] < timedelta(hours=3):
                return cache_data['data']

        try:
            # Get trending tracks from featured playlists
            response = self._make_api_request('browse/featured-playlists', {
                'limit': 2  # Get tracks from top 2 playlists
            })
            
            playlists = response.get('playlists', {}).get('items', [])
            trending_tracks = []
            
            for playlist in playlists:
                tracks_response = self._make_api_request(
                    f"playlists/{playlist['id']}/tracks",
                    {'limit': limit // 2}  # Split limit between playlists
                )
                playlist_tracks = [
                    item['track'] for item in tracks_response.get('items', [])
                    if item.get('track')
                ]
                trending_tracks.extend(playlist_tracks)
            
            # Cache results
            st.session_state.song_cache[cache_key] = {
                'data': trending_tracks,
                'timestamp': datetime.now()
            }
            
            return trending_tracks

        except Exception as e:
            error_logger.log_error(e, "get trending songs")
            return []