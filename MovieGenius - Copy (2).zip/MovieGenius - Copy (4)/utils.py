import streamlit as st

def load_css():
    st.markdown("""
        <style>
        /* Modern UI Theme inspired by Bolt.new */
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        :root {
            --primary-color: #3245FF;
            --primary-light: #535FFF;
            --gradient-1: linear-gradient(135deg, #3245FF 0%, #535FFF 100%);
            --gradient-2: linear-gradient(135deg, #111111 0%, #222222 100%);
            --surface-card: rgba(32, 32, 32, 0.6);
            --text-primary: #FFFFFF;
            --text-secondary: rgba(255, 255, 255, 0.7);
            --border-light: rgba(255, 255, 255, 0.1);
        }
        
        /* Base styles */
        .stApp {
            font-family: 'Inter', sans-serif;
            background: #000000;
            background-image: 
                radial-gradient(circle at top right, rgba(50, 69, 255, 0.15), transparent 25%),
                radial-gradient(circle at bottom left, rgba(83, 95, 255, 0.15), transparent 25%);
            color: var(--text-primary);
        }
        
        /* Modern Cards with Bolt-style Glass Effect */
        .glass-container {
            background: var(--surface-card);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-light);
            border-radius: 24px;
            padding: 2rem;
            margin: 1.5rem 0;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }
        
        .glass-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, 
                transparent, 
                rgba(255, 255, 255, 0.1), 
                transparent);
        }
        
        .glass-container:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
            border-color: rgba(50, 69, 255, 0.3);
        }
        
        /* Premium Buttons */
        .stButton > button {
            background: var(--gradient-1);
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 500;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(50, 69, 255, 0.2);
            backdrop-filter: blur(10px);
        }
        
        .stButton > button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(50, 69, 255, 0.3);
            background: linear-gradient(135deg, #535FFF 0%, #3245FF 100%);
        }
        
        /* Modern Input Fields */
        .stTextInput > div > div > input {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            color: white;
            padding: 1rem;
            transition: all 0.3s ease;
            font-size: 0.95rem;
        }
        
        .stTextInput > div > div > input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(50, 69, 255, 0.2);
            background: rgba(255, 255, 255, 0.07);
        }
        
        /* Bolt-style Tabs */
        .stTabs [data-baseweb="tab-list"] {
            gap: 8px;
            background: var(--surface-card);
            padding: 0.5rem;
            border-radius: 16px;
            border: 1px solid var(--border-light);
        }
        
        .stTabs [data-baseweb="tab"] {
            border-radius: 10px;
            padding: 0.5rem 1rem;
            transition: all 0.3s ease;
        }
        
        .stTabs [data-baseweb="tab"]:hover {
            background: rgba(50, 69, 255, 0.1);
        }
        
        /* Premium Select Boxes */
        .stSelectbox > div > div {
            background: var(--surface-card);
            border: 1px solid var(--border-light);
            border-radius: 12px;
        }
        
        .stSelectbox > div > div:hover {
            border-color: var(--primary-color);
        }
        
        /* Modern Sliders */
        .stSlider > div > div > div {
            background: var(--gradient-1);
        }
        
        /* Chat Interface */
        .chat-container {
            background: var(--surface-card);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border-light);
            border-radius: 24px;
            padding: 1.5rem;
        }
        
        .chat-message {
            padding: 1rem;
            margin: 0.5rem 0;
            border-radius: 12px;
            animation: fadeIn 0.3s ease-out;
            background: var(--gradient-2);
            border: 1px solid var(--border-light);
        }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: var(--primary-color);
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary-light);
        }
        
        /* Data Tables */
        .stDataFrame {
            background: var(--surface-card);
            border-radius: 12px;
            border: 1px solid var(--border-light);
            overflow: hidden;
        }
        
        .stDataFrame th {
            background: rgba(50, 69, 255, 0.1);
            color: var(--text-primary);
        }
        
        /* Markdown Text */
        .stMarkdown a {
            color: var(--primary-color);
            text-decoration: none;
            transition: all 0.2s ease;
        }
        
        .stMarkdown a:hover {
            color: var(--primary-light);
            text-decoration: underline;
        }
        </style>
    """, unsafe_allow_html=True)