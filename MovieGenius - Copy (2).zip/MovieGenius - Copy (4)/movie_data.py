import requests
from datetime import datetime, timedelta
import pandas as pd
from functools import lru_cache
import streamlit as st
import time
import logging
import re
from typing import List, Dict, Optional
import os
from sqlalchemy.orm import sessionmaker
from models import StreamingLink, MovieLike, Review
from error_handler import error_logger
from exceptions import APIError, RateLimitError, ResourceNotFoundError
from error_handler import ErrorLogger

# Configure logging with more detail
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

error_logger = ErrorLogger()

class MovieData:
    def __init__(self, db_engine=None):
        """Initialize MovieData with TMDB API configuration"""
        self.api_key = st.secrets["tmdb"]
        self.base_url = "https://api.tmdb.org/3"
        self.image_base_url = "https://image.tmdb.org/t/p/w500"
        self.cache = {}
        self.cache_duration = timedelta(hours=24)
        if db_engine:
            self.Session = sessionmaker(bind=db_engine)
        self._initialize_rate_limiting()

    def _initialize_rate_limiting(self):
        """Initialize rate limiting tracking"""
        if 'api_calls' not in st.session_state:
            st.session_state.api_calls = []
        if 'api_window_start' not in st.session_state:
            st.session_state.api_window_start = datetime.now()

    def _check_rate_limit(self):
        """Check and manage API rate limiting"""
        now = datetime.now()
        window_start = st.session_state.api_window_start
        
        # Clear old calls outside the window
        st.session_state.api_calls = [
            timestamp for timestamp in st.session_state.api_calls
            if (now - timestamp) < timedelta(seconds=10)
        ]
        
        # Check if we're over the limit (40 requests per 10 seconds)
        if len(st.session_state.api_calls) >= 40:
            oldest_call = min(st.session_state.api_calls)
            wait_time = 10 - (now - oldest_call).total_seconds()
            if wait_time > 0:
                raise RateLimitError(
                    f"Rate limit exceeded. Try again in {int(wait_time)} seconds.",
                    retry_after=int(wait_time)
                )

        # Add current call
        st.session_state.api_calls.append(now)

    def _make_api_request(self, endpoint: str, params: Dict = None) -> Dict:
        """Make API request with error handling and rate limiting"""
        try:
            self._check_rate_limit()
            
            url = f"{self.base_url}/{endpoint}"
            if params is None:
                params = {}
            params['api_key'] = self.api_key

            response = requests.get(url, params=params)
            
            if response.status_code == 429:  # Too Many Requests
                retry_after = int(response.headers.get('Retry-After', 30))
                raise RateLimitError(
                    f"TMDB API rate limit exceeded. Try again in {retry_after} seconds.",
                    retry_after=retry_after
                )
            
            response.raise_for_status()
            return response.json()

        except requests.exceptions.RequestException as e:
            if isinstance(e, requests.exceptions.HTTPError):
                if e.response.status_code == 404:
                    raise ResourceNotFoundError(f"Resource not found: {endpoint}")
                elif e.response.status_code == 401:
                    raise APIError("Invalid API key", "TMDB", 401)
                
            error_logger.log_error(e, f"TMDB API request to {endpoint}")
            raise APIError(f"TMDB API request failed: {str(e)}", "TMDB", 
                         getattr(e.response, 'status_code', None))

    def get_trending_movies(self) -> List[Dict]:
        """Get trending movies"""
        cache_key = "trending_movies"
        
        # Check cache first
        if cache_key in self.cache:
            cache_time, data = self.cache[cache_key]
            if datetime.now() - cache_time < self.cache_duration:
                return data

        try:
            response = self._make_api_request('trending/movie/week')
            results = response.get('results', [])[:20]  # Return top 20 trending movies
            
            # Cache the results
            self.cache[cache_key] = (datetime.now(), results)
            
            return results
            
        except Exception as e:
            st.error(f"Error getting trending movies: {str(e)}")
            return []

    def search_movies(self, query: str) -> List[Dict]:
        """Search for movies by title"""
        cache_key = f"search_{query}"
        
        # Check cache first
        if cache_key in self.cache:
            cache_time, data = self.cache[cache_key]
            if datetime.now() - cache_time < self.cache_duration:
                return data

        try:
            response = self._make_api_request('search/movie', {
                'query': query,
                'language': 'en-US',
                'include_adult': False
            })
            movies = response.get('results', [])
            
            # Cache the results
            self.cache[cache_key] = (datetime.now(), movies)
            
            return movies
            
        except Exception as e:
            st.error(f"Error searching movies: {str(e)}")
            return []

    def get_movie_details(self, movie_id: int) -> Dict:
        """Get detailed movie information including reviews and social metrics"""
        cache_key = f"movie_details_{movie_id}"
        
        # Check cache
        if cache_key in st.session_state:
            cache_data = st.session_state[cache_key]
            if datetime.now() - cache_data['timestamp'] < timedelta(hours=24):
                return cache_data['data']

        try:
            response = self._make_api_request(f'movie/{movie_id}', {
                'append_to_response': 'credits,reviews,similar'
            })
            movie_details = response
            
            # Cache the results
            st.session_state[cache_key] = {
                'data': movie_details,
                'timestamp': datetime.now()
            }

            # Get social metrics from database if Session is available
            if hasattr(self, 'Session'):
                session = self.Session()
                try:
                    likes = session.query(MovieLike).filter_by(movie_id=movie_id).count()
                    reviews = session.query(Review).filter_by(movie_id=movie_id).all()
                    critic_reviews = [r for r in reviews if getattr(r.user, 'is_critic', False)]
                    user_reviews = [r for r in reviews if not getattr(r.user, 'is_critic', False)]
                    
                    movie_details['social_metrics'] = {
                        'likes': likes,
                        'total_reviews': len(reviews),
                        'critic_reviews': critic_reviews,
                        'user_reviews': user_reviews
                    }
                finally:
                    session.close()
            
            return movie_details
        except Exception as e:
            st.error(f"Error fetching movie details: {str(e)}")
            return {}

    def get_movies_by_genre(self, genre_id: int) -> List[Dict]:
        """Get movies by genre"""
        cache_key = f"genre_{genre_id}_{datetime.now().date()}"
        
        # Check cache first
        if cache_key in self.cache:
            cache_time, data = self.cache[cache_key]
            if datetime.now() - cache_time < self.cache_duration:
                return data

        try:
            response = self._make_api_request('discover/movie', {
                'with_genres': genre_id,
                'language': 'en-US',
                'sort_by': 'popularity.desc',
                'include_adult': False
            })
            movies = response.get('results', [])
            
            # Cache the results
            self.cache[cache_key] = (datetime.now(), movies)
            
            return movies
            
        except Exception as e:
            st.error(f"Error fetching movies by genre: {str(e)}")
            return []

    def get_similar_movies(self, movie_id: int) -> List[Dict]:
        """Get movies similar to a specific movie"""
        cache_key = f"similar_{movie_id}"
        
        # Check cache first
        if cache_key in self.cache:
            cache_time, data = self.cache[cache_key]
            if datetime.now() - cache_time < self.cache_duration:
                return data

        try:
            response = self._make_api_request(f'movie/{movie_id}/similar')
            movies = response.get('results', [])
            
            # Cache the results
            self.cache[cache_key] = (datetime.now(), movies)
            
            return movies
            
        except Exception as e:
            st.error(f"Error fetching similar movies: {str(e)}")
            return []

    def get_movie_credits(self, movie_id: int) -> Dict:
        """Get cast and crew information for a movie"""
        cache_key = f"credits_{movie_id}"
        
        # Check cache first
        if cache_key in self.cache:
            cache_time, data = self.cache[cache_key]
            if datetime.now() - cache_time < self.cache_duration:
                return data

        try:
            response = self._make_api_request(f'movie/{movie_id}/credits')
            credits = response
            
            # Cache the results
            self.cache[cache_key] = (datetime.now(), credits)
            
            return credits
            
        except Exception as e:
            st.error(f"Error fetching movie credits: {str(e)}")
            return {"cast": [], "crew": []}

    def get_movie_videos(self, movie_id: int) -> List[Dict]:
        """Get video links (trailers, teasers) for a movie"""
        cache_key = f"videos_{movie_id}"
        
        # Check cache first
        if cache_key in self.cache:
            cache_time, data = self.cache[cache_key]
            if datetime.now() - cache_time < self.cache_duration:
                return data

        try:
            response = self._make_api_request(f'movie/{movie_id}/videos', {
                'language': 'en-US'
            })
            videos = response.get('results', [])
            
            # Cache the results
            self.cache[cache_key] = (datetime.now(), videos)
            
            return videos
            
        except Exception as e:
            st.error(f"Error fetching movie videos: {str(e)}")
            return []

    def get_genre_list(self) -> List[Dict]:
        """Get list of movie genres"""
        cache_key = "genres"
        
        # Check cache first
        if cache_key in self.cache:
            cache_time, data = self.cache[cache_key]
            if datetime.now() - cache_time < self.cache_duration:
                return data

        try:
            response = self._make_api_request('genre/movie/list', {
                'language': 'en-US'
            })
            genres = response.get('genres', [])
            
            # Cache the results
            self.cache[cache_key] = (datetime.now(), genres)
            
            return genres
            
        except Exception as e:
            st.error(f"Error fetching genre list: {str(e)}")
            return []

    def get_affiliate_links(self, movie_id: int) -> dict:
        """Get streaming affiliate links for a movie"""
        if not hasattr(self, 'Session'):
            return {}  # Return empty dict if no database connection
            
        session = self.Session()
        try:
            links = session.query(StreamingLink).filter_by(movie_id=movie_id).all()
            
            # Convert to dictionary with platform as key
            affiliate_links = {}
            for link in links:
                affiliate_links[link.platform] = link.link
                
            return affiliate_links
            
        except Exception as e:
            st.error(f"Error fetching affiliate links: {str(e)}")
            return {}
            
        finally:
            session.close()

    def add_affiliate_link(self, movie_id: int, platform: str, link: str, admin_id: int) -> bool:
        """Add or update an affiliate link for a movie"""
        if not hasattr(self, 'Session'):
            return False
            
        session = self.Session()
        try:
            # Check if link already exists
            existing_link = session.query(StreamingLink).filter_by(
                movie_id=movie_id,
                platform=platform
            ).first()
            
            if existing_link:
                existing_link.link = link
                existing_link.admin_id = admin_id
            else:
                new_link = StreamingLink(
                    movie_id=movie_id,
                    platform=platform,
                    link=link,
                    admin_id=admin_id
                )
                session.add(new_link)
                
            session.commit()
            return True
            
        except Exception as e:
            session.rollback()
            st.error(f"Error saving affiliate link: {str(e)}")
            return False
            
        finally:
            session.close()

    def advanced_search(self, genres: List[int] = None, year_from: Optional[int] = None, 
                       year_to: Optional[int] = None, min_rating: float = 0, 
                       keywords: List[str] = None) -> List[Dict]:
        """Advanced search for movies with multiple criteria"""
        try:
            url = f"{self.base_url}/discover/movie"
            
            # Build query parameters
            params = {
                "api_key": self.api_key,
                "language": "en-US",
                "sort_by": "popularity.desc",
                "include_adult": False,
                "vote_count.gte": 100  # Minimum number of votes
            }
            
            # Add genre filter
            if genres and len(genres) > 0:
                params["with_genres"] = ",".join(map(str, genres))
            
            # Add year filter
            if year_from:
                params["primary_release_date.gte"] = f"{year_from}-01-01"
            if year_to:
                params["primary_release_date.lte"] = f"{year_to}-12-31"
            
            # Add rating filter
            if min_rating > 0:
                params["vote_average.gte"] = min_rating
            
            # Make the request
            response = self._make_api_request('discover/movie', params)
            results = response.get("results", [])
            
            # Filter by keywords if provided
            if keywords and len(keywords) > 0:
                filtered_results = []
                for movie in results:
                    title = movie.get("title", "").lower()
                    overview = movie.get("overview", "").lower()
                    if any(keyword.lower() in title or keyword.lower() in overview 
                          for keyword in keywords):
                        filtered_results.append(movie)
                results = filtered_results
            
            return results[:20]  # Limit to top 20 results
            
        except Exception as e:
            st.error(f"Error in advanced search: {str(e)}")
            return []

    def get_movies_by_characteristics(self, characteristics: Dict) -> List[Dict]:
        """
        Get movies based on characteristics (genres, themes, tone, keywords)
        """
        genres = characteristics.get('genres', [])
        keywords = characteristics.get('keywords', [])
        themes = characteristics.get('themes', [])
        
        # Combine themes and keywords for better search results
        all_keywords = keywords + themes
        
        # First attempt with strict criteria
        results = self.advanced_search(
            genres=genres,
            keywords=all_keywords,
            min_rating=7.0  # Set a minimum rating for quality results
        )
        
        # If no results, relax the rating filter
        if not results:
            results = self.advanced_search(
                genres=genres,
                keywords=all_keywords,
                min_rating=6.0
            )
        
        # If still no results, remove keyword filter
        if not results:
            results = self.advanced_search(
                genres=genres,
                min_rating=6.0
            )
        
        return results[:20]