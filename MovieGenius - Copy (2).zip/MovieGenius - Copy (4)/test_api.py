import requests
import streamlit as st
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_tmdb_connection():
    """Test TMDB API connection with detailed logging"""
    base_url = "https://api.themoviedb.org/3"
    
    if "TMDB_API_KEY" not in st.secrets:
        logger.error("TMDB_API_KEY not found in secrets")
        return False
        
    api_key = st.secrets["TMDB_API_KEY"]
    logger.info(f"API Key length: {len(api_key)}")
    logger.info(f"API Key first 4 chars: {api_key[:4]}")
    
    url = f"{base_url}/configuration"
    params = {"api_key": api_key}
    
    try:
        logger.info("Testing API connection...")
        response = requests.get(url, params=params, timeout=10)
        logger.info(f"Response status code: {response.status_code}")
        
        if response.status_code == 200:
            logger.info("API connection successful!")
            return True
        elif response.status_code == 401:
            logger.error("API key unauthorized")
            return False
        else:
            logger.error(f"Unexpected status code: {response.status_code}")
            return False
            
    except Exception as e:
        logger.error(f"Connection test failed: {str(e)}")
        return False

if __name__ == "__main__":
    result = test_tmdb_connection()
    print(f"Connection test result: {'Success' if result else 'Failed'}")
