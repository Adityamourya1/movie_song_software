import streamlit as st
from database import engine
from review_system import ReviewSystem

# Initialize the review system in session state if not already present
if 'review_system' not in st.session_state:
    st.session_state.review_system = ReviewSystem(engine) 