import streamlit as st
from movie_data import MovieData
from song_data import SongData
from auth import Auth
from user_profile import UserProfile
from movie_recommender import MovieRecommender
from song_recommender import SongRecommender
from chatbot import MovieChatbot
from review_system import ReviewSystem
from song_review_system import SongReviewSystem
from streaming_service import StreamingService
from migrations import init_database
from utils import load_css
from ai_recommender import AIRecommender
from sqlalchemy import create_engine
from datetime import datetime, timedelta
from sqlalchemy.orm import sessionmaker
from typing import Dict
from models import User, Review, MovieLike, SongLike, StreamingLink, WatchlistItem
from init_db import init_database
from movie_card import MovieCard
import time
import re
from contextlib import contextmanager
import traceback
import logging
import sys

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@contextmanager
def error_handling(context: str):
    """Context manager for handling errors gracefully"""
    try:
        yield
    except Exception as e:
        logger.error(f"Error in {context}: {str(e)}\n{traceback.format_exc()}")
        st.error(f"An error occurred in {context}. Please try again or contact support if the problem persists.")

class AppState:
    """Manage application state"""
    def __init__(self):
        self.initialize_session_state()
        self.initialize_components()

    def initialize_session_state(self):
        """Initialize all session state variables"""
        if 'auth' not in st.session_state:
            st.session_state.auth = None
        if 'user' not in st.session_state:
            st.session_state.user = {
                'id': None,
                'username': 'Guest',
                'is_logged_in': False,
                'session_token': None
            }
        if 'search_results' not in st.session_state:
            st.session_state.search_results = []
        if 'last_search_query' not in st.session_state:
            st.session_state.last_search_query = ""
        if 'current_page' not in st.session_state:
            st.session_state.current_page = "Home"
        if 'movie_states' not in st.session_state:
            st.session_state.movie_states = {}
        if 'db_engine' not in st.session_state:
            st.session_state.db_engine = None
        if 'db_initialized' not in st.session_state:
            st.session_state.db_initialized = False
        if 'show_auth' not in st.session_state:
            st.session_state.show_auth = False
        if 'show_login' not in st.session_state:
            st.session_state.show_login = False
        if 'show_register' not in st.session_state:
            st.session_state.show_register = False
        if 'error_log' not in st.session_state:
            st.session_state.error_log = []
        if 'last_refresh' not in st.session_state:
            st.session_state.last_refresh = None
        if 'cache_duration' not in st.session_state:
            st.session_state.cache_duration = timedelta(hours=1)
        if 'active_movie_id' not in st.session_state:
            st.session_state.active_movie_id = None

    def initialize_components(self):
        """Initialize application components with error handling"""
        # Ensure database is initialized first
        with error_handling("database initialization"):
            if not st.session_state.db_initialized:
                engine = init_database()
                if engine is None:
                    raise Exception("Failed to initialize database")
                st.session_state.db_engine = engine
                st.session_state.db_initialized = True

        # Initialize auth after database is ready
        with error_handling("auth initialization"):
            if not st.session_state.auth and st.session_state.db_initialized:
                st.session_state.auth = Auth(st.session_state.db_engine)

        # Initialize core components after database and auth are ready
        with error_handling("core components initialization"):
            if st.session_state.db_initialized:
                components = initialize_components(st.session_state.db_engine)
                st.session_state.update(components)

        # Clean up expired states
        self.cleanup_expired_states()

    def cleanup_expired_states(self):
        """Clean up expired session states"""
        try:
            # Clear expired movie details
            for key in list(st.session_state.keys()):
                if key.startswith("show_details_") or key.startswith("show_review_"):
                    if st.session_state.last_refresh:
                        time_diff = datetime.now() - st.session_state.last_refresh
                        if time_diff > st.session_state.cache_duration:
                            del st.session_state[key]
            
            # Update last refresh time
            st.session_state.last_refresh = datetime.now()
        except Exception as e:
            logger.error(f"Error cleaning up expired states: {str(e)}")
            # Don't raise the error - this is a non-critical operation

def main():
    """Main application entry point with improved error handling"""
    try:
        st.set_page_config(
            page_title="MovieGenius",
            page_icon="🎬",
            layout="wide"
        )

        # Initialize app state
        app_state = AppState()
        
        # Load CSS
        load_css()
        
        # Display header
        st.title("🎬 MovieGenius")
        
        # Display profile header
        display_profile_header()
        
        if st.session_state.show_auth:
            display_auth_forms()
        else:
            with error_handling("component initialization"):
                # Initialize components
                components = initialize_components(st.session_state.db_engine)
                
                # Store components in session state
                st.session_state.update(components)
                
                # Display navigation
                display_navigation(components)

    except Exception as e:
        logger.error(f"Critical error in main: {str(e)}\n{traceback.format_exc()}")
        st.error("""
            😢 Something went wrong! We're working on fixing it.
            
            Try refreshing the page. If the problem persists:
            1. Clear your browser cache
            2. Try logging out and back in
            3. Contact support if the issue continues
        """)
        
        if st.button("Reset Application"):
            reset_application_state()
            st.rerun()

def initialize_components(db_engine) -> dict:
    """Initialize all application components"""
    if not db_engine:
        raise Exception("Database engine not initialized")
        
    movie_data = MovieData(db_engine)
    return {
        'movie_data': movie_data,
        'recommender': MovieRecommender(movie_data),  # Pass existing MovieData instance
        'review_system': ReviewSystem(db_engine),
        'song_data': SongData(),
        'song_recommender': SongRecommender(SongData()),
        'user_profile': UserProfile(db_engine),
        'chatbot': MovieChatbot(movie_data, UserProfile(db_engine)),  # Pass existing MovieData instance
        'streaming_service': StreamingService(db_engine),
        'ai_recommender': AIRecommender(movie_data)  # Pass existing MovieData instance
    }

def display_navigation(components: dict):
    """Display main navigation with error handling"""
    with error_handling("navigation"):
        # Display chat button in sidebar
        components['chatbot'].display_chat_button()
        
        # Main navigation
        pages = {
            "Discover": show_movie_page,
            "My Lists": show_watchlist_page,
            "Profile": show_profile_page,
            "Music": show_song_page
        }
        
        selected_page = st.sidebar.radio("Navigation", list(pages.keys()))
        
        # Display selected page with appropriate components
        display_selected_page(selected_page, pages, components)
        
        # Display auth button if not logged in
        display_auth_button()

def display_selected_page(selected_page: str, pages: dict, components: dict):
    """Display the selected page with error handling"""
    with error_handling(f"page display - {selected_page}"):
        if selected_page == "Discover":
            pages[selected_page](
                components['movie_data'],
                components['recommender'],
                components['review_system'],
                components['streaming_service'],
                components['ai_recommender']
            )
        elif selected_page == "My Lists":
            pages[selected_page](
                components['movie_data'],
                components['streaming_service']
            )
        elif selected_page == "Profile":
            pages[selected_page](components['user_profile'])
        elif selected_page == "Music":
            pages[selected_page](
                components['song_data'],
                components['song_recommender'],
                components['review_system']
            )

def reset_application_state():
    """Reset the application state in case of critical errors"""
    for key in list(st.session_state.keys()):
        del st.session_state[key]

def display_auth_button():
    """Display authentication button with error handling"""
    with error_handling("auth button display"):
        if not st.session_state.user['is_logged_in']:
            if st.sidebar.button("Login / Register"):
                st.session_state.show_auth = True
        else:
            if st.sidebar.button("Logout"):
                st.session_state.auth.logout_user()
                st.rerun()

def show_home_page(movie_data, song_data, movie_recommender, song_recommender):
    st.title(f"Welcome, {st.session_state.user['username']}! 👋")
    
    # Display personalized recommendations
    user_id = st.session_state.user['id']
    
    # Movie recommendations
    st.subheader("Movies You Might Like")
    user_movie_recs = movie_recommender.get_recommendations(user_id)
    if user_movie_recs:
        for movie in user_movie_recs[:5]:
            with st.container():
                col1, col2 = st.columns([1, 3])
                with col1:
                    if movie.get('poster_path'):
                        st.image(f"https://image.tmdb.org/t/p/w200{movie['poster_path']}", use_container_width=True)
                with col2:
                    st.markdown(f"### {movie['title']}")
                    st.write(movie['overview'][:200] + "...")
                    st.button(f"More Info 🎬", key=f"movie_{movie['id']}")
    else:
        st.info("Start rating movies to get personalized recommendations!")
    
    # Song recommendations
    st.subheader("Songs You Might Like")
    user_song_recs = song_recommender.get_recommendations(user_id)
    if user_song_recs:
        for song in user_song_recs[:5]:
            with st.container():
                st.markdown(f"""
                ### {song['name']}
                by {', '.join(artist['name'] for artist in song['artists'])}
                """)
                if st.button(f"More Info 🎵", key=f"song_{song['id']}"):
                    st.session_state.selected_song = song['id']
    else:
        st.info("Start rating songs to get personalized recommendations!")

def show_movie_page(movie_data, movie_recommender, review_system, streaming_service, ai_recommender):
    try:
        st.title("Movie Explorer")
        
        # Initialize session state for review form and loading states
        if 'show_review_form' not in st.session_state:
            st.session_state.show_review_form = False
        if 'is_loading_recommendations' not in st.session_state:
            st.session_state.is_loading_recommendations = False
        if 'last_search_query' not in st.session_state:
            st.session_state.last_search_query = None
        
        # Add tabs for different sections
        tab1, tab2, tab3 = st.tabs(["Search Movies", "Trending", "My Reviews"])
        
        with tab1:
            try:
                # Search options
                search_type = st.radio(
                    "Choose Search Type",
                    ["Basic Search", "AI Natural Language Search", "Mood-Based Search"],
                    horizontal=True,
                    key="search_type"
                )
                
                if search_type == "Basic Search":
                    search_query = st.text_input(
                        label="Movie Title Search",
                        placeholder="Search movies by title...",
                        key="basic_search"
                    )
                    
                    if search_query and search_query != st.session_state.last_search_query:
                        with st.spinner("Searching movies..."):
                            try:
                                results = movie_data.search_movies(search_query)
                                st.session_state.last_search_query = search_query
                                if results:
                                    display_movie_results(results, movie_data, movie_recommender, review_system, streaming_service)
                                else:
                                    st.info("No movies found matching your search.")
                            except Exception as e:
                                logger.error(f"Error in basic search: {str(e)}\n{traceback.format_exc()}")
                                st.error("Error searching movies. Please try again.")
                    
                elif search_type == "AI Natural Language Search":
                    try:
                        st.markdown("""
                        ### AI Natural Language Search
                        Try queries like:
                        - "Show me the best sci-fi movies from the last 5 years"
                        - "I want to watch a family-friendly adventure movie"
                        - "Find me critically acclaimed dramas with strong female leads"
                        """)
                        
                        nl_query = st.text_input(
                            label="Natural Language Search",
                            placeholder="Describe what you're looking for...",
                            key="nl_search"
                        )
                        
                        if nl_query and nl_query != st.session_state.last_search_query:
                            with st.spinner("Processing your request with AI..."):
                                try:
                                    results = ai_recommender.natural_language_search(nl_query)
                                    display_movie_results(results, movie_data, movie_recommender, review_system, streaming_service)
                                except Exception as e:
                                    logger.error(f"AI search error: {str(e)}\n{traceback.format_exc()}")
                                    st.error("Error processing AI search. Please try again.")
                    except Exception as e:
                        logger.error(f"Error in AI search section: {str(e)}\n{traceback.format_exc()}")
                        st.error("Error loading AI search. Please try again.")
                            
                elif search_type == "Mood-Based Search":
                    try:
                        st.markdown("""
                        ### Mood-Based Search
                        Select your mood to find movies that match your current state of mind.
                        """)
                        
                        mood = st.selectbox(
                            "How are you feeling?",
                            ["Happy", "Sad", "Excited", "Relaxed", "Thoughtful", "Romantic"],
                            key="mood_select"
                        )
                        
                        if st.button("Find Movies", key="mood_search"):
                            with st.spinner("Finding movies to match your mood..."):
                                try:
                                    results = ai_recommender.get_movies_by_mood(mood)
                                    if results:
                                        display_movie_results(results, movie_data, movie_recommender, review_system, streaming_service)
                                    else:
                                        st.info("No movies found for this mood. Try a different one!")
                                except Exception as e:
                                    logger.error(f"Mood search error: {str(e)}\n{traceback.format_exc()}")
                                    st.error("Error finding mood-based movies. Please try again.")
                    except Exception as e:
                        logger.error(f"Error in mood search section: {str(e)}\n{traceback.format_exc()}")
                        st.error("Error loading mood search. Please try again.")
            except Exception as e:
                logger.error(f"Error in search tab: {str(e)}\n{traceback.format_exc()}")
                st.error("Error loading search options. Please try again.")
                            
        with tab2:
            try:
                st.header("Trending Movies")
                try:
                    trending = movie_data.get_trending_movies()
                    if trending:
                        display_movie_results(trending, movie_data, movie_recommender, review_system, streaming_service)
                    else:
                        st.info("No trending movies available at the moment.")
                except Exception as e:
                    logger.error(f"Error loading trending movies: {str(e)}\n{traceback.format_exc()}")
                    st.error("Error loading trending movies. Please try again later.")
            except Exception as e:
                logger.error(f"Error in trending tab: {str(e)}\n{traceback.format_exc()}")
                st.error("Error loading trending section. Please try again.")
                
        with tab3:
            try:
                st.header("My Movie Reviews")
                if 'user' in st.session_state and st.session_state.user['id']:
                    try:
                        user_reviews = review_system.get_user_reviews(st.session_state.user['id'])
                        for review in user_reviews:
                            movie = movie_data.get_movie_details(review['movie_id'])
                            if movie:
                                st.markdown("---")
                                st.markdown(f"### {movie['title']}")
                                # Convert float rating to int for star multiplication
                                rating_stars = '⭐' * int(round(review['rating']))
                                st.markdown(f"**Your Rating:** {rating_stars}")
                                st.write(review['review_text'])
                    except Exception as e:
                        logger.error(f"Error loading user reviews: {str(e)}\n{traceback.format_exc()}")
                        st.error("Error loading your reviews. Please try again.")
                else:
                    st.info("Please log in to see your reviews.")
            except Exception as e:
                logger.error(f"Error in reviews tab: {str(e)}\n{traceback.format_exc()}")
                st.error("Error loading reviews section. Please try again.")
                
    except Exception as e:
        logger.error(f"Critical error in show_movie_page: {str(e)}\n{traceback.format_exc()}")
        raise  # Re-raise the exception to be caught by the error_handling decorator

def display_movie_results(movies, movie_data, movie_recommender, review_system, streaming_service):
    """Display movie search/recommendation results with details and interactions"""
    # Only update search results if new movies are provided
    if movies is not None and movies != st.session_state.search_results:
        st.session_state.search_results = movies
    
    # Use stored movies from session state
    display_movies = st.session_state.search_results
    
    if not display_movies:
        st.info("No movies found")
        return
    
    try:
        # Create MovieCard instance
        movie_card = MovieCard(movie_data, review_system, streaming_service)
        
        # Create columns for movie cards
        cols = st.columns(2)
        
        for idx, movie in enumerate(display_movies):
            with cols[idx % 2]:
                try:
                    # Generate a unique key for this movie
                    movie_key = f"movie_{movie['id']}"
                    
                    # Initialize movie state if not exists
                    if movie_key not in st.session_state.movie_states:
                        st.session_state.movie_states[movie_key] = {
                            'show_details': False,
                            'show_review': False,
                            'show_watch': False,
                            'liked': False
                        }
                    
                    movie_card.display(movie, prefix=movie_key)
                    
                except Exception as e:
                    logger.error(f"Error displaying movie card: {str(e)}\n{traceback.format_exc()}")
                    st.error("Error displaying this movie. Please try again.")
                    continue
                    
    except Exception as e:
        logger.error(f"Error in display_movie_results: {str(e)}\n{traceback.format_exc()}")
        st.error("Error displaying movie results. Please try again.")

def display_movie_details(movie_id: int, movie_data: MovieData, review_system):
    """Display comprehensive movie details with social features"""
    details = movie_data.get_movie_details(movie_id)
    if not details:
        st.error("Could not load movie details")
        return

    # Movie header
    col1, col2 = st.columns([1, 2])
    with col1:
        if details.get('poster_path'):
            st.image(f"{movie_data.image_base_url}{details['poster_path']}", use_container_width=True)
    with col2:
        st.subheader(details['title'])
        st.write(f"**Release Date:** {details.get('release_date', 'N/A')}")
        st.write(f"**Rating:** {'⭐' * int(details.get('vote_average', 'N/A'))}/10")
        
        # Genre display
        genres = [genre['name'] for genre in details.get('genres', [])]
        st.write(f"**Genres:** {', '.join(genres)}")
        
        if details.get('runtime'):
            st.write(f"**Runtime:** {details['runtime']} minutes")
        
        st.write("**Overview:**")
        st.write(details.get('overview', 'No overview available'))

    # Social metrics
    reviews_data = review_system.get_movie_reviews(movie_id)
    st.markdown("---")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Reviews", f"💬 {reviews_data['total_reviews']}")
    with col2:
        if reviews_data['total_reviews'] > 0:
            st.metric("Average Rating", f"⭐ {reviews_data['average_rating']:.1f}/5")
        else:
            st.metric("Average Rating", "No ratings yet")

    # Rating distribution if there are reviews
    if reviews_data['total_reviews'] > 0:
        st.markdown("### Rating Distribution")
        dist = reviews_data['rating_distribution']
        for rating in range(5, 0, -1):
            count = dist.get(rating, 0)
            st.write(f"{'⭐' * rating}: {count} {'review' if count == 1 else 'reviews'}")

    # Like button
    if review_system and 'user' in st.session_state:
        likes_count = review_system.get_movie_likes_count(movie_id)
        is_liked = review_system.get_movie_like_status(movie_id, st.session_state.user['id'])
        like_emoji = "❤️" if is_liked else "🤍"
        
        if st.button(f"{like_emoji} {likes_count}", key=f"like_btn_{movie_id}"):
            if review_system.toggle_movie_like(movie_id, st.session_state.user['id']):
                st.success("Added to your likes!")
                st.rerun()
            else:
                st.info("Removed from your likes")
                st.rerun()
    else:
        likes_count = review_system.get_movie_likes_count(movie_id)
        st.markdown(f"**🤍 {likes_count} likes**")
        
    # Write review section
    if 'user' in st.session_state:
        st.markdown("---")
        st.subheader("Write a Review")
        col1, col2 = st.columns([3, 1])
        with col1:
            review_text = st.text_area("Your thoughts", key=f"review_text_{movie_id}")
        with col2:
            rating = st.select_slider(
                "Rating",
                options=[1, 2, 3, 4, 5],
                value=5,
                key=f"rating_{movie_id}"
            )
            st.write(f"{'⭐' * rating}")
        
        if st.button("Submit Review", key=f"submit_review_{movie_id}"):
            if review_text.strip():
                if review_system.add_review(
                    st.session_state.user['id'],
                    movie_id,
                    review_text,
                    rating
                ):
                    st.success("Review submitted successfully!")
                    time.sleep(1)  # Give user time to see the success message
                    st.rerun()
            else:
                st.warning("Please write a review before submitting")

    # Reviews section
    st.markdown("---")
    st.subheader("Reviews")
    if reviews_data['reviews']:
        for review in reviews_data['reviews']:
            with st.container():
                st.markdown(f"""
                #### {review['username']} {'⭐' * int(review['rating'])}
                {review['review_text']}
                
                *Posted on {review['created_at']}*
                ---
                """)
    else:
        st.info("No reviews yet. Be the first to review!")

    # Close button
    if st.button("Back to Movies", key=f"close_details_{movie_id}"):
        st.session_state[f"show_details_{movie_id}"] = False
        st.rerun()

def show_song_page(song_data: SongData, song_recommender, review_system):
    """Display song search and details with styled cards"""
    st.title("Song Explorer")
    
    # Search box with better styling
    st.markdown("""
        <style>
        .stTextInput > div > div > input {
            border-radius: 20px;
        }
        
        .song-card {
            background-color: #1e1e1e;
            border-radius: 15px;
            padding: 20px;
            margin: 10px 0;
            border: 1px solid #333;
            transition: transform 0.2s;
        }
        
        .song-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        
        .song-title {
            color: #ffffff;
            font-size: 20px;
            margin-bottom: 5px;
        }
        
        .song-artist {
            color: #1DB954;  /* Spotify green */
            font-size: 16px;
        }
        
        .song-album {
            color: #b3b3b3;
            font-size: 14px;
        }
        
        .spotify-button {
            background-color: #1DB954;
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            text-decoration: none;
            font-size: 14px;
            transition: background-color 0.3s;
        }
        
        .spotify-button:hover {
            background-color: #1ed760;
        }
        </style>
    """, unsafe_allow_html=True)
    
    query = st.text_input("🔍 Search for songs, artists, or albums")
    
    if query:
        songs = song_data.search_songs(query)
        
        if songs:
            st.subheader("Search Results")
            for song in songs:
                # Create a styled card for each song
                with st.container():
                    st.markdown("""
                        <div class="song-card">
                    """, unsafe_allow_html=True)
                    
                    col1, col2, col3 = st.columns([2, 6, 2])
                    
                    with col1:
                        # Get album image URL
                        image_url = 'https://via.placeholder.com/100'
                        if isinstance(song.get('album'), dict) and 'images' in song['album']:
                            images = song['album']['images']
                            if images and len(images) > 0:
                                # Get the smallest image for the thumbnail
                                smallest_image = min(images, key=lambda x: x.get('width', float('inf')))
                                image_url = smallest_image.get('url', image_url)
                        
                        st.image(
                            image_url,
                            use_container_width=True
                        )
                    
                    with col2:
                        # Extract artist name from album data
                        artist_name = "Unknown Artist"
                        if isinstance(song.get('album'), dict) and 'artists' in song['album']:
                            artists = song['album']['artists']
                            if artists and len(artists) > 0:
                                artist_name = artists[0].get('name', 'Unknown Artist')
                        
                        # Get album name
                        album_name = "Unknown Album"
                        if isinstance(song.get('album'), dict):
                            album_name = song['album'].get('name', 'Unknown Album')
                        
                        st.markdown(f"""
                            <div class="song-title">{song.get('name', 'Unknown Track')}</div>
                            <div class="song-artist">{artist_name}</div>
                            <div class="song-album">Album: {album_name}</div>
                        """, unsafe_allow_html=True)
                        
                        if song.get('preview_url'):
                            st.audio(song['preview_url'])
                    
                    with col3:
                        if isinstance(song.get('album'), dict) and 'external_urls' in song['album']:
                            external_url = song['album']['external_urls'].get('spotify')
                            if external_url:
                                st.markdown(f"""
                                    <a href="{external_url}" target="_blank" class="spotify-button">
                                        <span>▶️ Play</span>
                                    </a>
                                """, unsafe_allow_html=True)
                    
                    # Additional song details
                    duration_ms = song.get('duration_ms', 0)
                    minutes = duration_ms // 60000
                    seconds = (duration_ms % 60000) // 1000
                    
                    # Get release date from album
                    release_date = "Unknown"
                    if isinstance(song.get('album'), dict):
                        release_date = song['album'].get('release_date', 'Unknown')
                    
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.markdown(f"**⏱️ {minutes}:{seconds:02d}**")
                    with col2:
                        st.markdown(f"**📅 {release_date}**")
                    with col3:
                        if review_system and 'user' in st.session_state:
                            likes_count = review_system.get_song_likes_count(song['id'])
                            is_liked = review_system.get_song_like_status(song['id'], st.session_state.user['id'])
                            like_emoji = "❤️" if is_liked else "🤍"
                            
                            if st.button(f"{like_emoji} {likes_count}", key=f"like_btn_{song['id']}"):
                                if review_system.toggle_song_like(song['id'], st.session_state.user['id']):
                                    st.success("Added to your likes!")
                                    st.rerun()
                        else:
                            likes_count = review_system.get_song_likes_count(song['id'])
                            st.markdown(f"**🤍 {likes_count} likes**")
                    
                    st.markdown("</div>", unsafe_allow_html=True)
        else:
            st.info("No songs found. Try a different search term.")

def display_song_details(song: Dict, review_system=None):
    """Display detailed song information with styling"""
    st.markdown("""
        <style>
        .song-container {
            padding: 20px;
            border-radius: 10px;
            background-color: rgba(255, 255, 255, 0.05);
            margin-bottom: 20px;
        }
        </style>
    """, unsafe_allow_html=True)
    
    with st.container():
        st.markdown('<div class="song-container">', unsafe_allow_html=True)
        col1, col2 = st.columns([1, 3])
        
        with col1:
            # Get album image URL
            image_url = 'https://via.placeholder.com/100'
            if isinstance(song.get('album'), dict) and 'images' in song['album']:
                images = song['album']['images']
                if images and len(images) > 0:
                    # Get the smallest image for the thumbnail
                    smallest_image = min(images, key=lambda x: x.get('width', float('inf')))
                    image_url = smallest_image.get('url', image_url)
            
            st.image(
                image_url,
                use_container_width=True
            )
        
        with col2:
            st.markdown(f"### {song['name']}")
            artists = ', '.join(artist['name'] for artist in song['artists'])
            st.write(f"**Artist(s):** {artists}")
            st.write(f"**Album:** {song['album']['name']}")
            
            # Like functionality
            if review_system and 'user' in st.session_state and st.session_state.user['is_logged_in']:
                col_like, col_count = st.columns([1, 4])
                
                with col_like:
                    user_id = st.session_state.user['id']
                    is_liked = review_system.has_user_liked_song(song['id'], user_id)
                    like_emoji = "❤️" if is_liked else "🤍"
                    
                    # Create unique key for the button
                    button_key = f"like_button_{song['id']}_{datetime.now().timestamp()}"
                    if st.button(like_emoji, key=button_key):
                        if review_system.toggle_song_like(song['id'], user_id):
                            st.rerun()
                
                with col_count:
                    likes_count = review_system.get_song_likes_count(song['id'])
                    st.write(f"**{likes_count}** likes")
            
            if song.get('preview_url'):
                st.audio(song['preview_url'])
                
        st.markdown('</div>', unsafe_allow_html=True)

def show_profile_page(user_profile):
    st.title("Your Profile")
    
    if 'user' not in st.session_state:
        # Show login prompt for guests
        st.info("Please log in to view your profile")
        
        # Optional: Add login form or button here
        if st.button("Log In", key="profile_login_btn"):
            # Redirect to login page or show login modal
            pass
            
    else:
        # Display profile for logged-in users
        user_profile.display_profile()

def show_watchlist_page(movie_data, streaming_service):
    st.title("Your Watchlist")
    if 'user' in st.session_state:
        watchlist = streaming_service.get_user_watchlist(st.session_state.user['id'])
        for movie_id in watchlist:
            movie = movie_data.get_movie_details(movie_id)
            if movie:
                with st.container():
                    col1, col2 = st.columns([1, 3])
                    with col1:
                        if movie.get('poster_path'):
                            st.image(f"https://image.tmdb.org/t/p/w200{movie['poster_path']}", use_container_width=True)
                    with col2:
                        st.markdown(f"### {movie['title']}")
                        st.write(movie['overview'][:200] + "...")
                        if st.button(f"Remove from Watchlist", key=f"remove_{movie['id']}"):
                            streaming_service.remove_from_watchlist(
                                st.session_state.user['id'], movie['id'])
                            st.rerun()

def show_chat_page(movie_chatbot):
    st.title("Movie Chat")
    if 'messages' not in st.session_state:
        st.session_state.messages = []

    # Display chat history
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    # Chat input
    if prompt := st.chat_input("Ask about movies..."):
        # Add user message to chat history
        st.session_state.messages.append({"role": "user", "content": prompt})
        
        # Get chatbot response
        response = movie_chatbot.get_response(prompt)
        
        # Add assistant response to chat history
        st.session_state.messages.append({"role": "assistant", "content": response})
        
        # Rerun to update chat display
        st.rerun()

def show_admin_page(movie_data):
    st.title("Admin Dashboard")
    
    # Affiliate Links Management
    st.header("Manage Affiliate Links")
    
    # Add new affiliate link
    with st.form("add_affiliate"):
        movie_search = st.text_input(
            label="Search for Movie",
            placeholder="Enter movie title...",
            key="movie_search_admin"
        )
        if movie_search:
            movies = movie_data.search_movies(movie_search)
            selected_movie = st.selectbox(
                "Select Movie",
                options=[(m['id'], m['title']) for m in movies],
                format_func=lambda x: x[1]
            )
        
        platform = st.selectbox("Platform", ["Netflix", "Amazon", "Hulu", "Disney+"])
        link = st.text_input(
            label="Affiliate Link URL",
            placeholder="Enter affiliate link...",
            key="affiliate_link_input"
        )
        
        if st.form_submit_button("Add Affiliate Link"):
            movie_data.add_affiliate_link(
                selected_movie[0],
                platform,
                link,
                st.session_state.user['id']
            )
            st.success("Affiliate link added successfully!")

def display_profile_header():
    """Display profile header at the top of the page"""
    with st.container():
        col1, col2, col3 = st.columns([1, 2, 1])
        
        with col1:
            st.markdown("### 👤")
            
        with col2:
            if 'user' in st.session_state and st.session_state.user['is_logged_in']:
                st.markdown(f"### Welcome, {st.session_state.user['username']}!")
            else:
                st.markdown("### Welcome, Guest!")
            st.markdown("Member since: January 2024")
            
        with col3:
            timestamp = datetime.now().timestamp()
            
            if 'user' in st.session_state and st.session_state.user['is_logged_in']:
                # Show profile options for logged-in users
                if st.button(
                    "Edit Profile",
                    key=f"edit_profile_btn_{timestamp}",
                    help="Edit your profile settings"
                ):
                    st.session_state.show_profile_settings = True
                
                if st.button(
                    "Logout",
                    key=f"logout_btn_{timestamp}",
                    help="Sign out of your account",
                    type="secondary"
                ):
                    st.session_state.user = {
                        'id': None,
                        'username': 'Guest',
                        'is_logged_in': False
                    }
                    st.session_state.show_login = False
                    st.session_state.pop('show_profile_settings', None)
                    st.rerun()
            else:
                # Show login form
                st.button(
                    "Login",
                    key=f"login_btn_{timestamp}",
                    help="Sign in to your account",
                    on_click=lambda: setattr(st.session_state, 'show_login', True)
                )
                
                if st.session_state.show_login:
                    st.markdown("### Login")
                    display_auth_forms()
                
                if not st.session_state.show_login:
                    # Add register link
                    st.markdown(
                        "New user? [Register here](#)",
                        help="Create a new account"
                    )
            
    st.markdown("---")

def display_auth_forms():
    tab1, tab2 = st.tabs(["Login", "Register"])
    
    with tab1:
        with st.form("login_form", clear_on_submit=True):
            username = st.text_input("Username", key="login_username")
            password = st.text_input("Password", type="password", key="login_password")
            
            col1, col2 = st.columns([1, 1])
            with col1:
                submit = st.form_submit_button("Sign In", use_container_width=True)
            with col2:
                if st.form_submit_button("Cancel", type="secondary", use_container_width=True):
                    st.session_state.show_auth = False
                    st.rerun()
            
            if submit and username and password:
                if st.session_state.auth.login_user(username, password):
                    st.session_state.show_auth = False
                    st.rerun()
    
    with tab2:
        with st.form("register_form", clear_on_submit=True):
            username = st.text_input("Username", key="reg_username")
            email = st.text_input("Email", key="reg_email")
            password = st.text_input("Password", type="password", key="reg_password")
            confirm_password = st.text_input("Confirm Password", type="password", key="reg_confirm_password")
            
            col1, col2 = st.columns([1, 1])
            with col1:
                submit = st.form_submit_button("Register", use_container_width=True)
            with col2:
                if st.form_submit_button("Cancel", type="secondary", use_container_width=True):
                    st.session_state.show_auth = False
                    st.rerun()
            
            if submit:
                if not username or not email or not password or not confirm_password:
                    st.error("Please fill in all fields")
                elif password != confirm_password:
                    st.error("Passwords do not match")
                elif len(password) < 8:
                    st.error("Password must be at least 8 characters long")
                elif not re.match(r"[^@]+@[^@]+\.[^@]+", email):
                    st.error("Invalid email address")
                else:
                    if st.session_state.auth.register_user(username, email, password):
                        st.success("Registration successful! You can now log in.")
                        time.sleep(1)
                        st.session_state.show_auth = False
                        st.rerun()

def verify_credentials(username: str, password: str) -> bool:
    """Verify user credentials"""
    session = sessionmaker(bind=st.session_state.db_engine)()
    try:
        user = session.query(User).filter_by(username=username).first()
        if user:
            st.write(f"Debug: Found user with username {username}")  # Debug info
            if verify_password(password, user.password_hash):
                st.write("Debug: Password verified")  # Debug info
                return True
            else:
                st.write("Debug: Password verification failed")  # Debug info
        else:
            st.write(f"Debug: No user found with username {username}")  # Debug info
        return False
    except Exception as e:
        st.error(f"Error verifying credentials: {str(e)}")
        return False
    finally:
        session.close()

def get_user_data(username: str) -> Dict:
    """Get user data from database"""
    session = sessionmaker(bind=st.session_state.db_engine)()
    try:
        user = session.query(User).filter_by(username=username).first()
        if user:
            return {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'is_admin': user.is_admin
            }
        return None
    finally:
        session.close()

def verify_password(password: str, password_hash: str) -> bool:
    """Verify password against hash"""
    # Replace with your actual password verification logic
    # This is just a placeholder - use proper password hashing!
    return password == password_hash  # DO NOT use in production!

def search_movies():
    """Handle movie search functionality"""
    # Add label to search input
    search_query = st.text_input(
        label="Movie Search",
        placeholder="Search for movies...",
        label_visibility="collapsed"  # Hides the label but keeps it accessible
    )
    
    if search_query:
        # Get movie data instance from session state or create new one
        if 'movie_data' not in st.session_state:
            st.session_state.movie_data = MovieData()
        
        # Search for movies
        results = st.session_state.movie_data.search_movies(search_query)
        
        if results:
            for movie in results:
                with st.container():
                    col1, col2 = st.columns([1, 3])
                    
                    with col1:
                        if movie.get('poster_path'):
                            st.image(f"https://image.tmdb.org/t/p/w200{movie['poster_path']}", use_container_width=True)
                    
                    with col2:
                        st.markdown(f"### {movie['title']}")
                        st.write(movie['overview'][:200] + "...")
                        if st.button("More Details", key=f"details_{movie['id']}"):
                            st.session_state.selected_movie = movie['id']
        else:
            st.info("No movies found matching your search.")

def display_user_lists():
    """Display user's watchlist and liked movies"""
    if 'user' not in st.session_state:
        st.info("Please log in to view your lists")
        return
        
    # Create tabs for different lists
    watchlist_tab, likes_tab = st.tabs(["Watchlist", "Liked Movies"])
    
    with watchlist_tab:
        st.header("Your Watchlist")
        if 'streaming_service' not in st.session_state:
            st.session_state.streaming_service = StreamingService(st.session_state.db_engine)
            
        watchlist = st.session_state.streaming_service.get_user_watchlist(st.session_state.user['id'])
        
        if watchlist:
            for movie_id in watchlist:
                movie = st.session_state.movie_data.get_movie_details(movie_id)
                if movie:
                    with st.container():
                        col1, col2 = st.columns([1, 3])
                        with col1:
                            if movie.get('poster_path'):
                                st.image(f"https://image.tmdb.org/t/p/w200{movie['poster_path']}", use_container_width=True)
                        with col2:
                            st.markdown(f"### {movie['title']}")
                            st.write(movie['overview'][:200] + "...")
                            if st.button("Remove from Watchlist", key=f"remove_watchlist_{movie['id']}"):
                                st.session_state.streaming_service.remove_from_watchlist(
                                    st.session_state.user['id'], movie['id'])
                                st.rerun()
        else:
            st.info("Your watchlist is empty. Add movies to watch later!")
    
    with likes_tab:
        st.header("Movies You've Liked")
        if 'review_system' not in st.session_state:
            st.session_state.review_system = ReviewSystem(st.session_state.db_engine)
            
        liked_movies = st.session_state.review_system.get_user_likes(st.session_state.user['id'])
        
        if liked_movies:
            for movie_id in liked_movies:
                movie = st.session_state.movie_data.get_movie_details(movie_id)
                if movie:
                    with st.container():
                        col1, col2 = st.columns([1, 3])
                        with col1:
                            if movie.get('poster_path'):
                                st.image(f"https://image.tmdb.org/t/p/w200{movie['poster_path']}", use_container_width=True)
                        with col2:
                            st.markdown(f"### {movie['title']}")
                            st.write(movie['overview'][:200] + "...")
                            if st.button("Unlike", key=f"unlike_{movie['id']}"):
                                st.session_state.review_system.remove_like(
                                    st.session_state.user['id'], movie['id'])
                                st.rerun()
        else:
            st.info("You haven't liked any movies yet. Start exploring!")

def display_user_reviews():
    """Display all reviews made by the current user"""
    if 'user' not in st.session_state:
        st.info("Please log in to view your reviews")
        return
        
    st.header("Your Movie Reviews")
    
    # Get review system from session state
    if 'review_system' not in st.session_state:
        st.session_state.review_system = ReviewSystem(st.session_state.db_engine)
    
    try:
        # Get all reviews by the user
        user_reviews = st.session_state.review_system.get_user_reviews_by_user_id(st.session_state.user['id'])
        
        if user_reviews:
            for review in user_reviews:
                # Get movie details
                movie = st.session_state.movie_data.get_movie_details(review['movie_id'])
                if movie:
                    with st.container():
                        col1, col2 = st.columns([1, 3])
                        
                        with col1:
                            if movie.get('poster_path'):
                                st.image(f"https://image.tmdb.org/t/p/w200{movie['poster_path']}", use_container_width=True)
                        
                        with col2:
                            st.markdown(f"### {movie['title']}")
                            # Convert float rating to int for star multiplication
                            rating_stars = '⭐' * int(round(review['rating']))
                            st.markdown(f"**Your Rating:** {rating_stars}")
                            st.write(review['review_text'])
                            st.markdown(f"*Reviewed on {review['created_at'].strftime('%Y-%m-%d')}*")
                            
                            # Add edit and delete buttons
                            col1, col2 = st.columns(2)
                            with col1:
                                if st.button("Edit Review", key=f"edit_{review['movie_id']}"):
                                    st.session_state[f"edit_review_{review['movie_id']}"] = True
                            with col2:
                                if st.button("Delete Review", key=f"delete_{review['movie_id']}"):
                                    if st.session_state.review_system.delete_review(
                                        st.session_state.user['id'], 
                                        review['movie_id']
                                    ):
                                        st.rerun()
                        
                        # Show edit form if edit button was clicked
                        if st.session_state.get(f"edit_review_{review['movie_id']}", False):
                            with st.form(key=f"edit_review_form_{review['movie_id']}"):
                                new_rating = st.slider("Rating", 1, 5, int(review['rating']))
                                new_review_text = st.text_area("Review", review['review_text'])
                                
                                if st.form_submit_button("Update Review"):
                                    try:
                                        st.session_state.review_system.update_review(
                                            st.session_state.user['id'], 
                                            review['movie_id'], 
                                            new_review_text, 
                                            new_rating
                                        )
                                        st.success("Review updated successfully!")
                                        st.session_state[f"edit_review_{review['movie_id']}"] = False
                                        st.rerun()
                                    except Exception as e:
                                        st.error(f"Error updating review: {str(e)}")
    except Exception as e:
        st.error(f"Error loading reviews: {str(e)}")

def show_movies_grid(movie_data, review_system, streaming_service):
    st.title("Featured Movies")
    
    # Create MovieCard instance
    movie_card = MovieCard(movie_data, review_system, streaming_service)
    
    # Get trending/popular movies
    movies = movie_data.get_trending_movies()
    
    # Display movies in a grid
    cols = st.columns(2)
    for idx, movie in enumerate(movies):
        with cols[idx % 2]:
            movie_card.display(movie)

def display_review_form(movie_id, review_system):
    """Display the review form with modern styling"""
    with st.expander("Write a Review", expanded=True):
        st.markdown("""
        <style>
        .review-form {
            background: rgba(255, 255, 255, 0.05);
            padding: 1.5rem;
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        </style>
        """, unsafe_allow_html=True)
        
        timestamp = datetime.now().timestamp()
        rating = st.slider(
            "Rating",
            1, 5, 5,
            key=f"rating_{movie_id}_{timestamp}"
        )
        st.write(f"{'⭐' * rating}")
        
        # Create the text area before referencing it
        with st.form(key=f"review_form_{movie_id}_{timestamp}"):
            review_text = st.text_area(
                "Your Review",
                key=f"review_text_{movie_id}_{timestamp}",
                height=100
            )
            
            if st.form_submit_button("Submit Review"):
                if review_text.strip():
                    if review_system.add_review(
                        st.session_state.user['id'],
                        movie_id,
                        review_text,
                        rating
                    ):
                        st.success("Review submitted successfully!")
                        time.sleep(1)
                        st.session_state[f"show_review_{movie_id}"] = False
                        st.rerun()
                else:
                    st.warning("Please write a review before submitting")

if __name__ == "__main__":
    main()
