import streamlit as st
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from functools import lru_cache

class SongRecommender:
    def __init__(self, song_data):
        self.song_data = song_data
        self.scaler = MinMaxScaler()
        self._initialize_cache()

    def _initialize_cache(self):
        """Initialize cache structures"""
        if 'song_recommendations' not in st.session_state:
            st.session_state.song_recommendations = {}
        if 'audio_features_cache' not in st.session_state:
            st.session_state.audio_features_cache = {}
        if 'song_cache_ttl' not in st.session_state:
            st.session_state.song_cache_ttl = timedelta(hours=1)

    @lru_cache(maxsize=100)
    def get_recommendations(self, song_id: str, n_recommendations: int = 10) -> List[Dict]:
        """Get song recommendations with improved caching and error handling"""
        try:
            cache_key = f"song_{song_id}_{datetime.now().strftime('%Y%m%d')}"
            if self._is_cache_valid(cache_key):
                return st.session_state.song_recommendations[cache_key]['data']

            # Get seed song and its features
            seed_song = self.song_data.get_song_by_id(song_id)
            if not seed_song:
                return self._get_default_recommendations(n_recommendations)

            seed_features = self._get_audio_features(song_id)
            if not seed_features:
                return self._get_default_recommendations(n_recommendations)

            recommendations = self._generate_recommendations(
                seed_song, seed_features, n_recommendations)
            self._cache_recommendations(cache_key, recommendations)
            
            return recommendations

        except Exception as e:
            st.error(f"Error in song recommendation generation: {str(e)}")
            return self._get_default_recommendations(n_recommendations)

    def _is_cache_valid(self, cache_key: str) -> bool:
        """Check if cached recommendations are still valid"""
        if cache_key in st.session_state.song_recommendations:
            cache_age = datetime.now() - st.session_state.song_recommendations[cache_key]['timestamp']
            return cache_age < st.session_state.song_cache_ttl
        return False

    def _get_audio_features(self, song_id: str) -> Optional[Dict]:
        """Get cached or fresh audio features"""
        try:
            if song_id in st.session_state.audio_features_cache:
                cache_data = st.session_state.audio_features_cache[song_id]
                if datetime.now() - cache_data['timestamp'] < st.session_state.song_cache_ttl:
                    return cache_data['features']

            features = self.song_data._make_api_request(f'audio-features/{song_id}')
            if features:
                st.session_state.audio_features_cache[song_id] = {
                    'features': features,
                    'timestamp': datetime.now()
                }
            return features

        except Exception as e:
            st.error(f"Error fetching audio features: {str(e)}")
            return None

    def _generate_recommendations(self, seed_song: Dict, seed_features: Dict, n: int) -> List[Dict]:
        """Generate song recommendations with enhanced feature analysis"""
        try:
            recommendations = self.song_data.get_recommendations(
                [seed_song['id']], 
                self._extract_genres(seed_song),
                limit=n*2  # Get more recommendations for better filtering
            )

            enhanced_recommendations = []
            for rec in recommendations:
                rec_features = self._get_audio_features(rec['id'])
                if rec_features:
                    similarity = self._calculate_similarity(seed_features, rec_features)
                    rec['similarity_score'] = similarity
                    rec['match_reason'] = self._get_match_reason(
                        seed_song, rec, seed_features, rec_features)
                    enhanced_recommendations.append(rec)

            # Sort by similarity and ensure diversity
            return self._diversify_recommendations(enhanced_recommendations, n)

        except Exception as e:
            st.error(f"Error generating recommendations: {str(e)}")
            return []

    def _calculate_similarity(self, features1: Dict, features2: Dict) -> float:
        """Calculate enhanced similarity between songs"""
        try:
            feature_keys = [
                'danceability', 'energy', 'loudness', 'speechiness',
                'acousticness', 'instrumentalness', 'liveness', 'valence', 'tempo'
            ]
            
            weights = {
                'danceability': 0.15,
                'energy': 0.15,
                'loudness': 0.1,
                'speechiness': 0.1,
                'acousticness': 0.15,
                'instrumentalness': 0.1,
                'liveness': 0.05,
                'valence': 0.15,
                'tempo': 0.05
            }

            similarity = 0.0
            for key in feature_keys:
                if key in features1 and key in features2:
                    diff = abs(features1[key] - features2[key])
                    if key == 'tempo':
                        # Normalize tempo difference
                        diff = min(diff / 50.0, 1.0)
                    elif key == 'loudness':
                        # Normalize loudness difference
                        diff = min(abs(diff) / 20.0, 1.0)
                    similarity += weights[key] * (1 - diff)

            return similarity

        except Exception:
            return 0.0

    def _diversify_recommendations(self, recommendations: List[Dict], n: int) -> List[Dict]:
        """Ensure diverse recommendations"""
        if not recommendations:
            return []

        # Sort by similarity score
        sorted_recs = sorted(recommendations, key=lambda x: x.get('similarity_score', 0), reverse=True)
        
        # Ensure genre diversity
        diverse_recs = []
        genre_counts = {}
        
        for rec in sorted_recs:
            genres = set(self._extract_genres(rec))
            
            # Check if we're not over-representing any genre
            genre_ok = True
            for genre in genres:
                if genre_counts.get(genre, 0) >= n/3:  # No more than 1/3 of recs from same genre
                    genre_ok = False
                    break
                    
            if genre_ok:
                diverse_recs.append(rec)
                for genre in genres:
                    genre_counts[genre] = genre_counts.get(genre, 0) + 1
                    
            if len(diverse_recs) >= n:
                break
                
        return diverse_recs

    def _get_default_recommendations(self, n: int) -> List[Dict]:
        """Get default recommendations for new users"""
        try:
            return self.song_data.get_trending_songs(limit=n)
        except Exception as e:
            st.error(f"Error getting default song recommendations: {str(e)}")
            return []

    def _cache_recommendations(self, cache_key: str, recommendations: List[Dict]):
        """Cache recommendations with timestamp"""
        st.session_state.song_recommendations[cache_key] = {
            'data': recommendations,
            'timestamp': datetime.now()
        }

    def _extract_genres(self, song: Dict) -> List[str]:
        """Extract genres from song metadata"""
        genres = []
        if 'artists' in song:
            for artist in song['artists']:
                if 'genres' in artist:
                    genres.extend(artist['genres'])
        return list(set(genres))

    def _get_match_reason(self, seed_song: Dict, rec_song: Dict,
                         seed_features: Dict, rec_features: Dict) -> str:
        """Generate detailed match reason"""
        try:
            reasons = []
            
            # Compare audio features
            if abs(seed_features['energy'] - rec_features['energy']) < 0.2:
                reasons.append("similar energy level")
            if abs(seed_features['danceability'] - rec_features['danceability']) < 0.2:
                reasons.append("similar danceability")
            if abs(seed_features['valence'] - rec_features['valence']) < 0.2:
                reasons.append("similar mood")
                
            # Compare genres
            seed_genres = set(self._extract_genres(seed_song))
            rec_genres = set(self._extract_genres(rec_song))
            common_genres = seed_genres & rec_genres
            if common_genres:
                reasons.append(f"shared genres: {', '.join(list(common_genres)[:2])}")
                
            if not reasons:
                return "musically similar"
            
            return " and ".join(reasons[:2])

        except Exception:
            return "musically similar"