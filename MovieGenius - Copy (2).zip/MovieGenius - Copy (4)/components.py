import streamlit as st
from typing import Optional, List, Dict, Any, Callable
from datetime import datetime

class LoadingSpinner:
    def __init__(self, text: str = "Loading..."):
        self.text = text
    
    def __enter__(self):
        st.spinner(self.text).__enter__()
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        st.spinner(self.text).__exit__(exc_type, exc_val, exc_tb)

class ErrorBoundary:
    def __init__(self, fallback: Optional[Callable] = None):
        self.fallback = fallback
    
    def __enter__(self):
        pass
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            from error_handler import error_logger
            error_logger.display_error_message(
                exc_val,
                "rendering component",
                "Something went wrong while displaying this component."
            )
            if self.fallback:
                self.fallback()
            return True

def display_rating(rating: float, max_rating: int = 5, emoji: str = "⭐") -> None:
    """Display a rating using emoji stars"""
    full_stars = int(rating)
    decimal_part = rating - full_stars
    
    # Display full stars
    st.write(emoji * full_stars + ("½" if decimal_part >= 0.5 else ""), 
             f"({rating:.1f})")

def display_timestamp(timestamp: datetime, format: str = "%Y-%m-%d %H:%M") -> None:
    """Display a formatted timestamp"""
    st.write(timestamp.strftime(format))

def confirmation_dialog(message: str, on_confirm: Callable, 
                       confirm_text: str = "Confirm",
                       cancel_text: str = "Cancel") -> None:
    """Display a confirmation dialog"""
    col1, col2 = st.columns(2)
    with col1:
        if st.button(confirm_text):
            on_confirm()
    with col2:
        if st.button(cancel_text):
            st.session_state.show_confirmation = False

def paginated_list(items: List[Any], items_per_page: int = 10,
                  key_prefix: str = "") -> List[Any]:
    """Display a paginated list of items"""
    if not items:
        return []

    # Initialize pagination state
    if f"{key_prefix}_page" not in st.session_state:
        st.session_state[f"{key_prefix}_page"] = 0

    total_pages = (len(items) + items_per_page - 1) // items_per_page
    current_page = st.session_state[f"{key_prefix}_page"]

    # Page navigation
    col1, col2, col3 = st.columns([1, 3, 1])
    with col1:
        if current_page > 0:
            if st.button("Previous", key=f"{key_prefix}_prev"):
                st.session_state[f"{key_prefix}_page"] -= 1
                st.rerun()

    with col2:
        st.write(f"Page {current_page + 1} of {total_pages}")

    with col3:
        if current_page < total_pages - 1:
            if st.button("Next", key=f"{key_prefix}_next"):
                st.session_state[f"{key_prefix}_page"] += 1
                st.rerun()

    # Display current page items
    start_idx = current_page * items_per_page
    end_idx = min(start_idx + items_per_page, len(items))
    return items[start_idx:end_idx]

def search_bar(on_search: Callable[[str], None], placeholder: str = "Search...",
              key: str = "search") -> None:
    """Display a search bar with debouncing"""
    query = st.text_input("Search", placeholder=placeholder, key=key)
    
    # Debounce search
    if key not in st.session_state:
        st.session_state[key] = ""
    
    if query != st.session_state[key]:
        st.session_state[key] = query
        on_search(query)

def notification_toast(message: str, type: str = "info") -> None:
    """Display a notification toast"""
    if type == "success":
        st.success(message)
    elif type == "error":
        st.error(message)
    elif type == "warning":
        st.warning(message)
    else:
        st.info(message)

class TabView:
    """A reusable tabbed view component"""
    def __init__(self, tabs: Dict[str, Callable]):
        self.tabs = tabs
    
    def render(self, default_tab: Optional[str] = None):
        tab_names = list(self.tabs.keys())
        if not tab_names:
            return
        
        selected_tab = st.radio(
            "Select Tab",
            tab_names,
            index=tab_names.index(default_tab) if default_tab in tab_names else 0,
            horizontal=True
        )
        
        with ErrorBoundary():
            self.tabs[selected_tab]()

class Card:
    """A reusable card component"""
    def __init__(self, title: str, content: Any, footer: Optional[Any] = None):
        self.title = title
        self.content = content
        self.footer = footer
    
    def render(self):
        """Render the card component"""
        container = st.container()
        with container:
            st.markdown(f"### {self.title}")
            self.content.markdown("", unsafe_allow_html=True)  # Render the content container
            if self.footer:
                st.markdown("---")
                self.footer.markdown("", unsafe_allow_html=True)  # Render the footer container
        return container

def loading_placeholder(key: str) -> None:
    """Display a loading placeholder"""
    if f"{key}_loading" not in st.session_state:
        st.session_state[f"{key}_loading"] = True
        
    if st.session_state[f"{key}_loading"]:
        st.markdown("Loading...")