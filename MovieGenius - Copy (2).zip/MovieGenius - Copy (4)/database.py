from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import SQLAlchemyError
import os
import streamlit as st
from error_handler import error_logger
from exceptions import DatabaseError
from contextlib import contextmanager

# Create data directory if it doesn't exist
if not os.path.exists('data'):
    os.makedirs('data')

# Single database URL for the entire application
DATABASE_URL = "sqlite:///data/moviegenius.db"

# Create the engine
engine = create_engine(DATABASE_URL)

# Create a base class for declarative models
Base = declarative_base()

# Create a session factory
Session = sessionmaker(bind=engine)

@contextmanager
def session_scope():
    """Provide a transactional scope around a series of operations."""
    session = Session()
    try:
        yield session
        session.commit()
    except SQLAlchemyError as e:
        session.rollback()
        error_logger.log_error(e, "database session operation")
        raise DatabaseError(f"Database operation failed: {str(e)}")
    finally:
        session.close()

def get_database_engine():
    """Get or create database engine with connection pooling and error handling"""
    try:
        if 'db_engine' not in st.session_state:
            st.session_state.db_engine = engine
        return st.session_state.db_engine
    except SQLAlchemyError as e:
        error_logger.log_error(e, "database engine creation")
        raise DatabaseError(f"Failed to create database engine: {str(e)}")

def get_db_session():
    """Get a database session with error handling"""
    try:
        engine = get_database_engine()
        SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
        return SessionLocal()
    except SQLAlchemyError as e:
        error_logger.log_error(e, "database session creation")
        raise DatabaseError(f"Failed to create database session: {str(e)}")

def check_database_health():
    """Check database connection and basic operations"""
    try:
        engine = get_database_engine()
        # Test connection
        with engine.connect() as conn:
            conn.execute("SELECT 1")
        return True
    except SQLAlchemyError as e:
        error_logger.log_error(e, "database health check")
        return False

def reset_database_connection():
    """Reset database connection in case of issues"""
    try:
        if 'db_engine' in st.session_state:
            st.session_state.db_engine.dispose()
            del st.session_state.db_engine
        return True
    except Exception as e:
        error_logger.log_error(e, "database connection reset")
        return False

__all__ = ['engine', 'Base', 'Session', 'session_scope']